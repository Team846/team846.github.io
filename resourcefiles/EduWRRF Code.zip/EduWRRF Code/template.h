/********************************************************************************
* FILE NAME: TEMPLATE.h
* Author:
*
* DESCRIPTION: 
*  This file contains...
*
* TEMPLATE header -- Replace with your own content
*  The #ifndef/#define/#endif below ensures that the contents are only included once
*    
********************************************************************************/

#ifndef __TEMPLATE_h_
#define __TEMPLATE_h_
/****** DECLARATIONS **********/

//your delarations here

/****** PROTOTYPES ************/

//your prototypes here

#endif __TEMPLATE_h_	//Nothing below this line!!!
