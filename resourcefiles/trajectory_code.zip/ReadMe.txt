========================================================================
    CONSOLE APPLICATION : trajectory Project Overview
========================================================================

AppWizard has created this trajectory application for you.  
This file contains a summary of what you will find in each of the files that
make up your trajectory application.


trajectory.vcproj
    This is the main project file for VC++ projects generated using an Application Wizard. 
    It contains information about the version of Visual C++ that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

trajectory.cpp
    This is the main application source file.

/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named trajectory.pch and a precompiled types file named StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" comments to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////


trajectory.exe
	Data from calculation is output to file "path.txt" which is  comma-quoted delimited making it easy
	to import int Excel and other spreadsheet applications for graphing and analysis.
	
	Users needs to supply initial velocity, initial angle and altitude above sea level.  The altitude doesn't make 
	much difference unless you are wanting to calculate for someplace like Denver where the altitude is 1607 m.
	For San Jose, the altitude is 16 m above sea level.  Atlanta is at 305 m which still doesn't have a significant
	effect on the answer.