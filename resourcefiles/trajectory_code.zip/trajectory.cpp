// trajectory.cpp : Calculate the trajectory of a ball with and without air resistance.  
//					Also accounts for the effect of altitude on the density of air. 
//					This code was rewritten into a Microsoft Visual C++ Windows 32 Console application
//					from Fortran code that I found on the internet at http://www.pdas.com/programs.bb.f90
//					For a discuss about this calculation and the effect of altitude on the flight of a baseball
//					check out http://www.pdas.com/bb1.htm
//
//					Version 1.0 written on January 14, 2006 by David Wachenschwanz

#include "stdafx.h"
#include <math.h>
#include <complex>
using namespace std;

typedef complex<double> dcmplx;


const double PI = 3.14159265; 
const double G = 9.80665;	// acceleration of gravity (m/s^2)
const double RHOZERO = 1.2250;	// density of air at sealevel (kg/m^3)

const double DT = 0.01;	// step time in secs

const double DIAM = 7.*2.54/100.;		// 7 inch ball diameter converted to meters
//const double DIAM = (9.125/(12.*PI))*0.3048;		// 9.125" circumference baseball
const double MASS = 0.185;				// mass of Poof basketball in kg
//const double MASS = 5.125/16*0.45359237;				// mass of baseball in kg
const double SREF = 0.25*PI*DIAM*DIAM;	// frontal area of ball (m^2)




struct TrajectoryPoint
{
	double time;
	dcmplx position;
	dcmplx velocity;
	dcmplx acceleration;
};

typedef TrajectoryPoint TrajectoryPoint;

void VacuumTrajectory(double,double,int,TrajectoryPoint *);
void Trajectory(double,double,double,bool,int,TrajectoryPoint *);
dcmplx Accel(double,dcmplx,dcmplx);
void BallKutta(TrajectoryPoint,double,TrajectoryPoint *);
double CdSphere(double);
double MetricViscosity(double);
void SimpleAtmosphere(double,double *,double *,double *);



int _tmain(int argc, _TCHAR* argv[])
{
	int i;
	int nPts;
	double dInitAngle;		// initial angle from horizontal in degrees
	double dInitVelocity;	// initial velocity in m/s
	double dInitAltitude;	// initial altitude in meters

	// double dInitAlitude = 16.;		//Altitude of San Jose in meters
	// double dInitAltitude = 305.;		// Altitude of Atlanta in meters
	// double dInitAltitude = 1609.; 	//Altitude of Denver in meters
	bool NORMALIZED = 1;

	TrajectoryPoint p[1000];
	TrajectoryPoint pv[1000];
	nPts = 1000;

	FILE *fo;

	printf("\nEnter Initial Velocity (m/s):  ");
	scanf("%lf", &dInitVelocity);
	printf("\nEnter Initial Angle (degrees):  ");
	scanf("%lf", &dInitAngle);
	printf("\nEnter Altitude (meters):  ");
	scanf("%lf", &dInitAltitude);

	printf("\n");

	// Calculate trajectory with air resistance
	Trajectory(dInitAltitude, dInitVelocity, dInitAngle, NORMALIZED, nPts, p);

	// Calculate trajectory with no air resistance
	VacuumTrajectory(dInitVelocity, dInitAngle, nPts, pv);

	fo = fopen("path.txt","w");

	fprintf(fo,"\"Point\",\"Time_s\",\"x_drag_m\",\"y_drag_m\",\"vx_drag_m/s\",\"vy_drag_m/s\",\"ax_drag_m/s^2\",\"ay_drag_m/s^2\",\"x_m\",\"y_m\",\"vx_m/s\",\"vy_m/s\",\"ax_m/s^2\",\"ay_m/s^2\"\n");
	for(i=0;i<nPts;++i)
		fprintf(fo,"%d, %lf, %lf, %lf, %lf, %lf, %lf, %lf, %lf, %lf, %lf, %lf, %lf, %lf\n",i, p[i].time, p[i].position, p[i].velocity, p[i].acceleration, pv[i].position, pv[i].velocity, pv[i].acceleration);

	fclose(fo);


	return 0;
}



// void Trajectory():  This function calculates the solution to the ordinary set of differential equations
//						that describes the motion of a trajectory with the effect of air resistance.  A 4th order
//						Runga-Kutta method is used to solve numerically.  
//
void Trajectory(double dInitAltitude, double dInitVelocity,double dInitAngle, bool NORMALIZED, int nPts, TrajectoryPoint *p)
{
	int i;
	double t;

	dcmplx position, velocity, acceleration;


	t = 0.;
	
	position = dcmplx (0.,dInitAltitude);
	velocity = dcmplx(dInitVelocity*cos(dInitAngle*PI/180.), dInitVelocity*sin(dInitAngle*PI/180.));
	acceleration = Accel(t, position,velocity);

	// cout << "acceleration = " <<acceleration << "\n";

	p[0].time = t;
	p[0].position = position;
	p[0].velocity = velocity;
	p[0].acceleration = acceleration;

	for(i=1; i<nPts; ++i)
		BallKutta(p[i-1],DT, &p[i]);

	if(NORMALIZED)
		for(i=0;i<nPts;++i)
			p[i].position = p[i].position-position;


}



// void VacuumTrajectory():  This function calculates the analytical solution for a trajectory without the effect of
//								air resistance.
//
void VacuumTrajectory(double dInitVelocity,double dInitAngle, int nPts, TrajectoryPoint *p)
{
	int i;
	double t;
	double Vxo;
	double Vyo;

	Vxo = dInitVelocity*cos(dInitAngle*PI/180.);
	Vyo = dInitVelocity*sin(dInitAngle*PI/180.);

	t = 0.;

	for(i=0;i < nPts; ++i)
	{
		p[i].time = t;
		p[i].position = dcmplx (Vxo*t, t*(Vyo-0.5*G*t)); 
		p[i].velocity = dcmplx (Vxo, Vyo-G*t);
		p[i].acceleration = dcmplx (0., -G);
		t = t + DT;
    }
}


// Accel():  Computes the acceleration (vector) for a spherical projectile moving through a viscous medium.
//				

dcmplx Accel(double time, dcmplx position,dcmplx velocity)
{
	dcmplx acceleration;
	double Cd;
	double density;
	dcmplx drag;
	double dragMagnitude;
	dcmplx unitVelocity;
	dcmplx VERTICAL(0.,1.);
	double vmag;
	double vsq;
	double q;		// dynamic pressure
	double sigma, delta, theta;
	double reynolds;

	vsq = norm(velocity);	// squared magnitude of velocity
	vmag = abs(velocity);	// magnitude of velocity
	unitVelocity = velocity/vmag;

	SimpleAtmosphere(0.001*position.imag(), &sigma, &delta, &theta);

	density = sigma*RHOZERO;

	//printf("Density = %lf\n",density);

	q = 0.5*density*vsq;
	reynolds = density*vmag*DIAM/MetricViscosity(theta);
	//Cd = 0.5;		// drag coefficient for a sphere
	Cd = CdSphere(reynolds);

	//printf("reynolds number = %le, Cd = %lf\n",reynolds, Cd);

	dragMagnitude = Cd*q*SREF;
	drag = -dragMagnitude*unitVelocity;

	acceleration = drag/MASS - G*VERTICAL;

	return acceleration;

}

// BallKutta():  Advances one time step in a trajectory.  Uses a system of four first order differential equations.
//					Uses a fourth-order Runga-Kutta method
//

void BallKutta(TrajectoryPoint p1, double h, TrajectoryPoint *p2)
{
	double t;
	dcmplx x,v,a;
	dcmplx dx1,dx2,dx3,dx4;
	dcmplx dv1,dv2,dv3,dv4;
	double HALF = 0.5, SIXTH = 1./6.;


	t = p1.time;
	x = p1.position;
	v = p1.velocity;

	a = Accel(t,x,v);
	dx1 = h*v;
	dv1 = h*a;

	a = Accel(t+HALF*h, x+HALF*dx1, v+HALF*dv1);
	dx2 = h*(v + HALF*dv1);
	dv2 = h*a;

	a = Accel(t+HALF*h, x+HALF*dx2, v+HALF*dv2);
	dx3 = h*(v + HALF*dv2);
	dv3 = h*a;

	a = Accel(t+h, x+dx3, v+dv3);
	dx4 = h*(v + dv3);
	dv4 = h*a;
	
	p2->time = t + h;
	p2->position = p1.position + SIXTH*(dx1+dx2+dx2+dx3+dx3+dx4);
	p2->velocity = p1.velocity + SIXTH*(dv1+dv2+dv2+dv3+dv3+dv4);

	p2->acceleration = Accel(p2->time, p2->position, p2->velocity);


}

// CdSphere():  Calculates the numerical drag coefficient for a sphere as a function of the Reynolds number.
//				For the low velocities and altitudes that we are concerned with here, Cd is 0.5 for a sphere.
//

double CdSphere(double r)	// r is the Reynolds number
{	
	double d;

	if(r<=0.)
		d = 0.;
	else if (r<=1.)
		d = 24./r;
	else if (r<=400.)
		d = 24*pow(r,-0.646);
	else if (r<= 3.e5)
		d = 0.5;
	else if (r<=2.e6)
		d = 3.66e-4*pow(r,0.4275);
	else
		d = 0.18;
	return d;
}

// MetricViscosity():  Computes viscosity of air using Sutherland's formula
//						Returns viscosity in kg/(meter-sec)
//
double MetricViscosity(double theta)  // temperature/sea-level temperature
{
	double visc;
	double temperature;					// temperature in deg Kelvin

	const double BETAVISC = 1.458e-6;	// viscosity term, N sec/(sq. m sqrt(deg K)
	const double SUTH = 110.4;			// Sutherland's constant, deg K
	const double TZERO = 288.16;		// temperature at sealevel, deg K

	temperature = TZERO*theta;
	visc = BETAVISC*sqrt(temperature*temperature*temperature)/(temperature+SUTH);

	return visc;
}

// SimpleAtmosphere():  calculates the characteristics of the lower atmosphere (This is only correct up to 20 km)
//						INPUT:
//						double altitude in km
//						OUTPUTS:
//						double *sigma  density/sea-level standard density
//						double *delta  pressure/sea-level standard pressure
//						double *theta  temperature/sea-level standard temperature
//
void SimpleAtmosphere(double altitude, double *sigma, double *delta, double *theta)
{
	const double REARTH = 6369.;		// radius of the Earth (km)
	const double GMR = 34.163195;		// gas constant

	double h;		// geopotential altitude

	h = altitude*REARTH/(altitude+REARTH);		// convert geometric to geopotential altitude

	if(h<11.)
	{
		*theta = 1.+(-6.5/288.15)*h;		// troposphere
		*delta = pow(*theta, GMR/6.5);
	}
	else
	{
		*theta = 216.65/288.15;			// stratosphere
		*delta = 0.2233611*exp(-GMR*(h-11.)/216.65);
	}
	*sigma = *delta/ *theta;

}