// my_code.c
//
// Write your code in this file.
//

#include "my_code.h"
#include "ifi_aliases.h"
#include "ifi_utilities.h"
#include "ifi_default.h"
#include "printf_lib.h"

#define BUTTON_REV_THRESH 100
#define BUTTON_FWD_THRESH 140

#define BUTTON_5_TOP()      (RC_in5 > BUTTON_FWD_THRESH)
#define BUTTON_5_BOTTOM()   (RC_in5 < BUTTON_REV_THRESH)
#define BUTTON_6_TOP()      (RC_in6 > BUTTON_FWD_THRESH)
#define BUTTON_6_BOTTOM()   (RC_in6 < BUTTON_REV_THRESH)

void mytest1(void);
void mytest2(void);
void mytest3(void);
void mytest4(void);
void mytest5(void);


// pwm01 controls the steering servo
// pwm02 controls the drive motor ESC (Electronic Speed Controller)


// myCode: ***************************************
// This function is called every 17 milliseconds (about 59 times a second).
// It takes input from the radio controller and sensors, and uses it to
// decide what output to send. (driving the motors)
void my_code(void) {
	
	// set the outputs to neutral at the beginning of every cycle
	pwm01 = 127;
	pwm02 = 127;
	
	//printf("Running\r");
	
	// Choose one of these functions by uncommenting/commenting these lines
	mytest1();
	//mytest2();
	//mytest3();
	//mytest4();
	//mytest5();
	//...
	
}


// This basic routine will drive the car forward/backwards by
// pressing the Channel 5 buttons on the controller.
void mytest1(void) {
	// pwm02 controls the drive motor output.
	// Its value ranges from 0 to 255. A value of 127 is neutral (stopped).
	
	if (BUTTON_5_TOP()) {
		// This gives you max forward
		pwm02 = 255;
	} else if (BUTTON_5_BOTTOM()) {
		// This gives you max reverse
		pwm02 = 0;
	}
	// EXERCISE: Does this work as expected? Check the direction that the wheels
	// are spinning, and if it's reversed, switch the 0 and 255 above.
	
	// EXERCISE: Try making the buttons on channel 6 control the steering, full left and full right.
	// Hint: Use the code above, with the following differences:
	// - Use BUTTON_6_TOP() and BUTTON_6_BOTTOM() instead of BUTTON_5_...()
	// - Control pwm01 instead of pwm02
}

// This routine demonstrates the use of the joystick inputs on the controller.
void mytest2(void) {
	// How to use the joystick inputs:
	//   RC_in1, RC_in2, RC_in3, RC_in4
	// These represent the value of the joystick axes. (They're labelled on the controller.)
	// The values range from 0 to 255, with 127 being neutral.
	
	// Set the drive motor output to the Y-axis of the left joystick
	pwm02 = RC_in3;
	
	// Set the steering output to the X-axis of the right joystick
	pwm01 = RC_in1;         // =FIX ME=
	
	printf("%d\r", pwm01);
	
	// EXERCISE: There's a problem with the code above. Try it out--when
	//           you steer left, the wheels turn right, and vice versa.
	//
	// How can we fix this problem? Try these fixes by replacing the line marked
	// =FIX ME= above.
	
	// Method 1:
	// - Subtract the value from 255. If you have an input of 10, you want to send an output
	//   of 255 - 10, or 245.
	
	// Method 2:
	// - Subtract 127 from the input, make it negative, and add 127 again.
	//
	// - When we subtract 127, zero becomes the neutral value, negative values are reverse
	//   and positive values are forward.
	//
	//   To do this we have to create a new variable with the following code:
	//     int steer = (int)RC_in1 - 127;
	//
	// - Now, we can just make the value negative.
	//     steer = -steer;
	//
	// - We can now add 127 and send it to the output.
	//     pwm01 = steer + 127;
}

// This routine demonstrates how to use a timer to do an action for a certain amount of time.
// In this case we will be driving forward for 2 seconds.
void mytest3(void) {
	// The following variables are "static", which means that they are saved when we leave this function.
	static int sState = 0;	// stores the current state, or status of the robot
	static int sTimer = 0;  // stores the time remaining for the action when it is running
	
	// sState can be:
	//  0: doing nothing, waiting for a button to be pressed
	//  1: button was pressed, we are driving forward for a set amount of time.
	
	if (sState == 0) { // if we're doing nothing, just waiting for the button to be pressed.
		if (BUTTON_5_TOP()) {	// if the button was pressed:
			// Our state is now "running".
			sState = 1;
			// Set the timer to 2 seconds (2000 milliseconds)
			sTimer = 2000/17;
		}
	} else if (sState == 1) { // otherwise, if the timer is running
		// Decrease the timer.
		sTimer--;	// This is shorthand for writing "sTimer = sTimer - 1;"
		
		// If the timer's more than zero, it hasn't run out yet.
		if (sTimer > 0) {
			// We run the motor full forward.
			pwm02 = 0;
		} else {
			// Time's up.
			// We don't run the motor.
			// We set the state back to "doing nothing"
			sState = 0;
		}
	}
}

// Here's some good values to use:
// Right turn: set pwm01 to 66
// Left turn: set pwm01 to 188

// EXERCISE: Now, we're going to make a button that does this:
// 1. Turn the wheels right, while stopped, for 1 second
// 2. Keeping the wheels turned right, drive forward for 1 second
// 3. Turn the wheels left, while stopped, for 1 second
// 4. Keeping the wheels turned left, drive reverse for 1 second
void mytest4(void) {
	static int sState = 0;
	static int sTimer = 0;
	
	// Our possible states for this routine are:
	// 0. waiting for button
	// 1. steering right
	// 2. driving right
	// 3. steering left
	// 4. driving left
	
	if (sState == 0) { // WAITING FOR BUTTON
		if (BUTTON_5_TOP()) {
			// If the button was pressed,
			// Set the next state and set the timer.
			sState = 1;
			sTimer = 1000/17;	// set the timer for 1000 milliseconds
		}
		
	} else if (sState == 1) { // STEERING RIGHT
		sTimer--;
		if (sTimer > 0) {
			// If the timer is still running,
			// turn the steering right
			pwm01 = 66;
		} else {
			// If we're out of time,
			// Set the next state and set the timer.
			sState = 2;
			sTimer = 1000/17;
		}
		
	} else if (sState == 2) { // DRIVING RIGHT
		sTimer--;
		if (sTimer > 0) {
			// Keep the wheels steered right
			pwm01 = 66;
			// Drive the car full forward
			pwm02 = 0+75;
		} else {
			sState = 3;
			sTimer = 1000/17;
		}
		
	} else if (sState == 3) { // STEERING LEFT
		// TODO: Your job
		// This stage just steers the wheels without driving.
		
	} else if (sState == 4) { // DRIVING LEFT
		// TODO: Your job
		// This stage keeps the wheels turned and drives fully forward.
		
	}
}

void mytest5(void) {
}
