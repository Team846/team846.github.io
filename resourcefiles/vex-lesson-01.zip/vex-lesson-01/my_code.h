#ifndef __MY_CODE_H
#define __MY_CODE_H

void allStop(void);
int limit127(int input);

void my_code(void);

#endif
