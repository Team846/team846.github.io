/*****************
** LRTBoomRotate.c
** 
******************/

#include "lrtUtilities.h"
#include "lrtConsoleMapping.h"
#include "lrtResultCodes.h"

static unsigned char gCyclesRemaining;

#define thePWM mRotateBoomPWM

//boom rotates about 180 degrees in 4000 ms (verify)
//arg = angle*4000L/(180L*26.2);


void BoomRotateInitialize(int cycles)
{
	if (cycles > 0)
	{
		gCyclesRemaining = cycles;
		thePWM = 127u+127u/2;	//counter clockwise, reduced speed
	}
	else
	{
		gCyclesRemaining = -cycles;
		thePWM = 127u-127u/4;	//clockwise reduced speed
	}
}

char BoomRotateRun(void)
{
	if (0==gCyclesRemaining)
	{
		thePWM = 127u;
		return kResultSuccess;
	}
	gCyclesRemaining--;
	return kResultRunning;
}

void BoomRotateReset(void)
{
	thePWM = 127u;
	gCyclesRemaining = 0;
}

#undef thePWM
