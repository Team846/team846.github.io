/********************************************************************************
* FILE NAME: LRTClimbStep.c
*
* DESCRIPTION: 
*  contains automation routines for climbing 6" step
*
* Defined leg postitions:
* kLegUp, kLeg6p0, kLeg0p5, kLeg0p0, kLegDown
********************************************************************************/

#include "lrtUtilities.h"
#include "lrtLegs.h"
#include "lrtConsoleMapping.h"
#include "lrtRobotMove.h"
#include "lrtResultCodes.h"
#include "printf_lib.h"
#include "lrtStallDetect.h"

//Raise front leg
//push forward
//lower front leg to level postion
//push forward 1 ft
//lower rear leg to zero position
//push foward & raise leg to zero position



static struct {
	char phase;
	char result;
	int cycles;
	struct { int front,rear; } legPosition;
	char paused;
} gClimb;


//enum ClimbSteps { kLowerLegs=4000/26.2 };
/********************************************************************************/
void ClimbStepInitialize(void)
{
	gClimb.phase=0;
	gClimb.result=kResultRunning;
	gClimb.cycles=0;
	gClimb.paused=0;
	MoveRobotInitialize(0, 1, 50);
	gLegs.front.cmd = gLegs.rear.cmd = 255;	//don't do anything
	
	EnableStallDetect();

}
/********************************************************************************/
void ClimbStepAbort(void)
{
	gClimb.result=kResultNotRunning;
}
/********************************************************************************
  sequence relies on timers and endpoints
  
  1	080 move front leg to 6" & move rear leg to 0.5"
  2	080 move robot forward low speed
  3	080 lower front leg to 0" & lower rear leg to lower limit
  4	080 move robot forward until rear leg hits step
  5	080 raise rear leg to 0"
  6	080 move forward xxx distance
      stop
********************************************************************************/
char ClimbStepRun(void)
{
	char advancePhase;
	extern legs gLegs;
	char robotInPosition;

	enum { kHaltBeforePhase=100 };	//set to 100 if not halting.

	if (gClimb.result)
		return gClimb.result;	//abort if not initialized

if (gLoopTimer.secondsChanged)
	printf("ClimbPhase %d\n",(int) gClimb.phase);

	StallDetect();

	robotInPosition = MoveRobotForward();	//sets drive PWMs if a move-task is setup
	do {
		advancePhase=0;
		switch(gClimb.phase)
		{
			case 0:
				gLegs.front.cmd = kLeg6p0;
				gLegs.rear.cmd = kLeg0p0;
				advancePhase=1;
				break;

			case 1:
				if (gLegs.front.inPosition) //leg in position?
				{
					//butt the robot against the step; 	expect timeout				
					MoveRobotInitialize(1.0*kEncoderTicksPerFt, 2000/26.2, 50);
					advancePhase=1;
				}
				break;

			case 2: //continue w/ rear leg and start moving fwd
				//wait for both robot motion and rear leg
				if (gMotorDriveIsStalled)
				{
					MoveRobotInitialize(0, 100/26.2, 80);	//clear move
					DisableStallDetect();	//End stall detection
					//printf("Stalled\n");	
				}
				if (robotInPosition && gLegs.rear.inPosition)
					advancePhase=1;
				break;

			case 3:	//initiate lift; both legs down and advance robot
				gLegs.front.cmd = kLeg0p0;
				gLegs.rear.cmd = kLegDown;
				MoveRobotInitialize(1.0*kEncoderTicksPerFt, 3000/26.2, 80);
				advancePhase=1;
				break;

			case 4: //perform lift; both legs down and advance robot
				if (gLegs.rear.inPosition && gLegs.front.inPosition)
					advancePhase=1;
				break;
			case 5:
				MoveRobotInitialize(2.0*kEncoderTicksPerFt, 3000/26.2, 80);
				advancePhase=1;
				break;
			case 6:
				if (robotInPosition)
					advancePhase=1;
				break;
			case 7:	//set up = - get robot up step
				//lift rear legs to minus 15 degrees continue fwd until robot stops
				gLegs.rear.cmd = kLegm1p0;
				MoveRobotInitialize(1.0*kEncoderTicksPerFt, 2000/26.2, 50);
				advancePhase=1;
				break;
			case 8:	//get rear wheel up step; hang on trailing leg
				if (gLegs.rear.inPosition)
					advancePhase=1;
				break;
			case 9:
				gLegs.rear.cmd = kLeg0p5;
				gLegs.front.cmd = kLeg0p5;
				MoveRobotInitialize(.5*kEncoderTicksPerFt, 2000/26.2, 50);
				advancePhase=1;
				break;
			case 10:
				if (robotInPosition)
				{
					StopRobotInitialize();
					advancePhase=1;
				}
				break;
			case 11:
				if (StopRobotExecute()==1)
					advancePhase=1;
				break;
			case 12:
				if (gLegs.rear.inPosition && gLegs.front.inPosition)
					advancePhase=1;
				break;
			case 13:
				gClimb.result = kResultSuccess;
				//idle here
				break;
			default:
				gClimb.result = kResultError;
		}	//end of switch

//		if (robotInPosition)
//			printf("robotInPosition %d\n",(int)robotInPosition);

		if (1 && advancePhase)
		{
			printf("Climb Phase %d finished\n",(int) gClimb.phase);
			PrintDistanceFeet();
		}
		if (advancePhase)	//go to next phase w/o going thru main loop
		{
			gClimb.phase++;
			gLegs.rear.inPosition = gLegs.front.inPosition = 0;	//stale result.
			
			if (gClimb.phase >= kHaltBeforePhase)	//For testing
			{
				gClimb.result = kResultNotRunning;
				break;	//exit the main loop
			}
		}
		
		robotInPosition=0;	//clear - stale flag
	} while (advancePhase!=0);

	return gClimb.result;	//0=running; 1=successful completion
}
