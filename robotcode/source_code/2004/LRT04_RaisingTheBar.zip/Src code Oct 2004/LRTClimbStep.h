/********************************************************************************
* FILE NAME: LRTClimbStep.h
*
* DESCRIPTION: 
*  contains automation routines for climbing 6" step
********************************************************************************/

#ifndef __lrtClimbStep_h
#define __lrtClimbStep_h

void ClimbStepInitialize(void);
char ClimbStepRun(void);
void ClimbStepAbort(void);

void DescendStepInitialize(void);
char DescendStepRun(void);
void DescendStepAbort(void);

#endif	//__lrtClimbStep_h
