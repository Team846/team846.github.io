/**************************
* Function mapping for Lynbrook Robotics robot
*
* maps predefined macros to user functions on Lynbrook's console
*
********************************************************/


#ifndef __lrtConsoleMapping_h_
#define __lrtConsoleMapping_h_
#include "ifi_aliases.h"

void LRTConsoleMapping(void);

//Driver controls:
//port 4 is left joystick
//port 3 is right joystick

//port 2 is copilot console
#define mDescendStep	p4_sw_aux1
#define mClimbStep	p4_sw_aux2
#define mLowRate	p4_sw_trig		//reduce gain on joysticks
#define mServoSwitch	p4_sw_top	//for testing

#define mDriverAbort	p3_sw_aux2	//abort any automated routine
#define mRightJoyStickOnly p3_sw_trig



//#define mAbortCopilot	p1_sw_aux1
#define mServoInTest		p4_x

//Copilot controls:
#define mFrontLeg	p2_x
#define mRearLeg	p2_y
#define mRaiseBoomInput	p2_wheel
#define mRotateBoomInput	p2_aux

#define mExtendHookInput p2_sw_trig
#define mRetractHookInput p2_sw_top
#define mWinchForwardInput p2_sw_aux1
#define mWinchReverseInput p2_sw_aux2

//front leg is in ADC 0
//rear leg is on ADC 1

#define mStartOnLeft rc_dig_in09
#define mPhotoDetector !rc_dig_in10

//pwm definitions

#define mWinchRelayFwd relay1_fwd
#define mWinchRelayRev relay1_rev

#define mPWMLeft pwm01
#define mPWMRight pwm02
#define mPWMLegFront pwm03
#define mPWMLegRear pwm04
#define mRotateBoomPWM pwm05	//boom horizontal
#define mRaiseBoomPWM pwm06		//boom vertical
#define mExtendHookPWM pwm07
#define mTeeBallServoRight pwm08
#define mTeeBallServoLeft pwm09

//unsigned char const
#define kA2DLegFront rc_ana_in01
#define kA2DLegRear rc_ana_in02

#define mSwTeeBall	!rc_dig_in11
#define mSwGenericAction	!rc_dig_in12

#define mSwAutonomous	!rc_dig_in13

//Redefinitions if using the EDU board

#ifndef _FRC_BOARD	//then we are using the EDU board
	#undef mSwTeeBall
	#undef mSwGenericAction
	#undef mClimbStep
	#undef mDescendStep
	#undef mDriverAbort
	
	#define mSwGenericAction !rc_dig_in01
	#define mDriverAbort !rc_dig_in02
	#define mSwTeeBall !rc_dig_in03
	#define mClimbStep	!rc_dig_in04
	#define mDescendStep	!rc_dig_in05
#endif // __lrtConsoleMapping_h_
