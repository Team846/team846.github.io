/********************************************************************************
* FILE NAME: LRTDescendStep.c
*
* DESCRIPTION: 
*  contains automation routines for descending 6" step
*
* Defined leg postitions:
* kLegUp, kLeg6p0, kLeg0p5, kLeg0p0, kLegDown
********************************************************************************/

#include "lrtUtilities.h"
#include "lrtLegs.h"
#include "lrtConsoleMapping.h"
#include "lrtRobotMove.h"
#include "lrtResultCodes.h"
#include "printf_lib.h"

//Raise front leg
//push forward
//lower front leg to level postion
//push forward 1 ft
//lower rear leg to zero position
//push foward & raise leg to zero position



static struct {
	char phase;
	char result;
	int cycles;
	struct { int front,rear; } legPosition;
	char paused;
} gDescend;


//enum DescendSteps { kLowerLegs=4000/26.2 };
/********************************************************************************/
void DescendStepInitialize(void)
{
	gDescend.phase=0;
	gDescend.result=kResultRunning;
	gDescend.cycles=0;
	gDescend.paused=0;
	MoveRobotInitialize(0, 1, 50);
	gLegs.front.cmd = gLegs.rear.cmd = 255;	//don't do anything
}
/********************************************************************************/
void DescendStepAbort(void)
{
	gDescend.result=kResultNotRunning;
}
/********************************************************************************
  sequence relies on timers and endpoints
	wrong discription - for climb, not descend. -- rewrite  
  1	080 move front leg to 6" & move rear leg to 0.5"
  2	080 move robot forward low speed
  3	080 lower front leg to 0" & lower rear leg to lower limit
  4	080 move robot forward until rear leg hits step
  5	080 raise rear leg to 0"
  6	080 move forward xxx distance
      stop
********************************************************************************/
char DescendStepRun(void)
{
	char advancePhase;
	extern legs gLegs;
	char robotInPosition;

	enum { kHaltBeforePhase=100 };	//set to 100 if not halting early.

	if (gDescend.result)
		return gDescend.result;	//abort if not initialized

if (gLoopTimer.secondsChanged)
	printf("DescendPhase %d\n",(int) gDescend.phase);

	do {
		advancePhase=0;
		robotInPosition = MoveRobotForward();	//sets drive PWMs if a move-task is setup

		switch(gDescend.phase)
		{
			case 0:
				gLegs.front.cmd = kLeg0p0;
				gLegs.rear.cmd = kLegm1p0;
				advancePhase=1;
				break;

			case 1:	//move wheels into position
				if (gLegs.rear.inPosition && gLegs.front.inPosition) //leg in position?
					advancePhase=1;
				break;
			
			case 2:	//back off platform
				MoveRobotInitialize(-1.0*kEncoderTicksPerFt, 1000/26.2, 50);
				advancePhase=1;
				break;
			case 3:	//overhanging; lower wheels and go forward small amount against platform
					// to define position
					if (robotInPosition) 
					{
						gLegs.rear.cmd = kLegDown;	
						gLegs.front.cmd = (kLeg0p0+kLeg6p0)/2;
						MoveRobotInitialize(+0.25*kEncoderTicksPerFt, 1000/26.2, 50);
						advancePhase=1;
					}
				break;
			case 4:
				if (gLegs.rear.inPosition && gLegs.front.inPosition && robotInPosition)
					advancePhase=1;
				break;

			case 5:	//init move to ride off platform
				MoveRobotInitialize(-2.0*kEncoderTicksPerFt, 2000/26.2, 50);
				advancePhase=1;
				break;
			case 6:
				if (robotInPosition)
					advancePhase=1;
				break;
			case 7:	//Level wheels and we are done.
				gLegs.front.cmd = kLeg6p0;
				gLegs.rear.cmd = kLeg0p5;
				advancePhase=1;
				break;
			case 8:	
				if (gLegs.rear.inPosition && gLegs.front.inPosition)
					advancePhase=1;
				break;
				
			case 9:
				gDescend.result = kResultSuccess;
				//idle here
				break;
			default:
				gDescend.result = kResultError;
		}	//end of switch

		if (robotInPosition)
			printf("robotInPosition %d\n",(int)robotInPosition);

		if (1 && advancePhase)
		{
			printf("DescendPhase %d finished\n",(int) gDescend.phase);
			PrintDistanceFeet();
		}
		if (advancePhase)
		{
			gDescend.phase++;
			gLegs.rear.inPosition = gLegs.front.inPosition = 0;	//stale result.

			if (gDescend.phase >= kHaltBeforePhase)	//For testing
			{
				gDescend.result = kResultNotRunning;
				break;	//exit the main loop
			}
		}
	} while (advancePhase!=0);

	return gDescend.result;	//0=running; 1=successful completion
}
