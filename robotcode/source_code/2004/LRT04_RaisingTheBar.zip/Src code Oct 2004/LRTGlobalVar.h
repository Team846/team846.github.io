/**********

LRT globals.h

************/
//to allocate globals, 
//define globals before #include'ing this headerfile

#ifdef Globals
#define scope	//to be nothing
#elif
#define scope extern 
#endif //Globals
