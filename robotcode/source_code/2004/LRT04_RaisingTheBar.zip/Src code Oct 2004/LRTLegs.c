/*****************
** LRTBoomElevate.c
** 
******************/

#include "lrtUtilities.h"
#include "lrtConsoleMapping.h"
#include "lrtLegs.h"
#include "ifi_utilities.h"
#include "printf_lib.h"
#include "lrtRobotSim.h"


/*******************************************************************************
* FUNCTION NAME: mapLegPos
* Maps analog input from A/D convertor to 0-254
* specifically, maps the range of inputs possible from the
* leg potentiometers, which is limited to about 612 to 1018 by hardware stops.
***********************************************************************************************/
int mapLegPos(int legPos)
{
	enum in {a=612,b=1018};	//modify '0' for lower range of leg
//	enum in {a=512,b=1023};	//modify '0' for lower range of leg
	enum out {w=0,x=254};
	
	int mappedLegPos;

	if (legPos <= a) mappedLegPos = w;
	else if (legPos >= b) mappedLegPos = x;
	else
		mappedLegPos = (legPos-a)*(long)x/(b-a);	//w is 0
	//	mappedLegPos = ((legPos-a)*(long)x + (b-legPos)*(long)w) / (b-a);
		
	return mappedLegPos;
}
/*****************************************************************/


/*******************************************************************************
* FUNCTION NAME: LRTFrontRearLegMapping
* range of console inputs is 0-254
* range of analog inputs is 0-1023
*******************************************************************************/
//data: Front/Rear
// up: 1017 1015
//ground: 796 775
// 5-5/8=925 6-1/8=945 (front)
// rear 6-1/8
// leg is 8" axle to axle; extra height is diff in wheel sizes.
void LRTFrontRearLegMapping(void)
{
	OperateLegWithLimits(mRearLeg,  &mPWMLegRear,  gLegs.rear.position);
	OperateLegWithLimits(mFrontLeg, &mPWMLegFront, gLegs.front.position);
}
/***********************************************************************************************/
void OperateLegWithLimits(unsigned char legInput, unsigned char *pwm, unsigned char legPosition)
{

	enum legPower {pUp=127L,pDown=127L};
			//deadband not used --see code below
	enum limits { lowerLimit=0L, upperLimit=254L, deadband=10L };
	int distance= (int) legInput - (int) legPosition;
	
	if (distance < 0)
		distance = -distance;	//abs()
	
	
	if (distance < deadband)
		*pwm=127;
	else if (legPosition <legInput )		//wanting to go up?
	{
		if ((int)legPosition >(int)upperLimit) *pwm=127;	//already beyond limit
		else *pwm = 127L-pUp;
	}
	else //wanting to go down?
	{
		if ((int)legPosition < (int)lowerLimit)
			*pwm=127; 	//already beyond limit
		else
			*pwm = 127L +pDown;
	}
	if (255==legInput)
		*pwm=127;	//neutral input; safety
}
/***********************************************************************************************/
/* Get the positions once at the beginning of the 26.2ms loops */
void GetLegPositions(void)
{
#ifndef SIM	// Normal code
	gLegs.rear.position = mapLegPos(Get_Analog_Value(kA2DLegRear));
	gLegs.front.position = mapLegPos(Get_Analog_Value(kA2DLegFront));
#else // simulation code
	GetSimulatedLegPositions();
#endif
}
/***********************************************************************************************/

//Used in Automation routines: ClimbStep/DescendStep/Autonomous

void Automated_OperateLegs(void)
{
	mRearLeg=gLegs.rear.cmd;
	mFrontLeg=gLegs.front.cmd;

	LRTFrontRearLegMapping();
	
	gLegs.rear.inPosition = (127u==mPWMLegRear);
	gLegs.front.inPosition = (127u==mPWMLegFront);

//diagnostic
	if (0==(0x07 & gLoopTimer.loopCount))	//print 1 per 8 cycles
	{
		PrintLegPosition();
//		printf("front:Pos,cmdLegs = %d,%d -> %dpwm\n", (int) gLegs.front.position,(int) gLegs.front.cmd, (int) mPWMLegFront);
//		printf("rear:Pos,cmdLegs = %d,%d -> %dpwm\n", (int) gLegs.rear.position,(int) gLegs.rear.cmd, (int) mPWMLegRear);
	}
}
/***********************************************************************************************/


void CheckLockOnLegControls(void)
{
	if (!gLegs.front.locked)
		gLegs.front.lastUnlockedValue = mFrontLeg;
	else
	{
		if (20 < mAbsDiff(mFrontLeg, gLegs.front.lastUnlockedValue))
			gLegs.front.locked = 0;
		else
			mFrontLeg=255;	//locked value
	}

	if (!gLegs.rear.locked)
		gLegs.rear.lastUnlockedValue = mRearLeg;
	else
	{
		if (20 < mAbsDiff(mRearLeg, gLegs.rear.lastUnlockedValue))
			gLegs.rear.locked = 0;
		else
			mRearLeg=255;	//locked value
	}

	//implicit else 'mRearLeg' & 'mFrontLeg' pass unchanged
}
