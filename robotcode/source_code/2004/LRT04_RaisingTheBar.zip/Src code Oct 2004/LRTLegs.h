/********************************************************************************
* FILE NAME: LRTLegs.h
*
* DESCRIPTION: 
*
********************************************************************************/


#ifndef __lrtLegs_h
#define __lrtLegs_h
//void OperateLegWithLimits(unsigned char armInput, unsigned char armPos, unsigned char *pwm);
void OperateLegWithLimits(unsigned char legInput, unsigned char *pwm, unsigned char legPosition);
void LRTFrontRearLegMapping(void);
void GetLegPositions(void);
int mapLegPos(int legPos);

void CheckLockOnLegControls(void);
void Automated_OperateLegs(void);


//data: Front/Rear
// up: 1017 1015
//ground: 796 775
// 5-5/8=925 6-1/8=945 (front)
// rear 6-1/8
// leg is 8" axle to axle; extra height is diff in wheel sizes.

//#define kLegUp  1010
//#define kLeg6p0  950
//#define kLeg0p5  600
//#define kLeg0p0  780
//#define kLegm3p0  600
//#define kLegDown 512

//values mapped to {0,254} to match user input
#define kLegUp  250
#define kLeg6p0  211
#define kLeg0p5  127
#define kLeg0p0  90
#define kLegm1p0  65
#define kLegm3p0  25
#define kLegDown 0


typedef struct
{
	unsigned char position;
	unsigned char cmd;
	unsigned char lastUnlockedValue;
	char inPosition: 1;
	char locked:	1;	//don't allow user control until input differs
						//from lastUserValue
} leg;

typedef struct
{
	leg front;
	leg rear;	
} legs;

extern legs gLegs;

//gLegPosition.front -> f.position


//typedef struct LEGS { unsigned char front, rear; } LEGS;
#endif	//__lrtLegs_h
