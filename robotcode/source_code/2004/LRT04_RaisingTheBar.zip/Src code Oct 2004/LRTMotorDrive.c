#include "lrtUtilities.h"
#include "ifi_aliases.h"
#include "OIFeedback.h"
#include "lrtTypes.h"
#include "lrtMotorDrive.h"

int limitMotorDrive(char vIn, int velocity);

/*********
 *
 * Velocity is measured in ticks per 2*26.2ms
 * EMF is voltage from 0-127 where 127=12.5V
 * kKvMainDrive is scaled by 512 so that 
 * EMF =  motor's maxVelocity ( in ticks/2*26.2ms) X kKvMainDrive / 512
 * 
 * Then, limit the max difference in app
 * These values are computed in an Excel Spreadsheet.
 * D.Giandomenico
 ************/ 
 
  

//  when multiplied by velocity (ticks per 2*26.2ms)
//
// Could we give a temporary boost?



//pwm is applied power on range of {-127,127}
//returns pwm on {0,254}

//#define UseOBSOLETE
#ifdef UseOBSOLETE
#error
char TorqueDrive(char TorqueIn, char velocity ) {}

unsigned char limitDriveMotorCurrent(char pwmIn, char velocity )
{
	short long motorEMF;
	int motorResistiveVoltage;
	motorEMF = (velocity * (long) kKvMainDrive256);
	motorEMF = mDivideByPowerOf2(motorEMF,8);	//divide by 256	= 2^8

	motorResistiveVoltage = pwmIn - motorEMF;

	motorResistiveVoltage = LimitRange(motorResistiveVoltage, -kMaxVr, kMaxVr);
	pwmIn = motorEMF + motorResistiveVoltage;
	return 127 + pwmIn;
}

//crude stop -- set pwms to neutral
#else //UseOBSOLETE
/********************************************************************************
* FUNCTION: limitDriveMotorCurrent
*
* DESCRIPTION: 

* All voltages scaled such on range {0-127}<->{0,Vbattery}

* Vr=resistive voltage on motor, giving rise to a current Vr/Ir
* EMF - motor's electromotive potential
*
*
* define 'drivePCM' as % of full scale on range {-127,127} <-> {-100%,100%}
* Va = %power * Vbattery - |%power| *EMF
*
* drivePC is drive percent = PWM-127.  {-100%,100%} <-> {-127,127}
********************************************************************************/

/*******************************************************************************/
unsigned char limitDriveMotorCurrent(char voltagePWM, char velocity)
{
	int motorResistiveVoltage;
	extern char gDriveLimitedFlag;
	gDriveLimitedFlag=0;	//used to indicate output < desired input

	if (0==voltagePWM) return 127;	//save some time

	motorResistiveVoltage = MotorResistiveVoltage(voltagePWM, velocity);
	
	if (mAbsolute(motorResistiveVoltage) > kMaxVr)
	{
		//limit current
		voltagePWM = (kMaxVr * (int) 127) / motorResistiveVoltage;
		gDriveLimitedFlag=1;
	}

	return 127 + voltagePWM;
}
/*******************************************************************************/
unsigned char TorqueDrive(char TorqueIn, char velocity )
{
	union {
		struct { char lsb,msb; };
		int i;
	} motorEMFs;
	int drive;
	char reversePowerFlag;
	
	extern char gDriveLimitedFlag;
	gDriveLimitedFlag=0;	//used to indicate output < desired input

	if (0==TorqueIn)
		return 127u;	//save alot of work...

	motorEMFs.i = velocity * (int) kKvMainDrive256;	//result is in motorEMFs.msb

	if (TorqueIn > 0)
		reversePowerFlag=0;		//save sign of TorqueIn
	else
	{
		reversePowerFlag=1;		//save sign of TorqueIn
		TorqueIn=-TorqueIn;	//abs value
		motorEMFs.msb = -motorEMFs.msb;	//Applied V reversed relative to EMF
	}

	//TorqueIn is positive &  motorEMFs.msb<127 always ==> Drive is positive;
	// '127' is full battery voltage opposing EMF
	drive = TorqueIn * (int) kMaxVr / (127 - (int) motorEMFs.msb);
	
	//check if limit reached and signal Operator Interface
	if (drive > 127)
	{
		drive=127;	//limit output
		gDriveLimitedFlag=1;
	}	
	
	if (reversePowerFlag) drive = -drive;	//restore sign
	return drive+127u;
}

/********************************************************************************
* FUNCTION: MotorResistiveVoltage
*
* DESCRIPTION: 
*  computes applied voltage - motorEMF
*  returns value on approx range {-256,+256}, which exceeds range of char
********************************************************************************/
int MotorResistiveVoltage(char voltagePWM, char velocity)
{
	int motorEMF;
	int result;
	motorEMF = 	velocity * (int)kKvMainDrive32;
	motorEMF = mDivideByPowerOf2(motorEMF,5);	//divide by 32
	
	if (voltagePWM < 0)
		motorEMF = -motorEMF;	//applied voltage reversed relative to EMF

	result = voltagePWM * (127L-motorEMF)/127;
	return result;
}
/********************************************************************************/

#ifdef CUT
unsigned char limitDriveMotorCurrent(char drivePC, char velocity )
{

	short long motorEMF;
	int motorResistiveVoltage;
	char quadrant1_3;

	if (drivePC>=0)
#error

	motorEMF = (long) velocity * (long) kKvMainDrive256;
	motorEMF = mDivideByPowerOf2(motorEMF,8+7);	//divide by 256	= 2^15


	motorResistiveVoltage = pwmIn - motorEMF;

	motorResistiveVoltage = LimitRange(motorResistiveVoltage, -kMaxVr, kMaxVr);
	pwmIn = motorEMF + motorResistiveVoltage;

}
#endif //CUT



#endif //UseOBSOLETE
void DriveMotorCoast(void)
{
	pwm01=pwm02=127;	//set left/right pwm to neutral
}



//EXPERIMENTAL
void limit(int motorResistiveVoltage, char *dynamicLimit);
void limit(int motorResistiveVoltage, char *dynamicLimitArg)
{
	char limit = *dynamicLimitArg;

	if (motorResistiveVoltage<0)
		motorResistiveVoltage = -motorResistiveVoltage;

	if (motorResistiveVoltage > kMaxVr) //invoke limit when input >kMaxVr
	{
		if (motorResistiveVoltage > limit)
		{
			if (limit > kMaxVr)
				limit--; //go down to a min of kMaxVr
			motorResistiveVoltage = limit;
		}
	}
	else if (limit<127)	// relax the dynamic limit to it's max value
		limit++; //go up to a max of 127
	*dynamicLimitArg = limit;	//copy back the limit
}	
