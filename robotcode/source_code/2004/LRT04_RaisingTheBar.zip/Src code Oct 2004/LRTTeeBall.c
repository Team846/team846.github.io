/*****************
** LRTTeeBall.c
** 
******************/

#include "lrtUtilities.h"
#include "lrtConsoleMapping.h"
#include "printf_lib.h"
#include "lrtResultCodes.h"

enum servoPositions { servoPos1=0, servoPos2=254 };
//move teeball servo
//servo speed is 150ms/60 degrees at 6V
#define kTeeBallServoCycles 180*150L/(60L*26.2)

static unsigned char gCyclesRemaining=0;

static void ReleaseTeeBallLatch(void);

void TeeBallStartSwing(void)
{
	gCyclesRemaining = 180*150L/(60L*26.2);
	
//	ReleaseTeeBallLatch();	//cou
}

char TeeBallRun(void)
{
	if (0==gCyclesRemaining)
	{
		TeeBallReset();
		return kResultSuccess;	//success
	}
	
	ReleaseTeeBallLatch();
	gCyclesRemaining--;
	return kResultRunning;
}

void TeeBallReset(void)
{
	mTeeBallServoLeft = 254;
	mTeeBallServoRight = 0;
	gCyclesRemaining = 0;
}
static void ReleaseTeeBallLatch(void)
{
	mTeeBallServoLeft = 0;
	mTeeBallServoRight = 254;
}
