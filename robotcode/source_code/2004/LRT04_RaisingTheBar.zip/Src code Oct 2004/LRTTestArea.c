//called from Initialization in UserRoutines for testing code
//only use when debugging
#include "lrtUtilities.h"
#include "lrtRobotSim.h"
#include "lrtMotorDrive.h"
#include "ifi_aliases.h"
#include "lrtConsoleMapping.h"
#include "lrtLegs.h"

#define TestArea 0
#if TestArea
void LRTJoystickMapping(void);
//void testTimers(void);

void testArea(void)
{
	long turnDelta = 45;
	long ticks;
	char i;
	char result;
	unsigned char pwmx;
	unsigned char pwmy;
	unsigned char pwmz;
	char test;
	int input; 
	int output;
	int turnETicks;
//	pwm01=pwm02=254;

	pwmx = 10;
	pwmy = 8;
	pwmz = mAbsDiff(pwmx,pwmy);
	pwmz = mAbsDiff(pwmy,pwmx);
#if CUT
	for (i=0; i<100; i++)
	{
		GetEncoderPositionNow();
		SIMmotorDrive();
	}
	pwm01=pwm02=127;

	while (1)
	{
		GetEncoderPositionNow();
		SIMmotorDrive();
	}

	LRTJoystickMapping();
#endif //CUT
	TestAreaActive();	//generate compiler warning.
}
//without a prototype, a call to this will generate a
// a non-fatal warning, which serves as a reminder
int TestAreaActive(void){}

#else
	void testArea(void){}
#endif //TestArea
