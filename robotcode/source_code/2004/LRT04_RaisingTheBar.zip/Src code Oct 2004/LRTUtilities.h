/********************************************************************************
* FILE NAME: LRTUtilities.h
*
*
********************************************************************************/

#ifndef __lrtUtilities_h_
#define __lrtUtilities_h_

#include "ifi_default.h"
#include "lrtTypes.h"
#define kPI	3.14159
#define kAxleLengthInch 32
#define kEncoderTicksPerFt	83.82
#define kEncoderTicksPerFt256	83.82*256L	//use care to wrap in '()' when dividing!
#define kEncoderTicksPerFtSmallW	207.8
#define kEncoderTicksPerFtSmallW256	207.8*256L	//use care to wrap in '()' when dividing!

//#define kEncoderTicksPerFt	67.1
//#define kEncoderTicksPerFt256	67.1*256L	//use care to wrap in '()' when dividing!

	//about 3.1 ticks per degree -- very sensitive!
#define kTurnTicksPerDegree (long)kAxleLengthInch*kEncoderTicksPerFt*2*kPI/(360*12)
#define kTurnTicksPerDegree256 (long)(kAxleLengthInch*kEncoderTicksPerFt256*2*kPI/(360*12))

#define kMaxMotorVel 23		//Velocity in ticks/26.2ms at max RPM
#define kFast 0				//use this to go as fast as possible

#define kNeutral 127u

void testArea(void);


//mSign(A) returns the sign +/-1 or zero of argument 'A'
#define mSign(A) ((A)>0 ? 1 : ((A)<0 ? -1:0))
#define mAbsolute(A) ((A)<0?-(A):(A))
#define mAbsDiff(A,B) ((A)>(B)?((A)-(B)):((B)-(A)))
#define mDivideByPowerOf2(AAA,pwr2) ((AAA)>=0 ? ((AAA)>>(pwr2)) : -(-(AAA)>>(pwr2)))
#define mModPowerOf2(AAA,pwr2) ((AAA > 0) ? ((1L<<pwr2)-1)&(AAA) : -(((1L<<pwr2)-1)&(-(AAA))))
#define mIsPowerOf2(AAA) (0==(((AAA)-1)&(AAA)))


typedef struct { long left, right; } LeftRightPair;

//short long's are 24 bit
typedef struct {
	volatile short long posNow;		//instantaneous position updated via interrupt
	short long position;			//copy of positon at beginning of loop
	short long oldPosition;
	short long projectedPos;	//where we expect to be at next tick given current Vel.
	int velocity;
	int oldVelocity;
} encoder;

extern encoder EncoderRight, EncoderLeft;
//allocated in user_routines.c



struct Clock {
	unsigned long ms;
	unsigned int seconds;
} extern volatile gClock; //allocated in interrupts.c

//use to control printf's
typedef struct {
		int oldSeconds;
		char secondsChanged;
		char loopCount;
} SlowLoopTiming;
extern SlowLoopTiming gLoopTimer;	//alloc. in LRTUtilities.c

typedef struct {
	union
	{ 
		 bitid bitselect;          /*txdata.LED_byte1.bitselect.bit0*/
		 unsigned char data;       /*txdata.LED_byte1.data*/
	} LED_byte1,LED_byte2;
	unsigned char user_byte;
} OI_LED_User_bytes;


int LimitRange(long a, int low, int high);
unsigned char removePWMDeadband(unsigned char pwm);
unsigned char addDeadband(unsigned char pwm);
unsigned char addLargeDeadband(unsigned char pwm);
void calibrateInput(unsigned char *in, unsigned char lowValue);
void RemoveAllPWMDeadbands(void);

void GetEncoderPositionNow(void);

void AllStop(void);

void UpdateSlowLoopTimers(void);

void TeeBallStartSwing(void);
char TeeBallRun(void);
void TeeBallReset(void);

//mElevate() returns #26.2ms cycles corresponding to the angle in degrees
//estimate turn of 180 degrees in 4000ms -- verify this
//note: Motor speeds are not symmetrical.
//positive is up, negative is down
#define mElevate(_ANGLE_) _ANGLE_*4000L/(180L*26.2)
void BoomElevateInitialize(int cycles);
char BoomElevateRun(void);
void BoomElevateReset(void);

//mRotate returns #26.2ms cycles corresponding to the angle in degrees
//estimate turn of 180 degrees in 4000ms -- verify this
//note: Motor speeds are not symmetrical.
//positive is CCW, negative is CW
#define mRotate(_ANGLE_) _ANGLE_*4000L/(180L*26.2)
void BoomRotateInitialize(int cycles);
char BoomRotateRun(void);
void BoomRotateReset(void);

void AutonomousAbort(void);
void AutonomousInitialize(void);
void AutonomousReset(void);
char AutonomousRun(void);
char AutonomousStatus(void);


void PrintDistanceFeet(void);
void PrintVelocity(void);
void PrintTimeMs(void);
void PrintLegPosition(void);
void PrintPWMs(void);



#endif //__lrtUtilities_h_
