#include "lrtUtilities.h"
#include "lrtRobotMove.h"

#include "interrupts.h"
#include "lrtConsoleMapping.h"
#include "printf_lib.h"
#include "OIFeedback.h"
#include "lrtResultCodes.h"
#include "lrtStallDetect.h"
#include "lrtLegs.h"

//void LRTautonomous(void);
char MoveRobot(void);

//typedef struct { long left, right; } Point;
	
/***********************************************************************************/
struct autonomous {
	char returnValue;
	char alreadyRan;	//prevent running more than once
	char taskPhase;
	char stallCount;	//number of times robot has stalled in routine
}	pAutonomous={kResultNotRunning,0,0,0};


//called to allow multiple autonomous runs
void AutonomousReset(void)
{
	pAutonomous.alreadyRan = 0;	
}

char AutonomousStatus(void)
{
	return pAutonomous.returnValue;	
}
void AutonomousAbort(void)
{
	pAutonomous.returnValue=kResultNotRunning;	
	pAutonomous.alreadyRan = 1;	
}
/*********************************************************/
//set outputs to neutral-- bug in Master controller causes stale data
//on pwm's when switched to autonomous.
void AutonomousInitialize(void)
{
	if (pAutonomous.returnValue==kResultRunning)
		return;	//do nothing
	if (pAutonomous.alreadyRan)	//must be cleared before running again.
	{
		pAutonomous.returnValue = kResultError;
		return;
	}
//	pAutonomous.alreadyRan=1;	//prevent running twice
	pAutonomous.returnValue=kResultRunning;	//prevent running twice
	pAutonomous.stallCount=0;	//prevent running twice
	pAutonomous.taskPhase=0;
	EnableStallDetect();

//gMotorDriveIsStalled=1;		//DEBUG

//	AllStop();
//	TeeBallReset();
	mWinchRelayFwd=mWinchRelayRev=0;
	
	gLegs.front.cmd = gLegs.rear.cmd = 255;	//don't do anything

}

/***********************************************************************************/
char AutonomousRun(void)
{
	enum { kHaltBeforePhase = 100 };	//for debugging; stop at phase #
	char advancePhase;
	char result;
	int turnETicks;	//turn measured in encoder ticks (R-L) so that positive = CCW (left turn)
	int distance;
	static char stallReturnPhase = -1;
	static unsigned char wait = 0;	//wait this number of cycles; max 255, or about 6 sec
	
if (gLoopTimer.secondsChanged)
		printf("Autonomous phase: %d\n", (int)pAutonomous.taskPhase);

	if (pAutonomous.returnValue != kResultRunning)
	{
printf("Auto Not Running\n");
		return pAutonomous.returnValue;
	}
//	User_Byte5=EncoderLeft.velocity;
//	User_Byte6=EncoderRight.velocity;

//	mPWMLeft=mPWMRight=127;	//motors are at neutral unless otherwise commanded
	
//	TeeBallRun();	//if TeeBallInitialized, then TeeBallRun() will execute
	
	if (gMotorDriveIsStalled)
	{
		printf("Stall\n");
		DisableStallDetect();	//clear the condition

	//	pAutonomous.taskPhase = 20;
		pAutonomous.taskPhase = 50;	//no recovery; just abort
	}

	do {
		result = advancePhase=0;	//clear advancePhase command and result
		OIShowPhaseWithLEDs(pAutonomous.taskPhase);

		if (wait)
		{
			wait--;
			continue;	//skip loop	(advancePhase is 0, so will come back next cycle)
		}
		switch (pAutonomous.taskPhase) {
			case 0:		//initialization; set first destination
				advancePhase=1;
				gLegs.rear.cmd=kLeg0p5;  //lower rear legs
if (0)
{ //skip turn for debugging
	pAutonomous.taskPhase=3;
	break;
}				
		//		printf("\Starting autonomous mode. t=%dms", (int)gClock.ms);
				printf("Starting On %s Side\n", mStartOnLeft ? "Left":"Right");
			
				if (mStartOnLeft) //leftside
					distance = (2.0*kEncoderTicksPerFt);
				else	//rightside
					distance = (2.0*kEncoderTicksPerFt);
				
				MoveRobotInitialize(distance, 3000/26.2, 127);

				break;

			case 1:	//Do the move in previous case
				result = MoveRobotForward();

				if (result) 
				{	//initialize for next move -- turn
					advancePhase=1;
					//	kTurnTicksPerDegree is about 3.1
					// so we only have about 1/3 degree resolution
					if (mStartOnLeft)	//need to turn right (CW)
					{
						turnETicks = -44 * kTurnTicksPerDegree;
					//	turnETicks = -44.3 * kTurnTicksPerDegree;
					//	turnETicks = -43 * kTurnTicksPerDegree; last match need a little more
					//	turnETicks = -40 * kTurnTicksPerDegree;
						TurnRobotInitialize(turnETicks, (3000/26.2), 80, 30);
					}
					else	//need to turn left (CCW)
					{
						turnETicks = 44 * kTurnTicksPerDegree;
					//	turnETicks = 44.3 * kTurnTicksPerDegree;
					//	turnETicks = 40; * kTurnTicksPerDegree //CCW	
						TurnRobotInitialize(turnETicks, (3000/26.2), 30, 80);
					}
					printf("Target Turn: %d (10x)\n", (int) (turnETicks*10/(kTurnTicksPerDegree)));
				}
				break;
			case 2:	//NB: jumped to from "STALL RECOVERY" below
				result = TurnRobot();	//do the move in the last case--turn
				if (result)
				{
					printf("\nCompleted turn; result=%d\n", (int) result);
					advancePhase=1;
				}
				break;
			case 3:
			
				//wait=(2000/26.2);
				if (RobotStopped(2))
					advancePhase=1;
				break;
			case 4:
//				StopRobotInitialize();
				advancePhase=1;
				break;
			case 5:
//				if (StopRobotExecute()==1)
					advancePhase=1;
				break;
			case 6:	//init 1st 3 feet of long run
				advancePhase=1;	//advance phase and setup next move

				distance = 2 * kEncoderTicksPerFt;
//				MoveRobotInitialize(distance, 10000/26.2, 127);
//				MoveRobotInitialize(distance, 10000/26.2, 100);
				MoveRobotInitialize(distance, 3000/26.2, 80);

//				gLegs.front.cmd=kLeg0p5;
//				gLegs.rear.cmd=kLeg0p5;
				break;
			case 7:
				result = MoveRobotForward();	//do the move in the last case-
				if (result)
					advancePhase=1;
				break;
			case 8:	//init long run
				advancePhase=1;	//advance phase and setup next move

			//	distance = 12.5 * kEncoderTicksPerFt;
				distance = 11.5 * kEncoderTicksPerFt;
//				MoveRobotInitialize(distance, 10000/26.2, 127);
//				MoveRobotInitialize(distance, 10000/26.2, 100);
				MoveRobotInitialize(distance, 7000/26.2, 80);

				gLegs.front.cmd=kLeg0p5;	//lower front leg
			//	gLegs.rear.cmd=kLeg0p5;

				break;
			case 9:	//start long move and look for photo detector
				if (mPhotoDetector)
				{
					advancePhase=1;
					TeeBallStartSwing();
				}
				else
				{
					result = MoveRobotForward();	//do the move in the last case-
					if (result)
					{
						TeeBallStartSwing(); //JUST Swing 
						printf("Completed long move\n");
						advancePhase=1;	//advance phase and setup next move
					}
				}
				break;
			case 10:
//				StopRobotInitialize();
				if (RobotStopped(0))
					advancePhase=1;
				break;
			case 11:
			
//				if (0 || StopRobotExecute()==1)
				{
//pAutonomous.taskPhase=14;	//skip backup
					advancePhase=1;
//					wait = (1500/26.2);	//wait before continuing
				}
	
				break;
			case 12:	//got tee ball.  Now lets back up a bit.
				MoveRobotInitialize(-8 * kEncoderTicksPerFt, 7000/26.2, 70);
				advancePhase=1;
				break;

			case 13:
				result = MoveRobotForward();	//do the move in the last case-
				if (result) advancePhase =1;
				break;
			case 14:
				printf("finished autonomous mode. t=%dms", (int)gClock.ms);
				advancePhase=1;
				pAutonomous.returnValue = kResultSuccess;
				break;



			//STALL RECOVERY during turn
			case 20:	//reverse
				gLegs.front.cmd=kLeg6p0;	//legs back up; don't climb wall!

				distance = -1 * kEncoderTicksPerFt;
				MoveRobotInitialize(distance, 2000/26.2, 80);
				advancePhase=1;
				break;
			case 21:
				result = MoveRobotForward();	//do the move in the last case-
				if (result) advancePhase=1;
				break;
			case 22:
				if (mStartOnLeft)	//need to turn CW (more power on left)
					turnETicks = -3 * kTurnTicksPerDegree;
				else
					turnETicks = 3 * kTurnTicksPerDegree;
				TurnRobotInitialize(turnETicks, (3000/26.2), 127, 127);
				//jump back to complete turn
				pAutonomous.taskPhase = 2;
				break;
			//End of STALL RECOVERY					



			default:
				if (pAutonomous.returnValue == kResultRunning)
					pAutonomous.returnValue = kResultNotRunning;
				break;	//quit;


		}	//end of switch


		if (result==kResultTimeOut)
		{	
			pAutonomous.returnValue = kResultTimeOut;
			printf("Timeout\n");
		}
		if (advancePhase)	//diagnostics
		{
			printf("\nEnd of AutoPhase=%d\n",(int)pAutonomous.taskPhase);
			PrintTimeMs();
			PrintDistanceFeet();
			PrintVelocity();
		}
		if (advancePhase)
		{
			if (pAutonomous.taskPhase >= kHaltBeforePhase)	//For testing
			{
				pAutonomous.returnValue = kResultNotRunning;
				break;	//exit the main loop
			}

			pAutonomous.taskPhase++;
		}
	} while (advancePhase);

	if (kResultRunning != pAutonomous.returnValue)
		pAutonomous.alreadyRan = 1;

	return pAutonomous.returnValue;
}
/*****************************************************************************************/

