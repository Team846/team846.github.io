#include "LRTUtilities.h"
#include "interrupts.h"
#include "LRTConsoleMapping.h"
#include "printf_lib.h"

void LRTautonomous(void);
char MoveRobot(void);



char StopAt(long left,long right, char speedx, char speedy);
char StopAt(long left,long right, char speedx, char speedy) { return 1; }   //dummy function


typedef struct { long left, right; } Point;
	


void LRTautonomous(void)
{
	static char taskPhase=0;
	char advancePhase;
	int result;
	int turnDelta;
	static int cycles=-1;	//how many 26.2 cycles have elapsed
		// total # of cycles in 15 seconds (15*1000/26.2)=
	
	cycles++;
	UpdateSlowLoopTimers();
	GetEncoderPositionNow(); //call early in routine
	
	User_Byte5=EncoderLeft.velocity;
	User_Byte6=EncoderRight.velocity;
	

	//first leg is 3.6 ft 
	//turn 45 degrees right (if starting on left)
	//continue 18.6ft

	//initialize and advance taskPhase.
	//don't put in switch()-- no need to waste time
	do {
		advancePhase=0;	//clear advancePhase command
		OIShowPhaseWithLEDs(taskPhase);
		if (gLoopTimer.secondsChanged)
		{
			printf("phase=%d, time=%dms\n",(int)taskPhase,(int)gClock.ms);
		//	printf("LPos=%d  RPos=%d, LVel=%d, RVel=%d\n",
		//	(int)	EncoderLeft.position, (int)EncoderRight.position,
		//	(int)	EncoderLeft.velocity,(int) EncoderRight.velocity);
		}
		switch (taskPhase) {
			case 0:		//initialization; set first destination
				advancePhase=1;
				
		//		printf("%3d ", (int) mStartOnLeft);
		//		printf("\Starting autonomous mode. t=%dms", (int)gClock.ms);
		//		if (mStartOnLeft) printf("Starting On Left Side\n");
		//		else printf("Starting on Right Side\n");
			
				//setup first move
				gTaskLW.phase = gTaskRW.phase = 0;	//set task phase to initialize	
				
				gTaskLW.destination = 3.5*kEncoderTicksPerFt;
				gTaskRW.destination = 3.5*kEncoderTicksPerFt;
				gTaskLW.velocity=gTaskRW.velocity=64;	//max speed
				gTaskLW.maxCycles = gTaskRW.maxCycles = (2000/26.2);	//2 seconds to complete any task
				gTaskLW.maxPWM = gTaskRW.maxPWM = 30;
				break;

			case 1:	//Do the move in last case
			//	if (0!= (result=MoveRobot()) advancePhase=1;
				result = (1 || MoveRobot());
	
				if (result) 
				{ //initialize for next move -- turn
					enum turnSpecs {innerTurnRadius=0, theta=45,maxOuterVelocity=18}; //inches; theta>=0
					advancePhase=1;	//advance phase and setup next move
					
					//to turn 'theta' degrees, the outside wheel must turn more than inside wheel:
					//That is, Xout-Xin = d*theta*2Pi/360 where d is the axle length
					turnDelta = (theta*kTurnTicksPerDegree256)>>8;

					if (mStartOnLeft) {	//turn 45 degrees right
						printf("Right Turn %dticks\n", (int)turnDelta);
						//right is inside wheel
						gTaskLW.phase = gTaskRW.phase = 0;	//set task phase to initialize
						gTaskRW.destination = innerTurnRadius*kEncoderTicksPerFt/12;
						gTaskLW.destination = gTaskRW.destination+turnDelta;
						
						gTaskLW.velocity=maxOuterVelocity;
						gTaskRW.velocity=maxOuterVelocity*(long)innerTurnRadius/(innerTurnRadius+kAxleLengthInch);
						gTaskLW.maxPWM = 127;
						gTaskRW.maxPWM = 127L*innerTurnRadius/(innerTurnRadius+kAxleLengthInch);
					} else
					{	//turn 45 left.  //left is inside wheel
						gTaskLW.destination = innerTurnRadius*kEncoderTicksPerFt/12;
						gTaskRW.destination = gTaskRW.destination+turnDelta;
						
						gTaskRW.velocity=maxOuterVelocity;
						gTaskLW.velocity=maxOuterVelocity*(long)innerTurnRadius/(innerTurnRadius+kAxleLengthInch);
						gTaskRW.maxPWM = 127;
						gTaskLW.maxPWM = 127L*innerTurnRadius/(innerTurnRadius+kAxleLengthInch);
					}
				}
				break;
			case 2:
				result = (0 || MoveRobot());	//do the move in the last case--turn
				if (result) {
					printf("Completed turn\n");
					advancePhase=1;	//advance phase and setup next move
					gTaskLW.phase = gTaskRW.phase = 0;	//set task phase to initialize
					gTaskLW.maxPWM = gTaskRW.maxPWM = 30;
					gTaskLW.velocity=gTaskRW.velocity=64;	//max speed
					gTaskLW.maxCycles = gTaskRW.maxCycles = (4000/26.2);	//2 seconds to complete any task

					gTaskLW.destination = 20*kEncoderTicksPerFt;
					gTaskRW.destination = 20*kEncoderTicksPerFt;

				}
				break;
			case 3:
				result = (1 || MoveRobot());	//do the move in the last case-
				if (result)
				{
					printf("Completed long move\n");
					advancePhase=1;	//advance phase and setup next move
				}
				break;
			case 4:
				printf("finished autonomous mode. t=%dms", (int)gClock.ms);
				advancePhase=1;
			default:
				break;	//idle here when finished


		}	//end of switch
		if (advancePhase) taskPhase++;
	} while (advancePhase);
	
	//check for pwms != 127
	if (pwm03 != 127) { printf("pwm03=%d\n",(int)pwm03), pwm03=127;}
	if (pwm04 != 127) { printf("pwm04=%d\n",(int)pwm04), pwm04=127;}
}
/*****************************************************************************************/

char MoveRobot(void)
{
	MoveDriveMotor(&gTaskLW);
	MoveDriveMotor(&gTaskRW);
//	return ((gTaskRW.returnValue!=0));
	//abort task of either times out
	if (2==gTaskLW.returnValue || 2==gTaskRW.returnValue)
	{
		//timeout
		printf("timeout\n");
		*gTaskLW.pwm=*gTaskRW.pwm=127;	//stop motors
		return 2;
	}
	else	//both motors must finish task
		return ((gTaskLW.returnValue!=0) && (gTaskRW.returnValue!=0));
}

void MoveDriveMotor(task1Wheel *t)
{
	enum direction { forward,reverse };
	char EMF;	//motor EMF
	char advancePhase;
	do {
		advancePhase=0;
		t->cyclesRemaining--;
		switch (t->phase)
		{
			case 0:	//initialization
				advancePhase=1;
				t->initialDirection = (t->destination>=0 ? forward:reverse);
				t->destination += t->e->position;	//add on the encoder's current postion to
					//get an absolute value for the destination position
				t->cyclesRemaining = t->maxCycles; //ticks to timeout
				t->returnValue=0;
				break;

			case 1:
				// does distance remaining have same sign as the initial direction ?
				if ((t->e->position < t->destination) != (forward==t->initialDirection))
				{
					//passed destination
					advancePhase=1;
					*t->pwm = 127;
				}
				else
					//should control velocity here. Oh well
					*t->pwm = limitDriveMotorCurrent(
						(forward == t->initialDirection ? t->maxPWM : -t->maxPWM),t->e->velocity);		

					break;
			case 2:
				t->returnValue = 1;
				break;
			default:
				t->returnValue=-1;		//paramater error
		}	//end switch

		if (advancePhase) t->phase++;

		if (0==t->cyclesRemaining && 0==t->returnValue)
		{
			*t->pwm=127;
			 t->returnValue=2;	//timeout
		}
	} while (advancePhase);
}
