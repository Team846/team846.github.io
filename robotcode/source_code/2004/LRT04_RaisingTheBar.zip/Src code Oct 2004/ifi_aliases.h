/********************************************************************************
* FILE NAME: ifi_aliases.h	
*
* DESCRIPTION: selects which header file based on project macro _FRC_BOARD
*
********************************************************************************/
#ifndef __ifi_aliases_h_


#ifdef _FRC_BOARD
	#include "ifi_aliasesFRC.h"
#else
	#include "ifi_aliasesFRC.h"
	#undef __ifi_aliases_h_
	
	//patch up inconsistencies
	#undef rc_dig_in01
	#undef rc_dig_in02
	#undef rc_dig_in03
	#undef rc_dig_in04
	#undef rc_dig_in05
	#undef rc_dig_in06
	#undef rc_dig_in07
	#undef rc_dig_in08
	#undef rc_dig_in09
	#undef rc_dig_in10
	#undef rc_dig_in11
	#undef rc_dig_in12
	#undef rc_dig_in13
	#undef rc_dig_in14
	#undef rc_dig_in15
	#undef rc_dig_in16

	#undef rc_dig_out01
	#undef rc_dig_out02
	#undef rc_dig_out03
	#undef rc_dig_out04
	#undef rc_dig_out05
	#undef rc_dig_out06
	#undef rc_dig_out07
	#undef rc_dig_out08
	#undef rc_dig_out09
	#undef rc_dig_out10
	#undef rc_dig_out11
	#undef rc_dig_out12
	#undef rc_dig_out13
	#undef rc_dig_out14
	#undef rc_dig_out15
	#undef rc_dig_out16
	
	#undef battery_voltage
	#include "ifi_aliasesEDU.h"


#endif



#endif	//__ifi_aliases_h_
