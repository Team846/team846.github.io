/*****************
** LRTBoomElevate.c
** 
******************/

#include "lrtUtilities.h"
#include "lrtConsoleMapping.h"
#include "lrtResultCodes.h"

static unsigned char gCyclesRemaining;

#define thePWM mRaiseBoomPWM

//boom rotates about 180 degrees in 4000 ms (verify)
//arg = angle*4000L/(180L*26.2);


void BoomElevateInitialize(int cycles)
{
	if (cycles > 0)
	{
		gCyclesRemaining = cycles;
		thePWM = 254;	//full speed up
	}
	else
	{
		gCyclesRemaining = -cycles;
		thePWM = 0;		//full speed down
	}
}

char BoomElevateRun(void)
{
	if (0==gCyclesRemaining)
	{
		thePWM = 127;
		return kResultSuccess;	//success
	}
	gCyclesRemaining--;
	return kResultRunning;
}

void BoomElevateReset(void)
{
	thePWM = 127;
	gCyclesRemaining = 0;
}

#undef thePWM
