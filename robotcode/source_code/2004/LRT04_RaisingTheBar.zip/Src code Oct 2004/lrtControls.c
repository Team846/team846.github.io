/********************************************************************************
* FILE NAME: lrtControls.c
*
* DESCRIPTION: 
*
********************************************************************************/
#include "ifi_aliases.h"
#include "ifi_default.h"
#include "lrtConsoleMapping.h"
#include "printf_lib.h"
#include "lrtUtilities.h"
#include "lrtMotorDrive.h"
#include "lrtLegs.h"
#include "lrtResultCodes.h"
#include "lrtClimbStep.h"

#define TORQUE_DRIVE 1		//for user control only; see lrtRobotMove.c too


enum activeRoutines { kNoRoutine, kRoutineAutonomous, kRoutineClimb, kRoutineDescend };
static struct {
	char returnValue;
	char activeRoutine;
} automationState = { kResultNotRunning, kNoRoutine };

/*******************************************************************************
* FUNCTION NAME: LRTConsoleMapping
* PURPOSE:       Performs the default mappings of inputs to outputs for the
*                Robot Controller.
* CALLED FROM:   this file, Process_Data_From_Master_uP routine
* ARGUMENTS:     none
* RETURNS:       void
*******************************************************************************/
void LRTJoystickMapping(void);
static void LRTBoomMapping(void);
static void LRTAutomationRoutines(void);
static void TimerHookExtend(char forceExpire);
static void TimerBoomElevate(char forceExpire);
static void TimerBoomRotate(char forceExpire);

void LRTConsoleMapping(void)
{
	static struct {
		char autonomousLastCycle:1;
	} modeFlag={0};
	
	//check if UserMode started (immediately following autonomousMode)
	if (!autonomous_mode && modeFlag.autonomousLastCycle)
	{
		TimerHookExtend(1);	//freeze control
		TimerBoomElevate(1);
		TimerBoomRotate(1);
		//abort autonomous?
		//any other initialization?
	}
	modeFlag.autonomousLastCycle = autonomous_mode;


//	if (gLoopTimer.secondsChanged) printf("Slow26msLoop\n");
if (mSwTeeBall) printf("SwTeeball\n");
if (mSwGenericAction) printf("ActionSw\n");
	LRTAutomationRoutines();
	//return value in global 'automationState'
	if (automationState.returnValue != kResultRunning)	//lockout joystick and legs if automation
	{
		LRTJoystickMapping();

		CheckLockOnLegControls();
		LRTFrontRearLegMapping();
	}
	else
	{
		gLegs.front.locked = gLegs.rear.locked = 1;
		Automated_OperateLegs();
	}


	LRTBoomMapping();

	if (mServoSwitch || mSwTeeBall)
	{
		//mTeeBallServo = mServoInTest;
		TeeBallStartSwing();
	}

	//operate only while timer not expired; allows predetermined operation times
	// for each function.
	TimerHookExtend(0);	
	TimerBoomElevate(0);
	TimerBoomRotate(0);
}
/*******************************************************************************/

void LRTJoystickMapping(void)
{
	//joystick output at extremes: stick back=0; fwd=254; stick left=254; right=0
	int LeftInput;
	int RightInput;
	int Forward;
	int Turn;

	//port 4 is left joystick
	//port 3 is right joystick
	p4_y = addDeadband(p4_y);	//port 4 is left joystick
	p3_y = addDeadband(p3_y);	//port 3 is right joystick
	p3_x = addDeadband(p3_x);	// used as x if 1 joystick
	
	p4_y -= 127; //shift from {0,254} to {-127,+127}  (although p#_y is unsigned)
	p3_y -= 127;
	p3_x -= 127;
	
	
	if (mRightJoyStickOnly)	//need to mix inputs
	{
		//reduce gain on 'turn'
		//coerce to signed char, then to int
		//reduce 'x' to control turn --try it out.
		LeftInput =  (int)(char) p3_y - (int)(char)p3_x*2;
		RightInput = (int)(char) p3_y + (int)(char)p3_x*2;
	}		
	else
	{
		LeftInput =  (char) p4_y; //coerce from unsigned to signed char
		RightInput = (char) p3_y;
		
	}	

	if (mLowRate)
	{
		Forward = (LeftInput + RightInput)*3/4;
		Turn = (LeftInput - RightInput);
		
		LeftInput = (Forward + Turn)/2;
		RightInput = (Forward - Turn)/2;
	}

//User_Byte1=LeftInput;
//User_Byte2=RightInput;

	LeftInput = LimitRange(LeftInput,-127,127);
	RightInput = LimitRange(RightInput,-127,127);

#if TORQUE_DRIVE
	mPWMLeft=TorqueDrive(LeftInput,EncoderLeft.velocity);
	mPWMRight=TorqueDrive(RightInput,EncoderRight.velocity);
#else
	mPWMLeft=limitDriveMotorCurrent(LeftInput,EncoderLeft.velocity);
	mPWMRight=limitDriveMotorCurrent(RightInput,EncoderRight.velocity);
#endif


}

/******************************************************************************/
static void LRTBoomMapping(void)
{
	int input;
	
	//Change direction and adjust gain of horizontal rotation
	//winodw motor drives faster in one direction than the other
	//adjust gain depending on direction.
	//+pwm is counterclockwise
	//-pwm is clockwise


//	input = 127-(int)addDeadband(mRotateBoomInput);
	input = 127-(int) mRotateBoomInput;
	if (input < 0) input = input/4;	//CW 
	else input = input/2; //CCW
	//add more deadband and eliminate small input
	if (input>= -10 && input <= 10) input =0;
//	mRotateBoomPWM=removePWMDeadband(input+127);
	mRotateBoomPWM = input+127;
	

//Elevate boom
	input = mRaiseBoomInput- (int) 127;
	input = mDivideByPowerOf2(input,1);	//reduce gain
	mRaiseBoomPWM = addDeadband(input+127);
//	mRaiseBoomPWM = addDeadband(mRaiseBoomInput);
	

	//extend hook
	if (mExtendHookInput)
		mExtendHookPWM = 0;	//full on 
	else if (mRetractHookInput)
		mExtendHookPWM = 254;
	else
		mExtendHookPWM = 127;
		
	//winch
	//safety - can only retract if both switches are pressed 
	//consider routine to turn on and off (pseudo PWM)
	mWinchRelayFwd = mWinchRelayRev = 0;
	if (mWinchForwardInput)		//wind winch
		mWinchRelayFwd=1;
	else if (mWinchReverseInput)	//unwind winch
		mWinchRelayRev=1;	//motor in reverse releases winch.
}
/******************************************************************************/
void RemoveAllPWMDeadbands(void)
{
	mPWMLeft=		removePWMDeadband(mPWMLeft);
	mPWMRight=		removePWMDeadband(mPWMRight);
	mPWMLegFront=	removePWMDeadband(mPWMLegFront);
	mPWMLegRear=	removePWMDeadband(mPWMLegRear);
	mRotateBoomPWM=	removePWMDeadband(mRotateBoomPWM);
	mRaiseBoomPWM=	removePWMDeadband(mRaiseBoomPWM);
	mExtendHookPWM=	removePWMDeadband(mExtendHookPWM);
	//don't remove deadbands from servos
}	
/******************************************************************************/

static void LRTAutomationRoutines(void)
{
	//Abort automation routines
	if (mDriverAbort || competition_mode) //competition mode is 'disable' switch
	{
		switch (automationState.activeRoutine)
		{
			case kRoutineAutonomous:
				printf("AUTO Abort\n");
				AutonomousAbort();
				if (competition_mode)	//competition mode is 'disable' switch
					AutonomousReset();	//allow another run after disable released.
				break;
			case kRoutineClimb:
				ClimbStepAbort();
				break;
			case kRoutineDescend:
				DescendStepAbort();
				break;
			default:
				break;
		}
		automationState.activeRoutine = kNoRoutine;
		automationState.returnValue = kResultNotRunning;
		return;
	}

	//Initialize (start) automation routines
	if (automationState.returnValue != kResultRunning)
	{
		if (!autonomous_mode && !mSwAutonomous)
			AutonomousReset();
		
		if (autonomous_mode || mSwAutonomous)
		{
			if (mSwAutonomous) AutonomousReset();	//allow more than one run
			AutonomousInitialize();
			if (kResultRunning == AutonomousStatus())	//sucessful init? Then proceed.
			{
				automationState.activeRoutine = kRoutineAutonomous;
				automationState.returnValue = kResultRunning;
			}
		}
		else if (mClimbStep)
		{
			ClimbStepInitialize();
			automationState.activeRoutine = kRoutineClimb;
			automationState.returnValue = kResultRunning;
		}
		else if (mDescendStep)
		{
			DescendStepInitialize();
			automationState.activeRoutine = kRoutineDescend;
			automationState.returnValue = kResultRunning;
		}
	}	//End of Initialize  automation routines


	//Run automation routines
	if (automationState.returnValue==kResultRunning)
	{

		switch (automationState.activeRoutine)
		{
			case kRoutineAutonomous:
				automationState.returnValue = AutonomousRun();
				break;
			case kRoutineClimb:
				automationState.returnValue = ClimbStepRun();
				break;
			case kRoutineDescend:
				automationState.returnValue = DescendStepRun();
				break;
			default:
				break;
		}
	}
}


/*******************************************************************************
* FUNCTION NAME: TimerHookExtend
* PURPOSE:       Limits time of operation; reset when output is neutral
* ARGUMENTS:     none
* RETURNS:       void
*******************************************************************************/
void TimerHookExtend(char forceExpire)
{
#define kUpCycles (6250/26.2)	
#define kDownCycles (6250/26.2)
#define thePWM	mExtendHookPWM
	static int timerUp=0, timerDown=0;	//timers; expired initially
	
	if (forceExpire)
	{
		timerUp=timerDown=0;
		thePWM=127u;
		return;
	}

	if (127u == thePWM)
	{
		timerUp = kUpCycles;		//reset timers
		timerDown = kDownCycles;
	}
	else if (thePWM < 127u)
	{
		if (timerUp>0) timerUp--;	//go; timer runs
		else thePWM = 127u;	//stop
	}
	else //thePWM < 127u
	{
		if (timerDown>0) timerDown--;
		else thePWM = 127u;
	}
#undef kUpCycles
#undef kDownCycles
#undef thePWM
}
/*******************************************************************************/
void TimerBoomElevate(char forceExpire)
{
#define kUpCycles (6250/26.2)	
#define kDownCycles (5500/26.2)
#define thePWM	mRaiseBoomPWM

	static int timerUp=0, timerDown=0;	//timers; expired initially
	
	if (forceExpire)
	{
		timerUp=timerDown=0;
		thePWM=127u;
		return;
	}
	
	if (127u == thePWM)
	{
		timerUp = kUpCycles;		//reset timers
		timerDown = kDownCycles;
	}
	else if (thePWM > 127u)
	{
		if (timerUp>0) timerUp--;	//go; timer runs
		else thePWM = 127u;	//stop
	}
	else //thePWM < 127u
	{
		if (timerDown > 0) timerDown--;
		else thePWM = 127u;
	}
#undef kUpCycles
#undef kDownCycles
#undef thePWM
}
/*******************************************************************************/
void TimerBoomRotate(char forceExpire)
{
#if CUT
#define kUpCycles (4000/26.2)		//CCW
#define kDownCycles (4000/26.2)		//CW
#define thePWM	mRotateBoomPWM

	static int timerUp=0, timerDown=0;	//timers; expired initially
	
	if (forceExpire)
	{
		timerUp=timerDown=0;
		thePWM=127u;
		return;
	}
	
	if (127u == thePWM)
	{
		timerUp = kUpCycles;		//reset timers
		timerDown = kDownCycles;
	}
	else if (thePWM > 127u)
	{
		if (timerUp>0) timerUp--;	//go; timer runs
		else thePWM = 127u;	//stop
	}
	else //thePWM < 127u
	{
		if (timerDown > 0) timerDown--;
		else thePWM = 127u;
	}
#undef kUpCycles
#undef kDownCycles
#undef thePWM
#endif //CUT
}
/*******************************************************************************/
#if CUT
void testTimers(void)
{
	struct {
		int i;
		unsigned char thePWM;
	} tt2;

		mRaiseBoomPWM=127;
		TimerBoomElevate(0);

	for (tt2.i=0; tt2.i<8000/26.2; tt2.i++)
	{
		mRaiseBoomPWM=0;
		TimerBoomElevate(0);
		if (mRaiseBoomPWM==127) break;	
	}
	mRaiseBoomPWM=127;
	TimerBoomElevate(0);	
	for (tt2.i=0; tt2.i<8000/26.2; tt2.i++)
	{
		mRaiseBoomPWM=254;
		TimerBoomElevate(0);	
	}

	mRaiseBoomPWM=254;
	TimerBoomElevate(1);	
	TimerBoomElevate(0);	
	TimerBoomElevate(0);	
	mRaiseBoomPWM=127;
	TimerBoomElevate(0);	
	TimerBoomElevate(0);	

}
#endif //CUT
