#include "LRTUtilities.h"
#include "LRTConsoleMapping.h"
#include "LRTLegs.h"
#include "ifi_utilities.h"


//in "legs.h"
legs gLegs;

#ifdef CUT
struct {
	unsigned char front;
	unsigned char rear;
} gLegPosition;


//static LEGS cmd = {255,255};		//the positions to command legs to move
		//OperateLegWithLimits() won't move legs with input of 255
//static LEGS inPosition = {0,0};	//boolean

// set in MotorDrive.c & lrtUtilties.h

#endif //CUT

char gDriveLimitedFlag=0;	//used to indicate output < desired input
