/********************************************************************************
* FILE NAME:  
*
* DESCRIPTION: 
*
********************************************************************************/


#ifndef __lrtMotorDrive_h
#define __lrtMotorDrive_h

#define kKvMainDrive256 (4.76*256L)	//voltage 
#define kKvMainDrive32 (4.76*32L)	//voltage 
#define kMaxVr  72	//max voltage across motor branch resistance




//unsigned char limitDriveMotorCurrent(char voltagePWM, char velocity, boolean *currentLimited);
unsigned char limitDriveMotorCurrent(char voltagePWM, char velocity);
unsigned char TorqueDrive(char TorqueIn, char velocity );
int MotorResistiveVoltage(char voltagePWM, char velocity);


extern char gDriveLimitedFlag;
#define mDriveLimited() gDriveLimitedFlag


#endif	//__lrtMotorDrive_h
