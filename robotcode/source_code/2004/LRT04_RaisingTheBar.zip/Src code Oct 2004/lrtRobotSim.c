/********************************************************************************
* FILE NAME: lrtRobotSim.c
*
* DESCRIPTION: simulate robot functions
* given input PWM's, 
********************************************************************************/

#include "lrtRobotSim.h"
#include "lrtMotorDrive.h"
#include "lrtUtilities.h"
#include "lrtLegs.h"
#include "lrtConsoleMapping.h"
#include "printf_lib.h"

	//the change in the number of ticks per 26.2 ms for each 0.1V ('1' in pwm)
	//see excel spreadsheet 'program constants'
#define kDeltaEncoderTicks2_16 ((0.02827 * 256 * 256L))

#ifdef SIM

/* 
what are the state variables?
 * velocity
 * position
 * we can use the encoder values
 * T = (Vin-EMF) * K - drag
 * T = I * w (akin to F=ma) so vn = M * a * deltaT + vo
 * newTicks = vn
*/


/********************************************************************************
* FUNCTION: SIMmotorDrive
*
* DESCRIPTION: 
*  updates the Encoder positions as a function of the left and right pwm values
*  uses a model to simulate the motors driving the mass of the robot
*   computes the resistive voltage on the motor as a function of it's current Vel
*   and applied voltage

* Limitations:
*  Doesn't include any drag
*  Doesn't include any cross-coupling between the left and right drives
*  Model based on a single motor on each side, although constants are
*   based on aggregate of CIM and FP combined.
* May overestimate traveled distance, since a change in vel only contributes vel/2
*  in distance.  However, since instantaneous velocity is based on 
********************************************************************************/
void SIMmotorDrive(void)
{

	static struct { int left,right; } deltaVelRemainder = {0,0};	//store fractional ticks
#define kDrag256 ((int)256*.5)	//reduction in Vel/cycle
	struct {
		long voltage;
	} left,right;

	long deltaVelocity;
	int velocity256;	//scaled by 256
	int velocityAvg;	//scaled by 256

	left.voltage =  MotorResistiveVoltage(mPWMLeft -127, EncoderLeft.velocity);
	right.voltage = MotorResistiveVoltage(mPWMRight-127, EncoderRight.velocity);

	//compute the change in velocity due to the 'resistive' voltage applied to the motor
	//perform the calc. with greater precision and save the fractional ticks for the next loop.

//left side
	deltaVelocity = left.voltage * kDeltaEncoderTicks2_16;
	deltaVelocity = mDivideByPowerOf2(deltaVelocity,8);		//divide by 256; discard
	deltaVelocity += deltaVelRemainder.left;
	
//effect of drag -rudimentary at best
	velocity256 = EncoderLeft.velocity*(int)256 + deltaVelocity;
	if (velocity256 > kDrag256) velocity256 -= kDrag256;
	else if (velocity256 < -kDrag256) velocity256 += kDrag256;
	else velocity256=0;

	deltaVelRemainder.left = mModPowerOf2(velocity256,8);	// remainder 256	
	EncoderLeft.posNow += mDivideByPowerOf2(velocity256,8); // divide by 256
	


//right side
	deltaVelocity = right.voltage * kDeltaEncoderTicks2_16;
	deltaVelocity = mDivideByPowerOf2(deltaVelocity,8);		//divide by 256; discard
	deltaVelocity += deltaVelRemainder.right;

//effect of drag -rudimentary at best
	velocity256 = EncoderRight.velocity*(int)256 + deltaVelocity;
	if (velocity256 > kDrag256) velocity256 -= kDrag256;
	else if (velocity256 < -kDrag256) velocity256 += kDrag256;
	else velocity256=0;

	deltaVelRemainder.right = mModPowerOf2(velocity256,8);	// remainder 256
	EncoderRight.posNow += mDivideByPowerOf2(velocity256,8); // divide by 256
}




/********************************************************************************
* FUNCTION: GetSimulatedLegPositions()/SimulateLegMotors()
*
* DESCRIPTION: Simulate operation of the front and rear lifting legs
*
* If the front PWM >127, increment the leg position
* If the front PWM < 127 decrement the leg position
* To improve precision, position is stored as {0,4095}
*  and must be mapped to {0-1023} which is simply done by
*  a 2 bit right shift (>>2) ...effectively same but faster
* than a divide by 4.
* improved precision allows for better control of up/down rates
* since otherwise we are contrained to an integer/26.2ms
********************************************************************************/
static char pPrintChange = 1;	//flag to print

static struct { int front,rear; } pLegSim = { 4096,4096 }; //4096, 4096 };
void GetSimulatedLegPositions(void)
{
	extern char pPrintChange;	//private flag; set in it SimulateLegMotors()

	gLegs.rear.position = mapLegPos(pLegSim.rear >> 2);
	gLegs.front.position = mapLegPos(pLegSim.front >> 2);
	if (SIM && pPrintChange && gLoopTimer.secondsChanged)
	{
		pPrintChange=0;	//clear flag
		printf("ADC LegPos (Front/Rear) %d / %d",
			(int) gLegs.front.position, (int) gLegs.rear.position);
		PrintTimeMs();
	}
}


void SimulateLegMotors(void)
{
//rates are calculated as 
//  (total travel in ticks)/(seconds for full travel * 38 cycles/sec)
// for 5 seconds to travel range of 512*4, gives 11/cycle
// (Range of legs due to hard limits is from about 500 to 1023) 

#define kUpRate 4	//11
#define kDownRate 4	//11
	char changed;
	extern char pPrintChange;	//private flag; used to print in GetSimulatedLegPositions()
	
	changed =1;
	//power < 127 ==> go up; power>127 ==>go down
	if (mPWMLegFront<127 && pLegSim.front<(4096-kUpRate))
		pLegSim.front += kUpRate;
	else if (mPWMLegFront>127&& pLegSim.front>=kUpRate)
		pLegSim.front -= kDownRate;
	else changed=0;
	pPrintChange |= changed;
	
	changed=1;
	if (mPWMLegRear<127 && pLegSim.rear<(4096-kUpRate))
		pLegSim.rear += kUpRate;
	else if (mPWMLegRear>127&& pLegSim.rear>=kUpRate)
		pLegSim.rear -= kDownRate;
	else changed=0;
	pPrintChange |= changed;


}


#endif //SIM defined
