/********************************************************************************
* FILE NAME: lrtRobotSim.h
*
* DESCRIPTION: 
*
********************************************************************************/


#ifndef __lrtRobotSim_h
#define __lrtRobotSim_h

void SIMmotorDrive(void);
void GetSimulatedLegPositions(void);	//called from lrtLegs.c
void SimulateLegMotors(void);
#endif	//__lrtRobotSim_h
