/********************************************************************************
* FILE NAME: lrtStallDetect.c
*
* DESCRIPTION: detects condition where motor is powered forward,
* but there is no motion.
*
********************************************************************************/

#include "lrtStallDetect.h"
#include "lrtUtilities.h"
#include "lrtConsoleMapping.h"

/********************************************************************************
* FUNCTION: 
*
* DESCRIPTION: 
*
********************************************************************************/

/*******************************************************************************/

char gMotorDriveIsStalled=0;

#define kCyclesToCheckForStall	5

struct {
	char detectActive;
	char poweredLastCycle;
	char timeOutCycles;
} pStall;
/*******************************************************************************/
void EnableStallDetect(void)
{
	pStall.detectActive=1;
	gMotorDriveIsStalled=0;
	pStall.timeOutCycles =0;		//cycles to check for stall
}
/*******************************************************************************/
void DisableStallDetect(void)
{
	EnableStallDetect();	//reset
	pStall.detectActive=0;	//correct value
}
/*******************************************************************************/
/* Must be called at end of cycle to check if power was applied */

void StallDetect_SaveDrivePWMs(void)
{
	if (mPWMLeft > kNeutral+30 || mPWMLeft < kNeutral-30 ||
		mPWMRight > kNeutral+30 || mPWMRight < kNeutral-30)
		pStall.poweredLastCycle=1;
	else
		pStall.poweredLastCycle=0;
}
/*******************************************************************************/
void StallDetect(void)
{
	if (!pStall.detectActive) return;
	if (gMotorDriveIsStalled) return;	//can only be cleared by calling Enable/DisableStallDetect()

	if (pStall.poweredLastCycle && 0==EncoderRight.velocity && 0==EncoderLeft.velocity)
	{
		if (pStall.timeOutCycles >= kCyclesToCheckForStall)
			gMotorDriveIsStalled=1;		//robot is stalled.			
		else
			pStall.timeOutCycles++;
	}
	else
		pStall.timeOutCycles = 0;
}
/*******************************************************************************/
