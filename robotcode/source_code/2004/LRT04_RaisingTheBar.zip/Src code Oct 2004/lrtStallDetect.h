/********************************************************************************
* FILE NAME: lrtStallDetect.h
*
* DESCRIPTION: 
*
********************************************************************************/


#ifndef __lrtStallDetect_h
#define __lrtStallDetect_h

void EnableStallDetect(void);
void DisableStallDetect(void);
void StallDetect_SaveDrivePWMs(void);
void StallDetect(void);

extern char gMotorDriveIsStalled;

#endif	//__lrtStallDetect_h


