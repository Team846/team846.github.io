/********************************************************************************
* FILE NAME: 
*
* DESCRIPTION: 
*
********************************************************************************/


#ifndef __lrtTypes_h
#define __lrtTypes_h
typedef char boolean;

#define true 1
#define false 0

#endif	//__lrtTypes_h
