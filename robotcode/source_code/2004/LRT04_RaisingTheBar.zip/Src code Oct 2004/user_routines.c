/*******************************************************************************
* FILE NAME: user_routines.c <FRC VERSION>
*
* DESCRIPTION:
*  This file contains the default mappings of inputs  
*  (like switches, joysticks, and buttons) to outputs on the RC.  
*
* USAGE:
*  You can either modify this file to fit your needs, or remove it from your 
*  project and replace it with a modified copy. 
*
*******************************************************************************/
#include "ifi_aliases.h"
#include "ifi_default.h"
#include "ifi_utilities.h"
#include "user_routines.h"
#include "printf_lib.h"
#include "interrupts.h"

#include "lrtUtilities.h"
#include "lrtConsoleMapping.h"
#include "lrtLegs.h"
#include "OIFeedback.h"
#include "lrtRobotMove.h"
//#include "lrtMotorDrive.h"
#include "lrtRobotSim.h"
//#include "lrtClimbStep.h"
#include "lrtStallDetect.h"

//#ifdef _SIMULATOR
//	#define Getdata(A) ;
//	#define Putdata(A) ;
//#endif


encoder EncoderRight={0,0,0,0}, EncoderLeft={0,0,0,0};
task1Wheel gTaskLW = {&EncoderLeft,&(mPWMLeft)};
task1Wheel gTaskRW = {&EncoderRight,&(mPWMRight)};
robotTask gTask;


/*******************************************************************************
*
*	FUNCTION:		User_Autonomous_Code()
* 
*******************************************************************************/
void User_Autonomous_Code(void)
{
	//Do nothing. Autonomous handled in LRTAutomationRoutines()
}

/*******************************************************************************
* FUNCTION NAME: User_Initialization
* PURPOSE:       This routine is called first (and only once) in the Main function.  
*                You may modify and add to this function.
* CALLED FROM:   main.c
*******************************************************************************/
void User_Initialization (void)
{
	rom const	char *strptr = "IFI User Processor Initialized ...";
	testArea();	//call this routine for debugging code snippets

#ifdef _FRC_BOARD
	Set_Number_of_Analog_Channels(SIXTEEN_ANALOG);    /* DO NOT CHANGE! */
#else
	Set_Number_of_Analog_Channels(TWO_ANALOG);    /* DO NOT CHANGE! */
#endif


	
/* FIRST: Set up the I/O pins you want to use as digital INPUTS. */
#ifdef _FRC_BOARD
  digital_io_01 = digital_io_02 = digital_io_03 = digital_io_04 = INPUT;
  digital_io_05 = digital_io_06 = digital_io_07 = digital_io_08 = INPUT;
  digital_io_09 = digital_io_10 = digital_io_11 = digital_io_12 = INPUT;
  digital_io_13 = digital_io_14 = digital_io_15 = digital_io_16 = INPUT;
  digital_io_17=digital_io_18 = INPUT;

  //[LRT] only digital i/o pins 1-6 can be used for interrupts
  digital_io_01=INPUT;  //Left Encoder A output
  digital_io_02=INPUT;  //Right Encoder A output
  
  digital_io_07=INPUT;	//Left Encoder B output
  digital_io_08=INPUT;	//Right Encoder B output
#else
	IO1 = IO2 = IO3 = IO4 = IO5 = IO6 = IO7 = IO8 = INPUT;
	IO9 = IO10 = IO11 = IO12 = IO13 = IO14 = IO15 = IO16 = INPUT;
#endif	//_FRC_BOARD

/* FOURTH: Set your initial PWM values.  Neutral is 127. */
	AllStop();	//sets all pwms 00-16 to neutral 127
	TeeBallReset();	//set to extreme position
	
/* should learn how to setup a pwm to control a servo over its full range - DG */


/* FIFTH: Set your PWM output types for PWM OUTPUTS 13-16.
  /*   Choose from these parameters for PWM 13-16 respectively:               */
  /*     IFI_PWM  - Standard IFI PWM output generated with Generate_Pwms(...) */
  /*     USER_CCP - User can use PWM pin as digital I/O or CCP pin.           */
  Setup_PWM_Output_Type(IFI_PWM,IFI_PWM,IFI_PWM,IFI_PWM);

  /* 
     Example: The following would generate a 40KHz PWM with a 50% duty cycle on the CCP2 pin:

         CCP2CON = 0x3C;
         PR2 = 0xF9;
         CCPR2L = 0x7F;
         T2CON = 0;F
         T2CONbits.TMR2ON = 1;

         Setup_PWM_Output_Type(USER_CCP,IFI_PWM,IFI_PWM,IFI_PWM);
  */

  /* Add any other initialization code here. */

  Initialize_Serial_Comms();

  // Initialize timers and external interrupts
  // NOTE WELL:  Interrupt vector is installed in User_Routines_Fast.c
  // Interrupt handlers are located in interrupts.c
  Initialize_Interrupts();
  //Initialize_Timer_0();
  //Initialize_Timer_1();
  //Initialize_Timer_2();
  //Initialize_Timer_3();
  Initialize_Timer_4();	//maintains gClockms & gSeconds

  Putdata(&txdata);             /* DO NOT CHANGE! */

  printf("%s\n", strptr);       /* Optional - Print initialization message. */

  User_Proc_Is_Ready();         /* DO NOT CHANGE! - last line of User_Initialization */
}

/*******************************************************************************
* FUNCTION NAME: Process_Data_From_Master_uP
* PURPOSE:       Executes every 26.2ms when it gets new data from the master 
*                microprocessor.
* CALLED FROM:   main.c
* ARGUMENTS:     none
* RETURNS:       void
*******************************************************************************/
//Note: 26.2ms is 2^18 * (1/10MHz) [D.Giandomenico]
//There are 38.15 cycles / second

static void Slow26msLoop(void);
static void Process_Data_Shell0(void); 
void Process_Data_From_Master_uP(void)
{	
	Getdata(&rxdata);   /* Get fresh data from the master microprocessor. */

#ifdef SIM
		autonomous_mode=0;	//for simulation
#endif
	
	UpdateSlowLoopTimers();
	if (competition_mode)	//verify when Competition_mode is true
		if (gLoopTimer.secondsChanged)
			printf("Outputs Disabled\n");
			//outputs are disabled, but routines continue to run.

	Process_Data_Shell0();

	Putdata(&txdata);             /* DO NOT CHANGE! */	
}
/*******************************************************************************/
static void Process_Data_Shell0(void)
{
	GetEncoderPositionNow();
	GetLegPositions();
	ClearOIFeedbackData();	//clear copy of OI LED/User bytes
	StallDetect();		//check if power was applied but no velocity resulted

	Slow26msLoop();
#ifdef SIM
	{
		SIMmotorDrive();
		SimulateLegMotors();
	}
#endif
	UpdateOIFeedbackData(); //copy OI LED/User bytes to txdata
	StallDetect_SaveDrivePWMs();	//save info about power applied to drive
}


/*******************************************************************************
*
*	FUNCTION:		User_Autonomous_Code()
* 
*******************************************************************************/

static void Slow26msLoop(void)	//called from Process_data_From_Master_uP() above
{


	AllStop();	//force all pwms to neutral;
	TeeBallRun();

	if (0 && mPhotoDetector)
		TeeBallStartSwing();	//test

	//diagnostics
	if(1 && gLoopTimer.secondsChanged && (1==(0x3&gClock.seconds)))
	{
		printf("\n   SlowLoop -- ");	
		PrintTimeMs();
		PrintDistanceFeet();
		PrintVelocity();
		PrintLegPosition();
	}

	
	
//	if (gLoopTimer.secondsChanged) printf("Slow26msLoop\n");
	
	LRTConsoleMapping();
	
	//send data back to 'Dashboard'
	txdata.user_byte5=EncoderLeft.velocity;
	txdata.user_byte6=EncoderRight.velocity;


  //Generate_Pwms(pwm13,pwm14,pwm15,pwm16);
	RemoveAllPWMDeadbands();

}
