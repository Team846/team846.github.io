#ifndef __TetraWhacker_h
#define __TetraWhacker_h

void whackTetraStart(char side);
char whackTetraRun(void);

#endif	//__TetraWhacker_h
