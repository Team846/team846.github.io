#include "LRTUtilities.h"

char AutonomousRun(void);
void WhackTetraReset(void);
