#ifndef __xferProfiles_h
#define __xferProfiles_h

extern rom const char xferPower4_5[128];
extern rom const char xfer96_4[128];
#endif	//__xferProfiles_h
