#include "arm.h"
#include "ifi_utilities.h"
#include "lrtConnections.h"
/********************************************************************************
* FILE NAME: arm.c
*
* DESCRIPTION: 
*
********************************************************************************/
/********************************************************************************
* FUNCTION: 
*
* DESCRIPTION: 
*
********************************************************************************/

/*******************************************************************************/
arms gArm;

/********************************************************************************
* FUNCTION: GetArmPositions()
*
* DESCRIPTION: Read the analog positions of the arms at the beginning
* of each loop.
*
********************************************************************************/

void GetArmPositions(void)
{
	overlay unsigned int rawAnalog;	//value on {0,1023}
	rawAnalog = Get_Analog_Value(kA2DShoulderJoint);
	rawAnalog = Get_Analog_Value(kA2DArmJoint);

}

void lockUserArmControls(void)
{
	gArm.fore.locked=1;
	gArm.fore.lastUnlockedValue;	//record last known user command

	gArm.upper.locked=1;
	gArm.upper.lastUnlockedValue;	//record last known user command
}

/********************************************************************************
* FUNCTION: checkArmLocks() 
*
* DESCRIPTION: unlocks each arm if each is near last value when unlocked.
*  Check that BOTH are unlocked before processing leg values;
*
********************************************************************************/


#define kArmUnlockThreshold 20
void checkArmLocks(void)
{
	overlay int diff;	
	if (gArm.fore.locked)
	{
		diff = gArm.fore.oldPosition - (int) gArm.fore.curPosition;
		if (diff < 0) diff = -diff;
		if (diff < kArmUnlockThreshold)
			gArm.fore.locked=0;		//unlock this arm	
	}

	if (gArm.upper.locked)
	{
		diff = gArm.upper.oldPosition - (int) gArm.upper.curPosition;
		if (diff < 0) diff = -diff;	//abs()
		if (diff < kArmUnlockThreshold)
			gArm.upper.locked=0;		//unlock this arm	
	}
}

void moveArms(void)
{
//	static void moveForeArm(void);
//	static void moveUpperArm(void);

//	if (gArm.commandInProgress)


}
