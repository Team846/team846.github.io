/********************************************************************************
* FILE NAME: Arm.h
*
* DESCRIPTION: arm variables and routines
*
********************************************************************************/


#ifndef __Arm_h
#define __Arm_h



typedef struct
{
	int position1024;	//current ten bit reading
	unsigned char curPosition;
	unsigned char oldPosition;
	unsigned char cmd;	//the position sent from the OI
	unsigned char lastUnlockedValue; //a position sent from OI
	char inPosition: 1;
	char locked:	1;	//don't allow user control until input differs
						//from lastUserValue
} arm;

typedef struct
{
	arm upper;	//e.g. gArm.upper.curPosition
	arm fore;	//e.g. gArm.fore.curPosition
	char commandInProgress: 1;
} arms;

extern arms gArm;


/*******************************************************************************/
void GetArmPositions(void);
void checkArmLocks(void);
void lockUserArmControls(void);
void moveArms(void);

#endif	//__Arm_h



