#include "LRTUtilities.h"


void AutonomousAbort(void){}
void AutonomousInitialize(void){}
void AutonomousReset(void){}
char AutonomousRun(void){}
char AutonomousStatus(void){}

char gDriveLimitedFlag;
