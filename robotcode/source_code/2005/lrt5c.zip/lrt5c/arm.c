#include "arm.h"
#include "ifi_utilities.h"
#include "lrtConnections.h"
#include "lrtMotorDrive.h"
#include "lrtUtilities.h"



pidData gpid,	//scratch area
	gShoulderPID = { 10,0,0, 0,0,0},
	gForearmPID = { 10,0,0, 0,0,0};

/********************************************************************************
* FUNCTION: 
*
* DESCRIPTION: 
*
********************************************************************************/

/*******************************************************************************/
arms gArm;

/********************************************************************************
* FUNCTION: GetArmPositions()
*
* DESCRIPTION: Read the analog positions of the arms at the beginning
* of each loop.
*
********************************************************************************/

void GetArmPositions(void)
{
	overlay unsigned int rawAnalog;	//value on {0,1023}
	rawAnalog = Get_Analog_Value(kA2DShoulderJoint);
	rawAnalog = Get_Analog_Value(kA2DArmJoint);

//good place to get values for k
//#define _TunePID
#ifdef _TunePID
//KD =Get_Analog_Value(kA2D1);
//KI =Get_Analog_Value(kA2D2);
//KD =Get_Analog_Value(kA2D3);
#endif //_TunePID
}

void lockUserArmControls(void)
{
	gArm.forearm.locked=1;
	gArm.forearm.lastUnlockedValue;	//record last known user command

	gArm.shoulder.locked=1;
	gArm.shoulder.lastUnlockedValue;	//record last known user command
}

/********************************************************************************
* FUNCTION: checkArmLocks() 
*
* DESCRIPTION: unlocks each arm if each is near last value when unlocked.
*  Check that BOTH are unlocked before processing leg values;
*
********************************************************************************/


#define kArmUnlockThreshold 20
void checkArmLocks(void)
{
	overlay int diff;	
	if (gArm.forearm.locked)
	{
		diff = gArm.forearm.oldPosition - (int) gArm.forearm.curPosition;
		if (diff < 0) diff = -diff;
		if (diff < kArmUnlockThreshold)
			gArm.forearm.locked=0;		//unlock this arm	
	}

	if (gArm.shoulder.locked)
	{
		diff = gArm.shoulder.oldPosition - (int) gArm.shoulder.curPosition;
		if (diff < 0) diff = -diff;	//abs()
		if (diff < kArmUnlockThreshold)
			gArm.shoulder.locked=0;		//unlock this arm	
	}
}
/********************************************************************************/
void UserControlArms(void)
{
	if (gArm.commandInProgress) return;
	if (!gArm.forearm.locked)
		gPWM.forearm = addDeadband(mForearm);
	if (!gArm.shoulder.locked)
	gPWM.shoulder = addDeadband(mShoulder);
}
/********************************************************************************/

void ApplyArmLimitSwitches(void)
{
	//switches should go high when limited (interrupted), or disconnected
	//motors should be connected such that positive pwm -> up movement
	
	if (mShoulderUpperLimitSw && gPWM.shoulder>0)
		gPWM.shoulder=0;
	if (mShoulderLowerLimitSw && gPWM.shoulder<0)
		gPWM.shoulder=0;

	if (mForeArmUpperLimitSw && gPWM.forearm>0)
		gPWM.shoulder=0;
	if (mForeArmLowerLimitSw && gPWM.forearm<0)
		gPWM.shoulder=0;
}



/* works on data on gPid -- need to copy data in and out. */

void armPID(int error)
{
	extern pidData gpid;	
	overlay int differential;
	overlay struct {
		long short proportional;	//'long short' is 24 bits
		long integral;
		long short differential;
	} pwm;	//these are the 3 components that make up the PID ouput.
	

//	1+a+a^2+a^3... = 1/(1-a)
//	1 + b/256 + (b/256)^2 + (b/256)^3... = 256/(256-b)
//	so max we can climb is 256* error.

	gpid.integral = gpid.integral*255;	//decay constant (e.g. 255/256) 
	gpid.integral = mDivideBy256(gpid.integral) + error;

	

	pwm.proportional = gpid.KP * error;
	mDivideBy64(pwm.proportional);

	// typical integral values may climb to 256 * 512, or 2^17 and as high as 2^18
	// if we keep KI on {0,256} then valuy
	// to keep pwm on {0,127} (2^7)
	pwm.integral = gpid.KI * gpid.integral;
	mDivideByPowerOf2(pwm.integral,11);	//divide by 2048

//	pwm.differential = error - gpid.error_prior;
//	gpid.error_prior = error;	//save error for next loop
//	pwm.differential = gpid.KD * pwm.differential;
//	pwm.differential = mDivideBy256;

	gpid.pwm = pwm.proportional;
	gpid.pwm += pwm.integral;
//	gpid.pwm += pwm.differential;

	mLimitRange(gpid.pwm,-127,127);
}


void OperateArms(void)
{
	
	gpid = gShoulderPID; //copy data structure
	armPID(gArm.shoulder.position1024-gArm.shoulder.setpoint);
	gPWM.shoulder = gpid.pwm;
	gShoulderPID = gpid; //save updated structure
	
	gpid = gForearmPID; //copy data structure
	armPID(gArm.forearm.position1024-gArm.forearm.setpoint);
	gPWM.forearm = gpid.pwm;
	gForearmPID = gpid;	//save updated structure
}
