/*******************************************************************************
* FILE NAME: ifi_default.h
*
* DESCRIPTION: 
*  Modifies vectors in orignal ifi_default.h
* so that interrupts and timers will work with MPLabSIM debugger              
* when SIMULATOR is defined.
*  David Giandomenico 2/11/2005
*******************************************************************************/

#ifndef __ifi_default_h_
#include "ifi_defaultOriginal.h"

#ifdef _SIMULATOR
	#undef   RESET_VECTOR
	#undef   HIGH_INT_VECTOR
	#undef   LOW_INT_VECTOR
	
	#define   RESET_VECTOR      0x000
	#define   HIGH_INT_VECTOR   0x008
	#define   LOW_INT_VECTOR    0x018
#endif //SIMULATOR


#endif //__ifi_default_h_
