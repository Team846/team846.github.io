/********************************************************************************
* FILE NAME: lrtControls.c
*
* DESCRIPTION: 
*
********************************************************************************/
#include "ifi_aliases.h"
#include "ifi_default.h"
#include "lrtConnections.h"
#include "printf_lib.h"
#include "lrtUtilities.h"
#include "lrtMotorDrive.h"
#include "arm.h"
#include "lrtResultCodes.h"

#define TORQUE_DRIVE 1		//for user control only; see lrtRobotMove.c too

enum activeRoutines { kNoRoutine, kRoutineAutonomous, kRoutineClimb, kRoutineDescend };
// enum activeRoutines { kNoRoutine, kRoutineAutonomous, kHookTetra, kReleaseTetra };

static struct {
	char returnValue;
	char activeRoutine;
} automationState = { kResultNotRunning, kNoRoutine };

/*******************************************************************************
* FUNCTION NAME: LRTConsoleMapping
* PURPOSE:       Performs the default mappings of inputs to outputs for the
*                Robot Controller.
* CALLED FROM:   this file, Process_Data_From_Master_uP routine
* ARGUMENTS:     none
* RETURNS:       void
*******************************************************************************/
void lrtJoystickDrive(void);
static void LRTAutomationRoutines(void);
//static void TimerHookExtend(char forceExpire);
//static void TimerBoomElevate(char forceExpire);
//static void TimerBoomRotate(char forceExpire);

void LRTConsoleMapping(void)
{
	static struct {
		char autonomousLastCycle:1;
	} modeFlag={0};
	
	//catch transition from Autonomous to UserMode for any initialization	
//check if UserMode started (immediately following autonomousMode)
	if (!autonomous_mode && modeFlag.autonomousLastCycle)
	{
//		TimerHookExtend(1);	//freeze control
//		TimerBoomElevate(1);
//		TimerBoomRotate(1);
		//abort autonomous?
		//any other initialization?
	}
	modeFlag.autonomousLastCycle = autonomous_mode;


	if (gLoop.onSecond) printf("Slow26msLoop\n");

	//for testing & setup purposes only.  Send raw input to ouput.
	if (1)mPWMTestOut = mLeftDriveJoyStick; //pwm10 & p4_y; see lrtConnections.h

	LRTAutomationRoutines();

	//return value in global 'automationState'
	if (automationState.returnValue != kResultRunning)	//lockout joystick and legs if automation
	{
		if (mShiftLow)	ShiftLowGear();
		if (mShiftHigh) ShiftHighGear();


//Code for arm posititioning goes here

			checkArmLocks();
			UserControlArms();

		if (gGearBox.shifting)
			DoShift();
		else
			lrtJoystickDrive();		//drive controls locked out while shifting

//		CheckLockOnLegControls();
//		LRTFrontRearLegMapping();
	}
	else
	{
//		gLegs.front.locked = gLegs.rear.locked = 1;
//		Automated_OperateLegs();
	}


}
/*******************************************************************************/

void lrtJoystickDrive(void)
{
	//joystick output at extremes: stick back=0; fwd=254; stick left=254; right=0
	overlay int Left;
	overlay int Right;	
//	overlay int Forward;
	overlay int Turn;

	Left = addDeadband(mLeftDriveJoyStick);
	Right = addDeadband(mRightDriveJoyStick);
	Turn = addDeadband(mTurnJoyStick);
		
	
	if (mRightJoyStickOnly)	//need to mix inputs
	{
		//reduce gain on 'turn'
		//'turn' input is on right joystick
		Left =  (int)Right - (int)Turn;
		Right = (int)Right + (int)Turn;
	}		

	if (mLowRate)
	{
//		Forward =	Left + Right;	//this area for rescaling turn and fwd
//		Turn =		Left - Right;
//		Left =	Forward + Turn;
//		Right = Forward - Turn;
		mDivideBy2(Left);
		mDivideBy2(Right);
	}

//User_Byte1=LeftInput;
//User_Byte2=RightInput;

	mLimitRange(Left,-127,127);
	mLimitRange(Right,-127,127);
	
	DriveLeftMotors(Left);
	DriveRightMotors(Right);
}

/******************************************************************************
Remove deadband from Victor 884 ESC's
at the same time, map {-127,127} to {0,255}
******************************************************************************/
void RemoveAllPWMDeadbands(void)
{
	mPWMcimLeft=		removePWMDeadband(gPWM.cimL);
	mPWMcimRight=		removePWMDeadband(gPWM.cimR);
	mPWMfpriceLeft=		removePWMDeadband(gPWM.fpriceL);
	mPWMfpriceRight=	removePWMDeadband(gPWM.fpriceR);
	mPWMshoulder=		removePWMDeadband(gPWM.shoulder);
	mPWMforearm=		removePWMDeadband(gPWM.forearm);

	//don't remove deadbands from servos
}	
/******************************************************************************/

static void LRTAutomationRoutines(void)
{
	//Abort automation routines
	if (mDriverAbort || competition_mode) //competition mode is 'disable' switch
	{
		switch (automationState.activeRoutine)
		{
			case kRoutineAutonomous:
				printf("AUTO Abort\n");
				AutonomousAbort();
				if (competition_mode)	//competition mode is 'disable' switch
					AutonomousReset();	//allow another run after disable released.
				break;
			case kRoutineClimb:
//				ClimbStepAbort();
				break;
			case kRoutineDescend:
//				DescendStepAbort();
				break;
			default:
				break;
		}
		automationState.activeRoutine = kNoRoutine;
		automationState.returnValue = kResultNotRunning;
		return;
	}

	//Initialize (start) automation routines
	if (automationState.returnValue != kResultRunning)
	{
		if (!autonomous_mode && !mSwAutonomous)
			AutonomousReset();
		
		if (autonomous_mode || mSwAutonomous)
		{
			if (mSwAutonomous) AutonomousReset();	//allow more than one run
			AutonomousInitialize();
			if (kResultRunning == AutonomousStatus())	//sucessful init? Then proceed.
			{
				automationState.activeRoutine = kRoutineAutonomous;
				automationState.returnValue = kResultRunning;
			}
		}
//		else if (mClimbStep)
//		{
////			ClimbStepInitialize();
//			automationState.activeRoutine = kRoutineClimb;
//			automationState.returnValue = kResultRunning;
//		}
//		else if (mDescendStep)
//		{
////			DescendStepInitialize();
//			automationState.activeRoutine = kRoutineDescend;
//			automationState.returnValue = kResultRunning;
//		}
	}	//End of Initialize  automation routines


	//Run automation routines
	if (automationState.returnValue==kResultRunning)
	{

		switch (automationState.activeRoutine)
		{
			case kRoutineAutonomous:
				automationState.returnValue = AutonomousRun();
				break;
			case kRoutineClimb:
//				automationState.returnValue = ClimbStepRun();
				break;
			case kRoutineDescend:
//				automationState.returnValue = DescendStepRun();
				break;
			default:
				break;
		}
	}
}

/*******************************************************************************/


