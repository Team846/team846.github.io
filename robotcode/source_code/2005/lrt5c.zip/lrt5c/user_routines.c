/*******************************************************************************
* FILE NAME: user_routines.c <FRC VERSION>
*
* DESCRIPTION:
*  This file contains the default mappings of inputs  
*  (like switches, joysticks, and buttons) to outputs on the RC.  
*
* USAGE:
*  You can either modify this file to fit your needs, or remove it from your 
*  project and replace it with a modified copy. 
*
*******************************************************************************/

#include "ifi_aliases.h"
#include "ifi_default.h"
#include "ifi_utilities.h"
#include "user_routines.h"
#include "printf_lib.h"
#include "interrupts.h"
#include "lrtUtilities.h"
#include "OIFeedback.h"
#include "lrtConnections.h"
#include "lrtMotorDrive.h"
#include "arm.h"


encoder EncoderRight={0,0,0,0}, EncoderLeft={0,0,0,0};



struct Clock volatile gClock;

static void Process_Data_Shell0(void);
static void Slow26msLoop(void);




/*******************************************************************************
* FUNCTION NAME: Process_Data_From_Master_uP
* PURPOSE:       Executes every 26.2ms when it gets new data from the master 
*                microprocessor.
* CALLED FROM:   main.c
* ARGUMENTS:     none
* RETURNS:       void
*******************************************************************************/
//Note: 26.2ms is 2^18 * (1/10MHz) [D.Giandomenico]
//There are 38.15 cycles / second

void Process_Data_From_Master_uP(void)
{
 	Getdata(&rxdata);   /* Get fresh data from the master microprocessor. */

#ifdef SIM
		autonomous_mode=0;	//for simulation
#endif
	
	UpdateSlowLoopTimers();
	if (competition_mode)	//verify when Competition_mode is true
		if (gLoop.onSecond2)
			printf("Outputs & OI Disabled\n");
			//outputs are disabled, but routines continue to run.

	Process_Data_Shell0();
 	Getdata(&rxdata);   /* Get fresh data from the master microprocessor. */

  Putdata(&txdata);             /* DO NOT CHANGE! */
}


/******************************************************************************/
static void Process_Data_Shell0(void)
{
	GetEncoderPositionNow();
//	GetLegPositions();
	ClearOIFeedbackData();	//clear copy of OI LED/User bytes
//	StallDetect();		//check if power was applied but no velocity resulted
	
//	Operate Compressor as needed
	mCompressorRelay = !mCompressorAtPressure;

	Slow26msLoop();
#ifdef SIM
	{
		SIMmotorDrive();
	}
#endif
	UpdateOIFeedbackData(); //copy OI LED/User bytes to txdata
//	StallDetect_SaveDrivePWMs();	//save info about power applied to drive
}

/******************************************************************************/
static void Slow26msLoop(void)	//called from Process_data_From_Master_uP() above
{
	AllStop();	//force all pwms to neutral;
	ClearMotorPWMs();	//clear all motor drive values.
	gDriveLimitedFlag = 0;	//clear drive current limited flag

	//diagnostics; print every four seconds
	if(gLoop.onSecond4)
	{
		printf("\n   SlowLoop -- ");	
		PrintTimeMs();
		PrintDistanceFeet();
		PrintVelocity();
		PrintLegPosition();
	}

	//	if (gLoop.onSecond) printf("Slow26msLoop\n");
	
	if (mTetraLoadServiceFlag) ToggleSignalFlag();
	LRTConsoleMapping();
	SignalFlagPWM();

	//send data back to 'Dashboard'
	txdata.user_byte5=EncoderLeft.velocity;
	txdata.user_byte6=EncoderRight.velocity;


  //Generate_Pwms(pwm13,pwm14,pwm15,pwm16);
	ApplyArmLimitSwitches();
	RemoveAllPWMDeadbands();
}
/******************************************************************************/
/******************************************************************************/
/******************************************************************************/
