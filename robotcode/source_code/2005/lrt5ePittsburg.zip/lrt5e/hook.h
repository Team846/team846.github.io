
#ifndef __Hook_h
#define __Hook_h

extern char gHookPosition;	//position of hook
enum { kHookUp, kHookDown };	//NB: Robot_disabled position is '0'



#endif	//__Hook_h

