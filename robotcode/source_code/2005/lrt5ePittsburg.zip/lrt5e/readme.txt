FRC-RC Interrupt and Timer Template Code.

2-25-2004
Updated interrupts.c to allow clearing of the interrupt flag before enabling.

2-24-2004
Added IFI's latest version of ifi_aliases.h, dated 2-20-2004.
Added IFI's PWM and Relay initialization bug fix to user_routines_fast.c/User_Autonomous_Code().

2-23-2004
Added IFI's latest version of ifi_aliases.h, dated 2-18-2004.

2-17-2004
Added the latest verson of user_routines_fast.c and IFI's 2-10-2004 default code release.

The FRC-RC interrupt inputs are mapped to digital inputs:
Use digital input 1 for interrupt 1
Use digital input 2 for interrupt 2
Use digital input 3 for interrupt 3
Use digital input 4 for interrupt 4
Use digital input 5 for interrupt 5
Use digital input 6 for interrupt 6 