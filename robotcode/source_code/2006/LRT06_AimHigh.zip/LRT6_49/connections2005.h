

#error - not to be included. For Reference
#define mPWMcimLeft pwm01
#define mPWMfpriceLeft pwm02
#define mPWMcimRight pwm03
#define mPWMfpriceRight pwm04


//#define mEncoderLeftAin rc_dig_in01	//interrupt - used implicitly by interupt 1
//#define mEncoderRightAin rc_dig_in02  //interrupt - used implicitly by interupt 2
#define mEncoderLeftBin rc_dig_in03
#define mEncoderRightBin rc_dig_in04


#define mCompressorRelay relay2_fwd	//on separate power circuit
