#ifndef __EEPROM_H
#define __EEPROM_H
//***************************************************************************

//***************************************************************************
unsigned char EEPROM_read(unsigned int address);
void EEPROM_write(unsigned int address, unsigned char c);
//***************************************************************************
#endif //__EEPROM_H -- !!Nothing below this line!!
