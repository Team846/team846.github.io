#include <stdio.h>

#include "ifi_aliases.h"
#include "ifi_default.h"
#include "ifi_utilities.h"
#include "user_routines.h"
#include "serial_ports.h"
#include "camera.h"
#include "tracking.h"
#include "terminal.h"
#include "encoder.h"
#include "simulator.h"

#include "connections.h"

void AutoTest(void)
{
//	static int counter = 0;
//
//	switch (counter)
//	{
//		case 1: gCtrl.left = 255; gCtrl.right = 255;
//				break;
//		case 2: gCtrl.left = 0; gCtrl.right = 0;
//				break;
//		case 3: gCtrl.left = 127; gCtrl.right = 127;
//				break;
//		default: break;
//	}
//	counter++;
}
