#include "common.h"

void testArea(void)
{
	//
}
