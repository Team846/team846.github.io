// Compass.h

#ifndef _compass_h
#define _compass_h

extern unsigned int gCompassDirection;	

void Initialize_Compass(void);

void GetCompassHeading(void);

#endif
