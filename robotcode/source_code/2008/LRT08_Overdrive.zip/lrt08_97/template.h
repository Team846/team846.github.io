#ifndef __TEMPLATE_h
#define __TEMPLATE_h

#include "common.h"

// Declarations here.

#endif	// __TEMPLATE_h
