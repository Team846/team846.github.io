FRC Simple Robot Template
--------------------------------

This program is the simplest sample program that implements
the full field control and shows the use of the watchdog
timer. This is an excellent starting point for your programs.

This program simply drives forward for 2 seconds in the
Autonomous period and does simple arcade driving during the
Operator Control period.
