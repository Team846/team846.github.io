#ifndef AUTON_INCLUDES_H_
#define AUTON_INCLUDES_H_

#include "LRTAutonBase.h"
#include "FarField.h"
#include "MiddleField.h"
#include "NearFieldStraightKick.h"
#include "TestAuton.h"

#endif
