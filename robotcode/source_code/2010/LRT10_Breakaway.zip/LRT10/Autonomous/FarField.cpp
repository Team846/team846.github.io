#include "FarField.h"
using namespace std;
FarField::FarField(ClosedLoopDriveTrain& robotDrive,
        LRTDriveEncoders& driveEncoders,
        LRTKicker& kicker,
        LRTRoller& roller,
        string name)
    : LRTAutonBase(robotDrive, driveEncoders,
            kicker, roller, name)
{

}

void FarField::AutonTask()
{
    DriveAndKickBalls(3);
}
