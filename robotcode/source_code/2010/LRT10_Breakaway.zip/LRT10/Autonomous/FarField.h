#include "LRTAutonBase.h"
class FarField : public LRTAutonBase
{
public:
    FarField(ClosedLoopDriveTrain& robotDrive,
            LRTDriveEncoders& driveEncoders,
            LRTKicker& kicker,
            LRTRoller& roller,
            std::string name = "LRTAutonFarField");
    const static int kInchesFromFirstBall = 3;
    const static int kInchesToMoveTowardsCenter = 9 * 12 + 8;
    const static int kDashInSliderChannel = 1;//TODO CHANGE ME!
    const static int kGetFirstBallMin = 0;//TODO figure out
    const static int kExtraBallIncrement = 1;//TODO figure out
protected:
    virtual void AutonTask();
};
