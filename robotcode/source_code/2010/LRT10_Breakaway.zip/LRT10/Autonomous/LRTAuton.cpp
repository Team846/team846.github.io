#include "LRTAuton.h"
#include "../AsynchronousPrinter.h"

LRTAuton::LRTAuton(ClosedLoopDriveTrain& robotDrive,
        LRTDriveEncoders& driveEncoders, LRTKicker& kicker, LRTRoller& roller) :
    m_currentAuton(0)
    , m_farField(robotDrive, driveEncoders, kicker, roller)
    , m_middleField(robotDrive, driveEncoders, kicker, roller)
    , m_nearFieldStraightKick(robotDrive, driveEncoders, kicker, roller)
    , m_testAuton(robotDrive, driveEncoders, kicker, roller)
{
}

void LRTAuton::StartFarField()
{
    StartAuton(m_farField);
}

void LRTAuton::StartMiddleField()
{
    StartAuton(m_middleField);
}

void LRTAuton::StartNearFieldStraightKick()
{
    StartAuton(m_nearFieldStraightKick);
}

void LRTAuton::StartTestAuton()
{
    StartAuton(m_testAuton);
}

void LRTAuton::StartAuton(LRTAutonBase& auton)
{
    if(m_currentAuton != 0)
    {
        AsynchronousPrinter::Printf("AUTONOMOUS ALREADY RUNNING - cannot start new auton\n");
        return;
    }

    AsynchronousPrinter::Printf("Started auton mode: %s\n", auton.GetName().c_str());
    m_currentAuton = &auton;
    m_currentAuton->StartAuton();
}

void LRTAuton::EndAuton()
{
    if(m_currentAuton == 0)
    {
        AsynchronousPrinter::Printf("NO AUTONOMOUS RUNNING - cannot end autonomous\n");
        return;
    }

    m_currentAuton->EndAuton();
    m_currentAuton = 0;
}
