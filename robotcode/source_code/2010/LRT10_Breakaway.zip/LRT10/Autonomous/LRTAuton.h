#ifndef LRT_AUTON_H_
#define LRT_AUTON_H_

#include "AutonIncludes.h"
#include "../ClosedLoopDriveTrain.h"
#include "../LRTDriveEncoders.h"
#include "../LRTKicker.h"

class LRTAuton
{
public:
    LRTAuton(ClosedLoopDriveTrain& robotDrive,
            LRTDriveEncoders& driveEncoders, LRTKicker& kicker,
            LRTRoller& roller);

    void StartFarField();
    void StartMiddleField();
    void StartNearFieldStraightKick();
    void StartTestAuton();

    void EndAuton();

private:
    void StartAuton(LRTAutonBase& auton);

    LRTAutonBase* m_currentAuton;

    FarField m_farField;
    MiddleField m_middleField;
    NearFieldStraightKick m_nearFieldStraightKick;

    TestAuton m_testAuton;
};

#endif
