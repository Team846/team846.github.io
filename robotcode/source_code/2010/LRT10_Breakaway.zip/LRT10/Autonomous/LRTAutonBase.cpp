#include "LRTAuton.h"
#include <string>
#include "../LRTConsole.h"
using namespace std;

LRTAutonBase::LRTAutonBase(ClosedLoopDriveTrain& robotDrive,
        LRTDriveEncoders& driveEncoders,
        LRTKicker& kicker,
        LRTRoller& roller,
        string name) :
    m_robotDrive(robotDrive)
    , m_driveEncoders(driveEncoders)
    , m_kicker(kicker)
    , m_roller(roller)
    , m_name(name)
    , m_task((m_name + "Task").c_str(), (FUNCPTR)LRTAutonBase::TaskEntry)
{

}

string LRTAutonBase::GetName()
{
    return m_name;
}

void LRTAutonBase::StartAuton()
{
    m_task.Start((UINT32)this);
}

void LRTAutonBase::EndAuton()
{
    m_task.Stop();
}

void LRTAutonBase::TaskEntry(UINT32 p)
{
    ((LRTAutonBase*)p)->AutonTask();
}

void LRTAutonBase::DriveStraightDistance(Direction dir, float inches, float speed,
        bool stopAfter)
{
    AsynchronousPrinter::Printf("Driving straight distance\n");

    //ensure both values are positive
    inches = LRTUtil::abs<float>(inches);
    speed = LRTUtil::abs<float>(speed);

    double startDist = m_driveEncoders.GetRobotDist();

    if(dir == kForward)
    {
        double endDist = startDist + inches;

        while(m_driveEncoders.GetRobotDist() < endDist)
        {
            m_robotDrive.ArcadeDrive(speed, 0.0);
            Wait(0.01);
        }
    }
    else if(dir == kReverse)
    {
        double endDist = startDist - inches;

        while(m_driveEncoders.GetRobotDist() > endDist)
        {
            m_robotDrive.ArcadeDrive(-speed, 0.0);
            Wait(0.01);
        }
    }

    if(stopAfter)
        StopRobot();

    AsynchronousPrinter::Printf("Finished Driving Straight\n");
}

void LRTAutonBase::DriveStraightTime(Direction dir, float time, float speed,
        bool stopAfter)
{
    //ensure both values are positive
    time = LRTUtil::abs<float>(time);
    speed = LRTUtil::abs<float>(speed);

    if(dir == kReverse)
    {
        speed = -speed;
    }

    Timer timer;
    timer.Start();

    while(!timer.HasPeriodPassed(time))
    {
        m_robotDrive.ArcadeDrive(speed, 0.0);
        Wait(0.02);
    }

    if(stopAfter)
        StopRobot();
}

void LRTAutonBase::DriveCondition(Direction dir, bool (*condition)(), float speed, float timeout,
        bool stopAfter)
{
    speed = LRTUtil::abs<float>(speed);
    timeout = LRTUtil::abs<float>(timeout);

    if(dir == kReverse)
    {
        speed = -speed;
    }

    Timer timer;
    timer.Start();

    while(!timer.HasPeriodPassed(timeout) && !condition())
    {
        m_robotDrive.ArcadeDrive(speed, 0.0);
        Wait(0.01);
    }

    if(stopAfter)
        StopRobot();
}

void LRTAutonBase::TurnAngle(Rotation dir, float degrees, float turnSpeed, bool stopAfter)
{
    AsynchronousPrinter::Printf("Turning angle\n");

    // ensure both values are positive
    degrees = LRTUtil::abs<float>(degrees);
    turnSpeed = LRTUtil::abs<float>(turnSpeed);

    float revolutions = degrees / 360.0;
    float startTurn = m_driveEncoders.GetTurnRevolutions();

    // clockwise is negative turning
    if(dir == kCW)
    {
        float endTurn = startTurn - revolutions;
        while(m_driveEncoders.GetTurnRevolutions() > endTurn)
        {
            m_robotDrive.ArcadeDrive(0.0, -turnSpeed);
            Wait(0.02);
        }
    }
    // counter-clockwise is positive turning
    else if(dir == kCCW)
    {
        float endTurn = startTurn + revolutions;
        while(m_driveEncoders.GetTurnRevolutions() < endTurn)
        {
            m_robotDrive.ArcadeDrive(0.0, turnSpeed);
            Wait(0.02);
        }
    }

    if(stopAfter)
        StopRobot();

    AsynchronousPrinter::Printf("FINISHED TURNING\n");
}

void LRTAutonBase::Pivot(PivotDirection pivotDir, Direction fwdDir,
        float degrees, float speed, bool stopAfter)
{
    AsynchronousPrinter::Printf("STARTED PIVOTING\n");

    degrees = LRTUtil::abs<float>(degrees);
    speed = LRTUtil::abs<float>(speed);

    if(fwdDir == kReverse)
        speed = -speed;

    double revolutions = degrees / 360.0;
    double startTurn = m_driveEncoders.GetTurnRevolutions();

    Rotation rotDir;
    double endTurn;

    //CCW = going left and fwd (0 and 0), or right and back (1 and 1)
    if((pivotDir ^ fwdDir) == 0)
    {
        rotDir = kCCW;
        endTurn = startTurn + revolutions;
    }
    else
    {
        rotDir = kCW;
        endTurn = startTurn - revolutions;
    }

    double error;
    if(rotDir == kCCW)
    {
        error = endTurn - m_driveEncoders.GetTurnRevolutions();
    }
    else if(rotDir == kCW)
    {
        error = m_driveEncoders.GetTurnRevolutions() - endTurn;
    }

    while(error > 0)
    {
//      AsynchronousPrinter::Printf( "P: Spd = %.2f, error = %.2f\n", speed, error );

        if(pivotDir == kLeft)
        {
            m_robotDrive.PivotLeft(speed);
        }
        else if(pivotDir == kRight)
        {
            m_robotDrive.PivotRight(speed);
        }

        Wait(0.02);

        if(rotDir == kCCW)
        {
            error = endTurn - m_driveEncoders.GetTurnRevolutions();
        }
        else if(rotDir == kCW)
        {
            error = m_driveEncoders.GetTurnRevolutions() - endTurn;
        }
    }

    if(stopAfter)
        StopRobot();

    AsynchronousPrinter::Printf("FINISHED PIVOTING\n");
}

void LRTAutonBase::StopRobot()
{
    AsynchronousPrinter::Printf("STOPPING ROBOT\n");

    Timer timer;
    timer.Start();

    while(!timer.HasPeriodPassed(0.5))
    {
        m_robotDrive.ArcadeDrive(0.0, 0.0);
        Wait(0.02);
    }

    AsynchronousPrinter::Printf("FINISHED STOPPING ROBOT\n");
}

void LRTAutonBase::DriveAndKickBalls(int numBalls)
{
    DriveStraightDistance(kForward, 1.5 * 12);

    m_kicker.Release();
    Wait(kTimeToWaitForKicker);

    for(int i = 0; i < numBalls - 1; i++)
    {
        DriveStraightDistance(kForward, 3 * 12);

        m_kicker.Release();
        Wait(kTimeToWaitForKicker);
    }
}
