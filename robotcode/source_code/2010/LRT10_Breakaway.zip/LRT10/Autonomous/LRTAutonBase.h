#ifndef LRT_AUTON_BASE_H_
#define LRT_AUTON_BASE_H_

#include "WPILib.h"
#include "../ClosedLoopDriveTrain.h"
#include "../LRTDriveEncoders.h"
#include "../LRTKicker.h"
#include "../LRTRoller.h"
#include <string>

class LRTAutonBase
{
public:
    LRTAutonBase(ClosedLoopDriveTrain& robotDrive,
            LRTDriveEncoders& driveEncoders,
            LRTKicker& kicker,
            LRTRoller& roller,
            std::string name = "LRTAutonInterface");
    virtual ~LRTAutonBase() {}

    std::string GetName();

    void StartAuton();
    void EndAuton();

    static void TaskEntry(UINT32 p);

    enum Direction {kForward, kReverse};
    enum Rotation {kCW, kCCW};
    enum PivotDirection {kLeft, kRight};
    const static float kStraightDriveSpeed = 0.3;
    const static float kTurnSpeed = 0.4;
    const static float kPivotSpeed = 0.8;

    const static float kTimeout = 2.0;

protected:
    void DriveStraightDistance(Direction dir, float inches, float speed = kStraightDriveSpeed, bool stopAfter = true);
    void DriveStraightTime(Direction dir, float seconds, float speed = kStraightDriveSpeed, bool stopAfter = true);
    void DriveCondition(Direction dir, bool (*condition)(), float speed = kStraightDriveSpeed, float timeout = kTimeout, bool stopAfter = true);

    void TurnAngle(Rotation dir, float degrees, float turnSpeed = kTurnSpeed, bool stopAfter = true);
    void Pivot(PivotDirection pivotDir, Direction fwdDir, float degrees, float speed = kPivotSpeed, bool stopAfter = true);

    void StopRobot();

    void DriveAndKickBalls(int numBalls);

    ClosedLoopDriveTrain& m_robotDrive;
    LRTDriveEncoders& m_driveEncoders;
    LRTKicker& m_kicker;
    LRTRoller& m_roller;
    std::string m_name;

    const static int kInchesToGrabBall = 3;

    // we want to back up more w/ the ball. SVR Day 3 [BL]
    const static int kInchesToBackUpWithBall = 13;
    const static double kTimeToWaitForKicker = 1.5;
private:
    virtual void AutonTask() {}

    Task m_task;
};

#endif
