#ifndef MIDDLE_FIELD_H_
#define MIDDLE_FIELD_H_

#include "LRTAutonBase.h"

class MiddleField : public LRTAutonBase
{
public:
    MiddleField(ClosedLoopDriveTrain& robotDrive,
            LRTDriveEncoders& driveEncoders,
            LRTKicker& kicker,
            LRTRoller& roller,
            std::string name = "MiddleField")
        : LRTAutonBase(robotDrive, driveEncoders,
                kicker, roller, name) {}

    virtual void AutonTask()
    {
        DriveAndKickBalls(2);
    }
};

#endif /*MIDDLE_FIELD_H_*/
