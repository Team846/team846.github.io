#include "NearFieldStraightKick.h"
using namespace std;

NearFieldStraightKick::NearFieldStraightKick(ClosedLoopDriveTrain& robotDrive,
        LRTDriveEncoders& driveEncoders, LRTKicker& kicker, LRTRoller& roller, string name) :
    LRTAutonBase(robotDrive, driveEncoders, kicker, roller, name)
    , m_roller(roller)
{
}

// in the near field, only one ball
// go forward, kick the ball, then back off
void NearFieldStraightKick::AutonTask()
{
    Pivot(kLeft, kForward, 360, 1, false);
//  StopRobot();

//  DriveStraightDistance(kForward, 3 * 12);
//  Wait(1);
//  Pivot(kLeft, kForward, 90, 1);
//  Wait(1);
//  DriveStraightDistance(kForward, 4 * 12);
//  Wait(1);
//
//  m_roller.SetReverse(true);
//  Wait(1);
//  m_roller.SetReverse(false);
//
//  DriveStraightDistance(kReverse, 4 * 12);

//  DriveStraightDistance(kForward, 7*12., 0.5);
//
//  m_kicker.Release();
//  Wait(1.0);
//
//  TurnAngle(kCW, 120, 0.5);
//
//  DriveStraightDistance(kForward, 3*12., 0.5);
}
