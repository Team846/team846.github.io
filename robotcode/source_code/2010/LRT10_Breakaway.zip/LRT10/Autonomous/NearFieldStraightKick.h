#ifndef NEAR_FIELD_STRAIGHT_KICK_H_
#define NEAR_FIELD_STRAIGHT_KICK_H_

#include "LRTAutonBase.h"

class NearFieldStraightKick : public LRTAutonBase
{
public:
    NearFieldStraightKick(ClosedLoopDriveTrain& robotDrive, LRTDriveEncoders& driveEncoders,
            LRTKicker& kicker, LRTRoller& roller, std::string name = "NearFieldStraightKick");
    virtual ~NearFieldStraightKick() {}

    LRTRoller m_roller;

private:
    virtual void AutonTask();
};

#endif
