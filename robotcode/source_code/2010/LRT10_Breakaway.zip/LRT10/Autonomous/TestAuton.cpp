#include "TestAuton.h"
#include "../AsynchronousPrinter.h"

Timer TestAuton::m_timer;

TestAuton::TestAuton(ClosedLoopDriveTrain& robotDrive, LRTDriveEncoders& driveEncoders,
        LRTKicker& kicker, LRTRoller& roller, string name) :
    LRTAutonBase(robotDrive, driveEncoders, kicker, roller, name)
{

}

bool HasPeriodPassed()
{
    return TestAuton::m_timer.HasPeriodPassed(1.0);
}

void TestAuton::AutonTask()
{
    Wait(0.25);
    AsynchronousPrinter::Printf("STARTING TEST AUTON\n");

    DriveStraightDistance(kForward, 2 * 12., 0.2);
    AsynchronousPrinter::Printf("TEST AUTON COMPLETED\n");
}
