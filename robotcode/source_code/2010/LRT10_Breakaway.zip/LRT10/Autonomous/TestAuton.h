#ifndef TEST_AUTON_H_
#define TEST_AUTON_H_

#include "LRTAutonBase.h"
#include "WPILib.h"

class TestAuton : public LRTAutonBase
{
public:
    TestAuton(ClosedLoopDriveTrain& robotDrive, LRTDriveEncoders& driveEncoders,
            LRTKicker& kicker, LRTRoller& roller, std::string name = "TestAuton");
    virtual ~TestAuton() {}

//  bool HasPeriodPassed();

    static Timer m_timer;
private:
    virtual void AutonTask();

};

#endif
