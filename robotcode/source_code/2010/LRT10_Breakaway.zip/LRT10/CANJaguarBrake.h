//Author: Brandon Liu and David Liu (2010)

#ifndef CAN_JAGUAR_BRAKE_H_
#define CAN_JAGUAR_BRAKE_H_

#include "WPILib.h"
#include "Brake.h"
#include "ProxiedCANJaguar.h"

class CANJaguarBrake : public Brake
{
    ProxiedCANJaguar& m_jaguar;
    int m_cycleCount;
    int m_amount;

public:
    CANJaguarBrake(ProxiedCANJaguar& jaggie);
    virtual void ApplyBrakes(int val8); // between 0 and 8

    virtual void BrakeFull()
    {
        ApplyBrakes(8);
    }

    virtual void SetCoast()
    {
        ApplyBrakes(0);
    }

    virtual void UpdateOutput();
};

#endif /* CAN_JAGUAR_BRAKE_H_ */
