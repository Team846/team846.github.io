#include "ClosedLoopDriveTrain.h"
#include "LRTConsole.h"
#include "AsynchronousPrinter.h"
#include <string>

ClosedLoopDriveTrain::ClosedLoopDriveTrain(LRTesc& escLeft,
        LRTesc& escRight,
        LRTDriveEncoders& encoders, DBSDrive& dbsDrive)
    : DriveMethod(escLeft, escRight)
    , m_escLeft(escLeft)
    , m_escRight(escRight)
    , m_encoders(encoders)
    , m_config(LRTConfig::GetInstance())
    , m_dbsDrive(dbsDrive)
    , m_fwdRunningError(kFwdDecay)
    , m_turnRunningError(kTurnDecay)
    , m_ds(*DriverStation::GetInstance())
{
    ApplyConfig();
}

void ClosedLoopDriveTrain::NotifyGearChange(LRTGearBox::GearBoxState newstate)
{
    m_state = newstate;

#ifdef LRT_2010_ROBOT
    if(m_state == LRTGearBox::kHighGear)
    {
        m_pGainFwd = m_HighGearpGainFwd;
        m_pGainTurn = m_HighGearpGainTurn;
    }
    else
    {
        m_pGainFwd = m_LowGearpGainFwd;
        m_pGainTurn = m_LowGearpGainTurn;
    }
#endif //LRT_2010_ROBOT

#ifdef LRT_2010_ROBOT_PRACTICE
    m_pGainFwd = m_pGainTurnPractice;
    m_pGainTurn = m_pGainFwdPractice;
#endif //LRT_2010_ROBOT_PRACTICE    
}

void ClosedLoopDriveTrain::ApplyConfig()
{
    string prefix = "ClosedLoopDriveTrain.";

#ifdef LRT_2010_ROBOT_PRACTICE
    m_pGainTurnPractice = m_config.Get<float>(prefix + "pGainTurnPractice", 1.5);
    m_pGainFwdPractice = m_config.Get<float>(prefix + "pGainFwdPractice", 1.5);
#endif // LRT_2010_ROBOT_PRACTICE

#ifdef LRT_2010_ROBOT
    m_LowGearpGainTurn = m_config.Get<float>(prefix + "LowGearpGainTurn", 1.5);
    m_LowGearpGainFwd = m_config.Get<float>(prefix + "LowGearpGainFwd", 1.5);
    m_HighGearpGainTurn = m_config.Get<float>(prefix + "HighGearpGainTurn", 1.5);
    m_HighGearpGainFwd = m_config.Get<float>(prefix + "HighGearpGainFwd", 1.5);
#endif // LRT_2010_ROBOT

    m_fullBrakingThreshold = m_config.Get<float>(prefix + "fullBrakingThreshold", 0.75);
    m_maxSpeedReversePower = m_config.Get<float>(prefix + "maxSpeedReversePower", 0.3);
    m_driveStraightTurningTolerance = m_config.Get<float>(prefix + "m_driveStraightTurningTolerance", 0.15);
}

DriveOutput ClosedLoopDriveTrain::ComputeArcadeDrive(float rawFwd, float rawTurnRateRPS)
{

    if(m_ds.GetDigitalIn(5))
        return m_dbsDrive.ComputeArcadeDrive(rawFwd, rawTurnRateRPS);

    float turningRate = m_encoders.GetNormalizedTurningSpeed();

    // eliminate spurrious measurements above mag |1|
    // values over mag |1| will cause the closed loop to slow down
    turningRate = LRTUtil::clamp<float>(turningRate, -1, 1);

    // update the running sum with the error
    float turningError = rawTurnRateRPS - turningRate;
    turningError = m_turnRunningError.UpdateSum(turningError);

    float turningCorrection = turningError * m_pGainTurn;
    float newTurn = rawTurnRateRPS + turningCorrection;

//  AsynchronousPrinter::Printf( "Error = %.4f act = %.4f turnIn = %.4f turnOut %.4f Gain = %.4f\n"
//      , turningError, turningRate , rawTurnRateRPS, newTurn, m_pGainTurn);

    // normalized forward speed
    float robotSpeed = m_encoders.GetNormalizedForwardSpeed();

    float fwdError = rawFwd - robotSpeed;
    fwdError = m_fwdRunningError.UpdateSum(fwdError);

    float fwdCorrection = fwdError * m_pGainFwd;
    float newFwd = rawFwd + fwdCorrection;

//  if (LRTUtil::abs<float>(rawFwd) > 0.2)
//      AsynchronousPrinter::Printf("FwdRaw:%+6.3f, FwdError:%+6.3f, FwdCorrection:%+6.3f, FwdGain:%+6.3f\n",
//              rawFwd, fwdError, fwdCorrection, m_pGainFwd);

    return m_dbsDrive.ComputeArcadeDrive(newFwd, newTurn);
}

void ClosedLoopDriveTrain::PivotLeft(float rightSpeed)
{
    m_escLeft.Stop();
    m_escRight.Set(rightSpeed);
}

void ClosedLoopDriveTrain::PivotRight(float leftSpeed)
{
    m_escRight.Stop();
    m_escLeft.Set(leftSpeed);
}
