#ifndef CLOSED_LOOP_DRIVE_TRAIN_H_
#define CLOSED_LOOP_DRIVE_TRAIN_H_

#include "LRTConnections.h"
#include "LRTGearBox.h"
#include "LRTDriveEncoders.h"
#include "DriveMethod.h"
#include "LRTConfig.h"
#include "DBSDrive.h"
#include "WPILib.h"
#include "LRTesc.h"

class RunningSum
{
public:
    RunningSum(float decayConstant) :
        m_decayConstant(decayConstant)
        , m_runningSum(0)
    {
    }

    float UpdateSum(float x)
    {
        m_runningSum *= m_decayConstant;
        m_runningSum += x;
        return m_runningSum * (1 - m_decayConstant);
    }

private:
    float m_decayConstant;
    float m_runningSum;
};

class ClosedLoopDriveTrain : public DriveMethod, public GearBoxListener
{
public:
    ClosedLoopDriveTrain(LRTesc& escLeft,
            LRTesc& escRight,
            LRTDriveEncoders& encoders, DBSDrive& dbsDrive);

    void ApplyConfig();
    virtual DriveOutput ComputeArcadeDrive(float rawFwd, float rawTurn);

    void PivotLeft(float rightSpeed);
    void PivotRight(float leftSpeed);

    LRTesc& GetLeftEsc()
    {
        return m_escLeft;
    }
    LRTesc& GetRightEsc()
    {
        return m_escRight;
    }

    virtual void NotifyGearChange(LRTGearBox::GearBoxState newstate);

private:
    LRTesc& m_escLeft, &m_escRight;
    LRTDriveEncoders& m_encoders;
    LRTConfig& m_config;
    DBSDrive& m_dbsDrive;

    float m_pGainTurn;
    float m_pGainFwd;

    float m_maxSpeedReversePower;
    float m_fullBrakingThreshold;
    float m_driveStraightTurningTolerance;

#ifdef LRT_2010_ROBOT_PRACTICE
    float m_pGainTurnPractice;
    float m_pGainFwdPractice;
#endif // LRT_2010_ROBOT_PRACTICE

#ifdef LRT_2010_ROBOT
    float m_LowGearpGainTurn;
    float m_LowGearpGainFwd;
    float m_HighGearpGainTurn;
    float m_HighGearpGainFwd;
#endif // LRT_2010_ROBOT

    LRTGearBox::GearBoxState  m_state;
    RunningSum m_fwdRunningError, m_turnRunningError;
    DriverStation& m_ds;

    const static float kFwdDecay = 0.5;
    const static float kTurnDecay = 0.5;
};

#endif
