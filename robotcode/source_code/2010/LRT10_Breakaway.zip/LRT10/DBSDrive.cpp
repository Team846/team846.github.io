//Author: David Liu (2009)

#include "DBSDrive.h"
#include "LRTConfig.h"
#include "LRTUtil.h"
#include <cmath>

//***********************************************************************
DBSDrive::DBSDrive(
    LRTesc& leftDrive, LRTesc& rightDrive,
    int maxBraking, bool isSquaredInputs
)
    : DriveMethod(leftDrive, rightDrive),
      m_maxBraking(maxBraking),
      m_isSquaredInputs(isSquaredInputs),
      m_prefix("DBSDrive."),
      m_ds(*DriverStation::GetInstance())
{
    ApplyConfig();
}

DBSDrive::~DBSDrive()
{
    // nothing to do
}

void DBSDrive::SetSquaredInputsEnabled(bool enabled)
{
    m_isSquaredInputs = enabled;
}

void DBSDrive::ApplyConfig()
{
    LRTConfig& config = LRTConfig::GetInstance();

    m_turnInPlaceThreshold = config.Get(m_prefix + "turnInPlaceThreshold", 10. / 128);
    m_brakeTurnDeadband = config.Get(m_prefix + "brakeTurnDeadband", 25. / 128);
}

DriveOutput DBSDrive::ComputeArcadeDrive(float forward, float turn)
{
    if(m_isSquaredInputs)
    {
        forward = LRTUtil::sign<float>(forward) * forward * forward;
        turn = LRTUtil::sign<float>(turn) * turn * turn;
    }

    enum {CW,  CCW}   turnDir;
    enum {LEFT, RIGHT} inboardSide;
    int brakeAmt;
    DriveOutput out;

    if(fabs(forward) < m_turnInPlaceThreshold)  // Normal turn-in-place
    {
        out.left  = -turn;
        out.right = +turn;
        m_leftDrive.SetCoast();
        m_rightDrive.SetCoast();
    }
    else    // Use DitherBraking
    {
        out.left  = forward - turn;
        out.right = forward + turn;

        if(turn >= 0)
        {
            turnDir = CCW;
            inboardSide = (forward >= 0 ? LEFT : RIGHT);
        }
        else
        {
            turnDir = CW;
            inboardSide = (forward >= 0 ? RIGHT : LEFT);
        }

        // If we're turning within the deadband, then we only scale
        // down the power on one side. If we exceed the deadband,
        // then we apply successively greater braking to that side.

        float absTurn = fabs(turn);
        if(absTurn < m_brakeTurnDeadband)
        {
            float inboardSidePower = forward - (forward * absTurn / m_brakeTurnDeadband);
            if(inboardSide == LEFT)
                out.left  = inboardSidePower;
            else
                out.right = inboardSidePower;
        }
        else    // Use Dithered braking
        {
            if(m_ds.GetDigitalIn(5))
                return out;

            brakeAmt = (int)(
                    (absTurn - m_brakeTurnDeadband)
                    * (m_maxBraking + 1) / (1 - m_brakeTurnDeadband)
                    ); // FIXME: make sure this int cast is okay.
            // brakeAmt on range {0, maxBraking}

            if(inboardSide == LEFT)
            {
                out.left  = 0;
                m_leftDrive.ApplyBrakes(brakeAmt);
            }
            else
            {
                out.right = 0;
                m_rightDrive.ApplyBrakes(brakeAmt);
            }
        }
    }

    return out;
}
