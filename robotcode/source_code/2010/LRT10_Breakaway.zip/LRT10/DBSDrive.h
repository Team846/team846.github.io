//Author: David Liu (2009)

#ifndef DBSDRIVE_H
#define DBSDRIVE_H

#include "WPILib.h"
#include "Brake.h"
#include "DriveMethod.h"

class DBSDrive : public DriveMethod
{
protected:
    int m_maxBraking;
    bool m_isSquaredInputs;
    string m_prefix;
    float m_turnInPlaceThreshold;
    float m_brakeTurnDeadband;

public:
    DBSDrive(
        LRTesc& leftDrive, LRTesc& rightDrive,
        int maxBraking, bool isSquaredInputs
    );
    virtual ~DBSDrive();

    void ApplyConfig();
    void SetSquaredInputsEnabled(bool enabled);
    virtual DriveOutput ComputeArcadeDrive(float forward, float turn);
private:
    DriverStation& m_ds;
};

#endif /* DBSDRIVE_H */
