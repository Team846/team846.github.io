//Author: Brandon Liu and David Liu (2010)

#include "WPILib.h"
#include "LRTIterativeRobot.h"
#include "LRTConnections.h"
#include "LRTDriverStationLCD.h"
#include "LRTDriverControls.h"
#include "DBSDrive.h"
#include "LRTKicker.h"
#include "LRTDriveEncoders.h"
#include "LRTKicker.h"
#include "SafeCANJaguar.h"
#include "LRTConfig.h"
#include "LRTGearBox.h"
#include "LRTWinch.h"
#include "LRTLift.h"
#include "LRTConsole.h"
#include "CANJaguarBrake.h"
#include "Profiler.h"
#include <string>
#include "LRTRoller.h"
#include "AsynchronousPrinter.h"
#include "CANBusController.h"
#include "ProxiedCANJaguar.h"
#include <iostream>
#include <fstream>
#include <Timer.h>
#include "ClosedLoopDriveTrain.h"
#include "Autonomous/LRTAuton.h"
#include "LineSensor.h"
#include "sysLib.h" // for sysClkRateGet

class LRTBot10 : public LRTIterativeRobot
{
    LRTConfig& m_config;
	LineSensor m_lineSense;
    DriverStation& m_ds;
    LrtLcd& m_dsLcd;

    CANBusController& m_canBusController;
    LRTDriverControls m_controls;

    // Drive Train
    LRTDriveEncoders& m_driveEncoders;
    LRTesc m_escLeft, m_escRight;
    Victor m_escWinch;
    ProxiedCANJaguar m_escArm, m_escRoller;

    LRTGearBox m_gearboxLeft, m_gearboxRight;
    DBSDrive m_dbsDrive;
    ClosedLoopDriveTrain m_robotDrive;

    LRTKicker m_kicker;
    LRTWinch m_winch;
    LRTLift m_lift;
    LRTRoller m_roller;

    LRTAuton m_auton;
    LRTConsole& m_console;

    // used for service mode - direct access to spikes/jags
    Relay m_relayKicker, m_relayLift;
    bool m_isServiceMode, m_isTestMode;

    enum GameState
    {
        kNothing,
        kHasEnteredAutonomous,
        kHasEnteredAutonomousFollowedByTeleop
    };

    // heuristic for determining if we were on the field or not
    struct
    {
        GameState state;
        double teleopStartTime;
    } m_gameState;

    const char* m_loadArray;

    bool m_isAutonomousInTeleop;
    bool m_isGameControllerEnabled;

public:
    LRTBot10()
        : m_config(LRTConfig::GetInstance())
        , m_lineSense(3,8,7)
        , m_ds(*DriverStation::GetInstance())
        , m_dsLcd(LrtLcd::GetInstance())
        , m_canBusController(CANBusController::GetInstance())

        , m_controls()
        , m_driveEncoders(LRTDriveEncoders::GetInstance())

        , m_escLeft(LRTConnections::kCanDriveLeft, m_driveEncoders.GetLeftEncoder(), "left")
        , m_escRight(LRTConnections::kCanDriveRight, m_driveEncoders.GetRightEncoder(), "right")

        , m_escWinch(LRTConnections::kPwmWinch)
        , m_escArm(LRTConnections::kCanArm)
        , m_escRoller(LRTConnections::kCanRoller)

        , m_gearboxLeft(string("Left"), m_escLeft, LRTConnections::kPwmShifterLeft)
        , m_gearboxRight(string("Right"), m_escRight, LRTConnections::kPwmShifterRight)

        , m_dbsDrive(m_escLeft, m_escRight, LRTConnections::kMaxBraking, false)
        , m_robotDrive(m_escLeft, m_escRight, m_driveEncoders, m_dbsDrive)

        , m_kicker()
        , m_winch(m_escWinch)
        , m_lift(m_escArm)
        , m_roller(m_escRoller, m_driveEncoders)

        , m_auton(m_robotDrive, m_driveEncoders, m_kicker, m_roller)
        , m_console(LRTConsole::GetInstance())

        , m_relayKicker(LRTConnections::kRelayKicker)
        , m_relayLift(LRTConnections::kRelayLiftRaiser)

        , m_isServiceMode(false)
        , m_isTestMode(false)

        , m_loadArray("\\|/-") // used for heartbeat

        , m_isAutonomousInTeleop(false)
        , m_isGameControllerEnabled(false)
    {
        AsynchronousPrinter::Printf("LRTBot10 Constructor Started\n");
        RobotInit();
        AsynchronousPrinter::Printf("LRTBot10 Constructor Completed\n");
    }


    /* Init Routines **************************************************************/

    void RobotInit()
    {
        AsynchronousPrinter::Printf("RobotInit() Started\n");

        m_gameState.state = kNothing;
        InitGearBoxListeners();

        // Actions which would be performed once (and only once) upon initialization of the
        // robot would be put here.

        AsynchronousPrinter::Printf("RobotInit() Completed\n");
    }

    void DisabledInit()
    {
        m_auton.EndAuton();

        m_isAutonomousInTeleop = false;
        m_isGameControllerEnabled = false;

        AsynchronousPrinter::Printf("Rechecking CANJaguars.\n");
        //m_canBusController.Enumerate();

        m_lift.StopLift();
        if(m_gameState.state == kHasEnteredAutonomousFollowedByTeleop)
        {
            LogPostGameData();
            m_gameState.state = kNothing;
        }
    }

    void AutonomousInit()
    {
        AsynchronousPrinter::Printf("Autonomous Init\n");

        m_roller.SetEnabled(true);
        m_isGameControllerEnabled = false;

        m_gearboxLeft.ShiftTo(LRTGearBox::kHighGear);
        m_gearboxRight.ShiftTo(LRTGearBox::kHighGear);

        m_gameState.state = kHasEnteredAutonomous;
        packetsMissedInLifetime = 0;

        /*
        if (!m_kicker.GetSense())
            m_kicker.Release();

        if (!m_kicker.GetSense())
            m_kicker.Release();
        */

        float autonomousDelay = m_ds.GetAnalogIn(4); // between 0 and 5 seconds
        Wait(autonomousDelay); // cannot be interrupted

        StartAutonomous();
    }

    // definitions for starting autonomous
    void StartAutonomous()
    {
        if(m_ds.GetDigitalIn(1))  // far field
            m_auton.StartFarField();
        else if(m_ds.GetDigitalIn(2))  // middle field
            m_auton.StartMiddleField();
        else if(m_ds.GetDigitalIn(3))  // near field
            m_auton.StartNearFieldStraightKick();
        else if(m_ds.GetDigitalIn(8))
            m_auton.StartTestAuton();
    }

    void TeleopInit()
    {
        m_auton.EndAuton();

        m_isAutonomousInTeleop = false;
        m_isGameControllerEnabled = false;

        m_gearboxLeft.ShiftTo(LRTGearBox::kHighGear);
        m_gearboxRight.ShiftTo(LRTGearBox::kHighGear);

        if(m_gameState.state == kHasEnteredAutonomous)
        {
            m_gameState.state = kHasEnteredAutonomousFollowedByTeleop;
            m_gameState.teleopStartTime = Timer::GetFPGATimestamp();
        }
    }

    void TestModeInit()
    {
        m_lift.SetTestMode(true);
    }

    void TestModeExit()
    {
        m_lift.SetTestMode(false);
    }

    void ServiceModeInit()
    {
        m_kicker.Disable();

        m_gearboxLeft.SetServiceMode(true);
        m_gearboxRight.SetServiceMode(true);
    }

    void ServiceModeExit()
    {
        m_kicker.Enable();

        m_gearboxLeft.SetServiceMode(false);
        m_gearboxRight.SetServiceMode(false);
    }

    void InitGearBoxListeners()
    {
        m_gearboxLeft.RegisterGearBoxListener(&m_driveEncoders);
        m_gearboxLeft.RegisterGearBoxListener(&m_robotDrive);
    }

    void LogPostGameData()
    {
        ofstream log("/gamelog.txt", ios::app);
        double stamp = Timer::GetFPGATimestamp();

        log << "\n";

        log << "[" << stamp << "] missed " << packetsMissedInLifetime;
        log << " over " << stamp - m_gameState.teleopStartTime << "\n";

        log << "Min Cycle Time: " << m_minCycleTime << "\n";
        log << "Max Cycle Time: " << m_maxCycleTime << "\n";

        log.close();
    }

    /* Periodic Routines **********************************************************/

    void ApplyConfig()
    {
        m_gearboxLeft.ApplyConfig();
        m_gearboxRight.ApplyConfig();
        m_kicker.ApplyConfig();
        m_lift.ApplyConfig();
        m_roller.ApplyConfig();
        m_robotDrive.ApplyConfig();
        m_escLeft.ApplyConfig();
        m_escRight.ApplyConfig();
//      m_auton.ApplyConfig();

        // put all apply config's here
    }

    void TestCode()
    {
        m_console.PrintMultipleTimesPerSecond(0.25,
                "ShiftL:%.3f R:%.3f\n", m_gearboxLeft.GetServo().Get()
                , m_gearboxRight.GetServo().Get());

        m_console.PrintMultipleTimesPerSecond(0.25, "PulseCountLeft: %d  Right: %d\n",
                m_gearboxLeft.GetPulseCount(), m_gearboxRight.GetPulseCount());

        m_console.PrintMultipleTimesPerSecond(0.25, "Gearbox state Left: %d, Right: %d\n",
                m_gearboxLeft.GetState(), m_gearboxRight.GetState());
    }

    void OutputLCDStatuses()
    {
        char beat = m_loadArray[(m_commonLoops / 12) % 4];

        string mode = "Normal Mode";
        if(m_isServiceMode)
            mode = "**SERVICE MODE**";
        else if(m_isTestMode)
            mode = "**TEST MODE**";

        if(m_isGameControllerEnabled)
            mode += " GC";
        m_dsLcd.print(LrtLcd::kHeartbeatLine, "%c %s", beat, mode.c_str());

        // encoders may not be thread-safe - conflict with the auton task [BL]
        if(!IsAutonomous())
        {
            LrtLcd::GetInstance().print(LrtLcd::kEncoderLine,
                    "EncL=%.1f,R=%.1f,fwd=%.1f",
                    m_driveEncoders.GetLeftSpeed(),
                    m_driveEncoders.GetRightSpeed(),
                    m_driveEncoders.GetForwardSpeed()
                                       );
        }

        LrtLcd::GetInstance().print(LrtLcd::kLiftExtenderLine,
                "Arm=%d,Lift=%d,K%s",
                m_lift.GetArmPosition(), m_lift.GetLiftPosition(),
                m_kicker.GetSense() ? "!" : "-");

        LrtLcd::GetInstance().print(LrtLcd::kDriveLine,
                "Fw:%.3f Turn: %.3f",
                m_controls.GetForward(), m_controls.GetTurn());
    }

    void CommonPeriodic()
    {
        {
            ProfiledSection pf("CommonPeriodic");
            OutputLCDStatuses();

            {
                ProfiledSection pf("ConsoleOutput+Controls");
                m_console.NextCycle();

                m_controls.Update(); // need to update debouncing
            }

            {
                // Uncomment to use test code
                // ProfiledSection pf("TestCode");
                // TestCode();
            }

            // update the LCD at 4Hz
            if(m_commonLoops % 12 == 0)
            {
                ProfiledSection pf("LCDUpdate");
                m_dsLcd.LCDUpdate();
            }

            HandleServiceModeEntryControls();
            HandleLCDScrollControls();

            if(m_isServiceMode && !IsAutonomous())
                ServiceMode();
            else
            {
                {
                    ProfiledSection pf("HandleConfig");
                    HandleConfig();
                }
            }
        }
    }

    void EnabledPeriodic()
    {
        {
            ProfiledSection pf("ApplyingOutputs");

            if(!m_isAutonomousInTeleop)
            {
                // update braking
                m_escLeft.UpdateOutput();
                m_escRight.UpdateOutput();

                m_winch.ApplyOutput();

                {
                    ProfiledSection pf("ApplyingOutputs.Lift");
                    m_lift.ApplyOutput();
                }

                {
                    ProfiledSection pf("ApplyingOutputs.Roller");
                    m_roller.ApplyOutput(50 * m_controls.GetDriverStick().GetRawAxisDelta(2));//50x is packet rate
                }
            }
        }
    }

    void ServiceMode()
    {
        HandleServiceLiftControls();
        HandleServiceWinchControls();
        HandleServiceKickerControls();
        HandleServiceAutonControls();
    }

    void DisabledPeriodic()
    {
        // nothing
    	m_lineSense.ResetFirstRun();
    }

    void AutonomousPeriodic()
    {
        // nothing
    }

    void CANDiagnostics(const char* name, CANJaguar& esc)
    {
        m_console.PrintEveryHalfSecond("%s=> ", name);

        m_console.PrintEveryHalfSecond("Bus: %5.2f V ", esc.GetBusVoltage());
        m_console.PrintEveryHalfSecond("Out: %6.2f V ", esc.GetOutputVoltage());

        m_console.PrintEveryHalfSecond("Cur: %4.1f A ", esc.GetOutputCurrent());
        m_console.PrintEveryHalfSecond("Temp: %5.1f Deg C ", esc.GetTemperature());

        m_console.PrintEveryHalfSecond("LimSw: %s%s ", esc.GetForwardLimitOK() ? "F" : "-",
                esc.GetReverseLimitOK() ? "R" : "-");
        m_console.PrintEveryHalfSecond("PwrCyc: %d ", esc.GetPowerCycled() ? 1 : 0);

        m_console.PrintEveryHalfSecond("\n");
    }

    void TeleopPeriodic()
    {
        {
            ProfiledSection pf("TeleopPeriodic");
            if(m_isServiceMode)
                return;

            // don't send signals in teleop if we're running autonomous [BL]
            if(m_isAutonomousInTeleop)
                return;

            HandleGameControllerEntryExitControls();
            if(m_isGameControllerEnabled)
            {
                HandleGameControllerControls();
                return;
            }

            ///Do linesensing stuff here
            //AsynchronousPrinter::Printf("Pos of line %.3f\n", lineSense.GetLinePosition());
//            float position;
            {
            	ProfiledSection pf("Get Line Position");
//            	AsynchronousPrinter::Printf( "Line Position %.2f\n", m_lineSense.GetLinePosition() );
//            	position = m_lineSense.GetLinePosition();
            	SmartDashboard::Log( (int) m_lineSense.Read(4000), "Reading Status" );
//            	SmartDashboard::Log( position, "Line Position" );
            }
            
//            AsynchronousPrinter::Printf("Sys clock rate get: %d\n", sysClkRateGet());
            
//            static int i, e;
//            if (e++%10==0)
//            	SmartDashboard::Log(i++%8,"hi world");
            
//            position *= 1;
//            if(m_lineSense.IsOnLine())
//            	m_robotDrive.ArcadeDrive(-0.1, 0);
//            else
//            	m_robotDrive.ArcadeDrive(0, position);
            
//            if(!m_controls.GetLeftPivot() && !m_controls.GetRightPivot())
//            {
//                m_robotDrive.ArcadeDrive(m_controls.GetForward(), m_controls.GetTurn());
//            	if(m_controls.GetTestMode())
//            		m_robotDrive.ArcadeDrive(m_controls.GetForward(), LRTUtil::Min<float>(m_lineSense.GetLinePosition(), -m_controls.GetForward()));
//            }
//            else if(m_controls.GetLeftPivot() && m_controls.GetRightPivot())
//            {
//                m_escLeft.Stop();
//                m_escRight.Stop();
//            }
//            else if(m_controls.GetLeftPivot())
//                m_robotDrive.PivotLeft(m_controls.GetForward());
//            else if(m_controls.GetRightPivot())
//                m_robotDrive.PivotRight(m_controls.GetForward());

            m_dsLcd.print(LrtLcd::kDriveLine2, "L:%.3f R:%.3f", m_escLeft.Get(), m_escRight.Get());

            ProfilerHelper pfh;

            pfh.Start("Teleop.Kicker");
            HandleKickerControls();
            pfh.Finish();

            pfh.Start("Teleop.Winch");
            HandleWinchControls();
            pfh.Finish();

            pfh.Start("Teleop.Lift");
            HandleLiftControls();
            pfh.Finish();

            pfh.Start("Teleop.Gearbox");
            HandleGearBoxControls(); //Uncomment when ready to test gearboxes
            pfh.Finish();

            pfh.Start("Teleop.Roller");
            HandleRollerControls();
            pfh.Finish();

            if(m_controls.GetAbortButton())
            {
                m_kicker.Stop();
                m_lift.AbortArm();
                m_lift.AbortLift();
            }

            // Used for testing encoder rate at SVR [KV]
            {
                ProfiledSection pf("EncoderPrinting");

//              m_console.PrintMultipleTimesPerSecond( 3, "Left Rate: %.2f, Right Rate: %.2f, Turn Rate: %.2f\n", m_driveEncoders.GetLeftSpeed(), m_driveEncoders.GetRightSpeed(), m_driveEncoders.GetTurningSpeed() );
//              m_console.PrintMultipleTimesPerSecond( 3, "Left Rate: %.2f, Right Rate: %.2f, Forward Rate: %.2f\n", m_driveEncoders.GetNormalizedLeftSpeed(), m_driveEncoders.GetNormalizedRightSpeed(), m_driveEncoders.GetNormalizedForwardSpeed() );

//              static int count = 0;
//              if (count++%3==0)
//                  AsynchronousPrinter::Printf("Turn ticks: %.1f, Turn speed: %.3f\n", m_driveEncoders.GetTurnTicks(), m_driveEncoders.GetTurningSpeed());
            }
        }
    }

    /* CONTROL ROUTINES ***********************************************************/

    void HandleLCDScrollControls()
    {
        // driver Station LCD Scrolling
        if(m_controls.GetLCDScrollUp())
            m_dsLcd.ScrollLCD(0, -2);
        else if(m_controls.GetLCDScrollDown())
            m_dsLcd.ScrollLCD(0, 2);
        else if(m_controls.GetLCDScrollLeft())
            m_dsLcd.ScrollLCD(-7, 0);
        else if(m_controls.GetLCDScrollRight())
            m_dsLcd.ScrollLCD(7, 0);
    }

    void HandleConfig()
    {
        {
            ProfiledSection pf("HandleConfig.ButtonHandling");
            // operator Button 2 and 11 (press 2 first)
            if(m_controls.GetSaveConfigButton())
            {
                AsynchronousPrinter::Printf("SAVE CONFIG\n");
                m_config.Save();
            }

            // Operator Button 2 and 9 (press 2 first)
            else if(m_controls.GetReloadConfigButton())
            {
                ProfilerHelper pf;
                AsynchronousPrinter::Printf("RELOAD CONFIG\n");

                pf.Start("HandleConfig.ButtonHandling.load");
                m_config.Load();
                pf.Finish();

                pf.Start("HandleConfig.ButtonHandling.Apply");
                ApplyConfig();
                pf.Finish();

                pf.Start("HandleConfig.ButtonHandling.Save");
                m_config.Save(); // cause any missing variables to be automatically regenerated.
                pf.Finish();
            }

            // Operator Button 2 and 7 (press 2 first)
            else if(m_controls.GetApplyConfigButton())
            {
                AsynchronousPrinter::Printf("APPLY CONFIG\n");
                ApplyConfig();
            }
        }

        float assignableAnalogs[4];
        {
            ProfiledSection pf("HandleConfig.GetAnalogs");
            for(int i = 0; i < 4; ++i)
                assignableAnalogs[i] = m_ds.GetAnalogIn(i + 1);
        }

        {
            ProfiledSection pf("HandleConfig.UpdateAssignable");
            m_config.UpdateAssignableControls(assignableAnalogs);
        }
    }

    void HandleKickerControls()
    {
        if(m_controls.GetKickerRelease())
            m_kicker.Release();
    }

    void HandleRollerControls()
    {
        if(m_roller.IsRollerButtonToggling())
        {
        	if(m_controls.GetToggleRoller())
        		m_roller.SetEnabled(!m_roller.GetEnabled());
        }
        else
            m_roller.SetEnabled(!m_controls.GetDisableRoller());

        if(m_controls.GetReverseRoller())
        {
            m_console.PrintEverySecond("Reversing Roller\n");
            m_roller.SetReverse(true);
        }
        else
            m_roller.SetReverse(false);
    }

    void HandleWinchControls()
    {
        if(m_controls.GetRetractWinch())
            m_winch.RetractWinch();
        else if(m_controls.GetReleaseWinch())
            m_winch.ReleaseWinch();
    }

    void HandleLiftControls()
    {
        // driver or Operator Button 3
        if(m_controls.GetArmVerticalThenLiftExtend())
        {
            AsynchronousPrinter::Printf("lift and arm going to extend\n");

            m_lift.ActivatePreset(LRTLift::kArmVertical);
            m_lift.ActivatePreset(LRTLift::kLiftExtended);
        }
        else if(m_controls.GetArmMiddleAndLiftMiddle())
        {
            AsynchronousPrinter::Printf("arm and lift going to middle\n");

            m_lift.ActivatePreset(LRTLift::kArmMiddle);
            m_lift.ActivatePreset(LRTLift::kLiftMiddle);
        }
        else if(m_controls.GetLiftExtend())
        {
            AsynchronousPrinter::Printf("Fully extending lift\n");

            m_lift.ActivatePreset(LRTLift::kLiftExtended);
        }
        else if(m_controls.GetLiftUp())
        {
            m_console.PrintEverySecond("Extending lift\n");

            m_lift.LiftExtend();
        }
        else if(m_controls.GetLiftDown())
        {
            m_console.PrintEverySecond("Retracting lift\n");

            m_lift.LiftRetract();
        }
        else if(m_controls.GetLiftHome())
        {
            AsynchronousPrinter::Printf("lift going to home\n");

            m_lift.ActivatePreset(LRTLift::kLiftHome);
        }
        else if(m_controls.GetLiftHomeThenArmHome())
        {
            AsynchronousPrinter::Printf("lift and arm going to home\n");

            m_lift.ActivatePreset(LRTLift::kLiftHome);
            m_lift.ActivatePreset(LRTLift::kArmHome);
        }
        else if(m_controls.GetLiftHomeThenArmMiddle())
        {
            AsynchronousPrinter::Printf("lift to home and arm to middle\n");

            m_lift.ActivatePreset(LRTLift::kLiftHome);
            m_lift.ActivatePreset(LRTLift::kArmMiddle);
        }

        if(m_controls.GetArmVertical())
        {
            AsynchronousPrinter::Printf("Arm going vertical\n");

            m_lift.ActivatePreset(LRTLift::kArmVertical);
        }
        else if(m_controls.GetArmUp())
        {
            m_console.PrintEverySecond("Raising arm\n");

            m_lift.ArmShiftUp();
        }
        else if(m_controls.GetArmDown())
        {
            m_console.PrintEverySecond("Lowering arm\n");

            m_lift.ArmShiftDown();
        }
        else if(m_controls.GetArmSpeedControlled())
            m_lift.RunArm(m_controls.GetArmSpeed());
    }

    void HandleGearBoxControls()
    {
        // removed shifting
    }

    /* SERVICE MODE CONTROLS ******************************************************/

    void HandleServiceModeEntryControls()
    {
        if(m_isServiceMode)
        {
            // user flipped out of service mode
            if(!m_controls.GetServiceMode())
            {
                AsynchronousPrinter::Printf("Service Mode EXITED\n");

                m_isServiceMode = false;
                ServiceModeExit();
            }
        }
        else
        {
            // user flipped to service mode
            if(m_controls.GetServiceMode())
            {
                AsynchronousPrinter::Printf("Service Mode ENTERED\n");

                m_isServiceMode = true;
                ServiceModeInit();
            }
        }

        if(!m_isServiceMode)
        {
            if(m_isTestMode)
            {
                // user flipped out of test mode
                if(!m_controls.GetTestMode())
                {
                    AsynchronousPrinter::Printf("Test Mode EXITED\n");

                    m_isTestMode = false;
                    TestModeExit();
                }
            }
            else
            {
                // user flipped to test mode
                if(m_controls.GetTestMode())
                {
                    AsynchronousPrinter::Printf("Test Mode ENTERED\n");

                    m_isTestMode = true;
                    TestModeInit();
                }
            }
        }
    }

    void HandleServiceLiftControls()
    {
        // Operator Button 9
        if(m_controls.GetServiceSetArmVertical())
        {
            AsynchronousPrinter::Printf("Service: Setting Arm Vertical Preset\n");
            m_lift.SavePreset(LRTLift::kArmVertical);
        }

        // Operator button 7
        if(m_controls.GetServiceSetArmMiddle())
        {
            AsynchronousPrinter::Printf("Service: Setting Arm Middle Preset\n");
            m_lift.SavePreset(LRTLift::kArmMiddle);
        }

        // Operator Button 8
        if(m_controls.GetServiceSetLiftMiddle())
        {
            AsynchronousPrinter::Printf("Service: Setting Lift Middle Preset\n");
            m_lift.SavePreset(LRTLift::kLiftMiddle);
        }

        // Operator Button 10
        if(m_controls.GetServiceSetLiftExtended())
        {
            AsynchronousPrinter::Printf("Service: Setting Lift Extended Preset\n");
            m_lift.SavePreset(LRTLift::kLiftExtended);
        }

        // Operator Button 11
        if(m_controls.GetServiceSetArmHome())
        {
            AsynchronousPrinter::Printf("Service: Setting Arm Home Preset\n");
            m_lift.SavePreset(LRTLift::kArmHome);
        }

        // Operator Button 12
        if(m_controls.GetServiceSetLiftHome())
        {
            AsynchronousPrinter::Printf("Service: Setting Lift Home Preset\n");
            m_lift.SavePreset(LRTLift::kLiftHome);
        }

        // Driver Button 10 - need to hold
        if(m_controls.GetServiceLiftUp())
        {
            m_console.PrintEverySecond("Service: Lift up\n");
            m_lift.RunLiftUp();
        }

        // Driver Button 12 - need to hold
        else if(m_controls.GetServiceLiftDown())
        {
            m_console.PrintEverySecond("Service: Lift down\n");
            m_lift.RunLiftDown();
        }
        else
            m_lift.StopLift();

        // Driver Button 9 - need to hold
        if(m_controls.GetServiceArmUp())
        {
            m_console.PrintEverySecond("Service: Arm up\n");
            m_lift.RunArm(0.35);
        }

        // Driver Button 11 - need to hold
        else if(m_controls.GetServiceArmDown())
        {
            m_console.PrintEverySecond("Service: Arm down\n");
            m_lift.RunArm(-0.35);
        }
        else
            m_lift.StopArm();
    }

    void HandleServiceWinchControls()
    {
        if(m_controls.GetServiceRetractWinch())
        {
            m_console.PrintEverySecond("Service: Retracting Winch\n");
            m_winch.RetractWinch();
        }
        else if(m_controls.GetServiceReleaseWinch())
        {
            m_console.PrintEverySecond("Service: Releasing Winch\n");
            m_winch.ReleaseWinch();
        }
    }

    void HandleServiceKickerControls()
    {
        if(m_controls.GetServiceKickerGo())
        {
            m_console.PrintEverySecond("Service: Kicker Going\n");
            m_kicker.Release();
        }
        else if(m_controls.GetServiceKickerPulseReverse())
        {
            m_console.PrintEverySecond("Service: Kicker Reversing\n");
            m_kicker.UnwindPulse();
        }
    }

    void HandleServiceAutonControls()
    {
        // nothing
    }

    /* GAME CONTROLLER CONTROLS ***************************************************/
    void HandleGameControllerEntryExitControls()
    {
        if(m_controls.GetControllerEnabled())
            m_isGameControllerEnabled = true;

        if(m_controls.GetControllerDisabled())
            m_isGameControllerEnabled = false;
    }

    void HandleGameControllerControls()
    {
        // Kicker
        if(m_controls.GetControllerPulseUnwindKicker())
            m_kicker.UnwindPulse();
        else if(m_controls.GetControllerPulseWindKicker())
            m_kicker.WindPulse();

        // Arm
        if(m_controls.GetControllerArmUp())
        {
            m_console.PrintEverySecond("Controller Arm Up\n");
            m_escArm.Set(0.35);
        }
        else if(m_controls.GetControllerArmDown())
        {
            m_console.PrintEverySecond("Controller Arm Down\n");
            m_escArm.Set(-0.35);
        }
        else
            m_escArm.Set(0);

        // Lift
        if(m_controls.GetControllerLiftUp())
        {
            m_console.PrintEverySecond("Controller Lift Up\n");
            m_relayLift.Set(LRTLift::kLiftUp);
        }
        else if(m_controls.GetControllerLiftDown())
        {
            m_console.PrintEverySecond("Controller Lift Down\n");
            m_relayLift.Set(LRTLift::kLiftDown);
        }
        else
            m_relayLift.Set(Relay::kOff);


        if(m_teleopInitialized && !m_isAutonomousInTeleop && m_controls.GetControllerStartAutonomous())
        {
            AsynchronousPrinter::Printf("Starting Autonomous in Teleoperated\n");

            StartAutonomous();
            m_isAutonomousInTeleop = true;
        }
        if(m_controls.GetControllerAbortAutonomous())
        {
            AsynchronousPrinter::Printf("Ending Autonomous in Teleoperated\n");

            m_auton.EndAuton();
            m_isAutonomousInTeleop = false;
        }
    }
};

START_ROBOT_CLASS(LRTBot10);
