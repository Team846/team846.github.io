//Author: Brian Axelrod and David Liu (2010)

#ifndef LRT_CONFIG_H_
#define LRT_CONFIG_H_

#include "WPILib.h"
#include <map>
#include <string>

class LRTConfig : public SensorBase
{

public:
    const static int kNumAnalogAssignable = 4;

    virtual ~LRTConfig() { }
    static LRTConfig& GetInstance();

    bool Load(string path = "/LRTConfig.txt");
    bool Save(string path = "/LRTConfig.txt");

    float ScaleAssignableAnalogValue(float value, int analogIndex);
    void UpdateAssignableControls(float analog[kNumAnalogAssignable]);

    template <typename T>
    T Get(string key);
    template <typename T>
    T Get(string key, T defaultValue);
    template <typename T>
    void Set(string key, T val);

protected:
    LRTConfig();

private:
    static LRTConfig* m_instance;
    DISALLOW_COPY_AND_ASSIGN(LRTConfig);

    map<string, string> m_configData;
    void Log(string key, string oldval, string newval);
    map<string, string> tload(string path);

    string m_analogAssignments[kNumAnalogAssignable];
    float m_analogAssignmentScaleMin[kNumAnalogAssignable];
    float m_analogAssignmentScaleMax[kNumAnalogAssignable];
};

#endif
