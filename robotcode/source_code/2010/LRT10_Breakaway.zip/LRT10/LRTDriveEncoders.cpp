//Author: Karthik Viswanathan (2010)

#include "WPILib.h"
#include "LRTConnections.h"
#include "LRTDriveEncoders.h"

LRTDriveEncoders* LRTDriveEncoders::instance = NULL;
float LRTDriveEncoders::s_maxEncoderRate = LRTDriveEncoders::kLowGearMaxEncoderRate;
float LRTDriveEncoders::s_maxTurningRate = LRTDriveEncoders::kLowGearMaxTurningRate;

LRTDriveEncoders& LRTDriveEncoders::GetInstance()
{
    if(instance == NULL)
        instance = new LRTDriveEncoders();
    return *instance;
}

LRTDriveEncoders::LRTDriveEncoders()
    : m_encoderLeft(LRTConnections::kDioEncoderLeftA, LRTConnections::kDioEncoderLeftB)
    , m_encoderRight(LRTConnections::kDioEncoderRightA, LRTConnections::kDioEncoderRightB)
{
    m_encoderLeft.SetDistancePerPulse(1); // want to stay with ticks/second
    m_encoderRight.SetDistancePerPulse(1);

    m_encoderLeft.Start();
    m_encoderRight.Start();
}

LRTDriveEncoders::~LRTDriveEncoders()
{
    // nothing
}

double LRTDriveEncoders::GetNormalizedForwardSpeed()
{
    return LRTUtil::clamp<double>(GetForwardSpeed() / s_maxEncoderRate, -1.0, 1.0);
}

double LRTDriveEncoders::GetNormalizedForwardSpeedWithHighGear()
{
    return LRTUtil::clamp<double>(GetForwardSpeed() / kHighGearMaxEncoderRate, -1.0, 1.0);
}

double LRTDriveEncoders::GetForwardSpeed()
{
    SmartDashboard::Log(m_encoderLeft.Get(), "Left ticks");
    SmartDashboard::Log(m_encoderLeft.GetRate(), "Left rate");
    SmartDashboard::Log(m_encoderRight.Get(), "Right ticks");
    SmartDashboard::Log(m_encoderRight.GetRate(), "Right rate");
    return (m_encoderLeft.GetRate() + m_encoderRight.GetRate()) / 2;
}

inline double LRTDriveEncoders::GetTurningSpeed()
{
    // turn > 0 is ccw
    return (m_encoderRight.GetRate() - m_encoderLeft.GetRate()) / 2; // fix GetRate error in WPILib
}

// CalGames:
//  10-15-10 6 turns is approx. 6725 ticks +/- 15
//  6 turns in 20.3 s +/- 0.2
double LRTDriveEncoders::GetNormalizedTurningSpeed()
{
    // SVR
//  return GetTurningSpeed() / (2 * s_maxTurningRate);

    // Calgames
    return GetTurningSpeed() / kMaxTurningRate;
}

double LRTDriveEncoders::GetLeftSpeed()
{
    return m_encoderLeft.GetRate();
}

double LRTDriveEncoders::GetRightSpeed()
{
    return m_encoderRight.GetRate();
}

double LRTDriveEncoders::GetRobotDist()
{
    return (GetLeftWheelDist() + GetRightWheelDist()) / 2;
}

// CCW is positive, CW is negative
double LRTDriveEncoders::GetTurnTicks()
{
    return m_encoderRight.Get() - m_encoderLeft.Get();
}

double LRTDriveEncoders::GetLeftWheelDist()
{
    // - Get() returns pulses
    // - kPulsesPerRevolution is in pulses / revolution
    // - kWheelDiameter * kPi is the circumference / revolution
    // in centimeters

    // ( pulses / second ) / ( pulses / revolution )
    // * ( circumference / revolution ) = centimeter distance
    return m_encoderLeft.Get() / kPulsesPerRevolution * kWheelDiameter * kPi;
}

double LRTDriveEncoders::GetRightWheelDist()
{
    // see GetLeftWheelDist() for calculation explanation
    return m_encoderRight.Get() / kPulsesPerRevolution * kWheelDiameter * kPi;
}

double LRTDriveEncoders::GetNormalizedLeftSpeed()
{
    return LRTUtil::clamp<double>(GetLeftSpeed() / s_maxEncoderRate, -1.0, 1.0);
}

double LRTDriveEncoders::GetNormalizedRightSpeed()
{
    return LRTUtil::clamp<double>(GetRightSpeed() / s_maxEncoderRate, -1.0, 1.0);
}

void LRTDriveEncoders::NotifyGearChange(LRTGearBox::GearBoxState newstate)
{
    switch(newstate)
    {
    case LRTGearBox::kHighGear:
        s_maxEncoderRate = LRTDriveEncoders::kHighGearMaxEncoderRate;
        s_maxTurningRate = LRTDriveEncoders::kHighGearMaxTurningRate;
        break;

    case LRTGearBox::kLowGear:
    case LRTGearBox::kNeutralGear:
        s_maxEncoderRate = LRTDriveEncoders::kLowGearMaxEncoderRate;
        s_maxTurningRate = LRTDriveEncoders::kLowGearMaxTurningRate;
        break;
    }
}

LRTEncoder& LRTDriveEncoders::GetLeftEncoder()
{
    return m_encoderLeft;
}

LRTEncoder& LRTDriveEncoders::GetRightEncoder()
{
    return m_encoderRight;
}

double LRTDriveEncoders::GetTurnRevolutions()
{
    return (m_encoderRight.Get() - m_encoderLeft.Get()) / kTicksPerFullTurn;
}
