//Author: Karthik Viswanathan (2010)

#ifndef LRTENCODER_H_
#define LRTENCODER_H_

#include "Encoder.h"
#include "LRTUtil.h"
#include "LRTConnections.h"
#include "LRTGearBox.h"
#include "LRTEncoder.h"

class LRTDriveEncoders : public SensorBase, public GearBoxListener
{
private:
    static LRTDriveEncoders* instance;

    // useless encoders instantiated to bypass WPILib bug; only
    // even encoders work [KV] [BA]
    LRTEncoder m_encoderLeft, m_encoderRight;

    // floats to prevent integer division
    static const float kWheelDiameter = 8.0; // in

    // output sprocket:wheel sprocket = 36:48
    static const float kPi = 3.14159;
    static const float kTrackLength = 23.0; // in

protected:
    LRTDriveEncoders();
    DISALLOW_COPY_AND_ASSIGN(LRTDriveEncoders);

public:
    static LRTDriveEncoders& GetInstance();
    virtual ~LRTDriveEncoders();

    static float s_maxEncoderRate;
    static float s_maxTurningRate; // current max rate

#if defined(LRT_2010_ROBOT)
    // 333.3 * 9/16 = 187.48 due to new sprocket ratio
    static const float kPulsesPerRevolution = 187.5; // for competition robot [BA]

    // constants at SVR were wrong. Encoders are not affected by sprockets. [BA]
    const static float kHighGearMaxEncoderRate = 1411.96;
    const static float kLowGearMaxEncoderRate = 1411.96;

    // SVR sprocket changes
    const static float kHighGearMaxTurningRate = 3000 * 16. / 9.;
    const static float kLowGearMaxTurningRate = 3000 * 16. / 9.;

    // CalGames update
    const static double kMaxTurningRate = 6725. / 15.0;

    // Calgames - 10/19/10 [KV] [BA]
    const static double kTicksPerFullTurn = 6725. / 6;

    /* OLD, UNUSED VALUES ************************************************************

        // calculated values at SVR for closed loop drive trains
        const static double k1rps_TickRate = (4100.0/(6/14.4))*250./360;

        // 16000 ticks in 5 turns, found on 3/15/10 [BL]
        const static double kTicksPerFullTurn = (16000.0/5)*250./360.;

        // 9/16 multiplier due to new sprocket ratio (SVR)
        const static double k1rps_TickRate = (4100.0/(6/14.4))*250./360.*9./16.;

        // constants used at SVR after sprocket change
        const static float kHighGearMaxEncoderRate = 1411.96 * 16./9.;
        const static float kLowGearMaxEncoderRate = 1411.96 * 16./9.;

        // SVR turning rates
        const static float kHighGearMaxTurningRate = 7500;
        const static float kLowGearMaxTurningRate = 3000;

        // 16000 ticks in 5 turns, Found on 3/15/10 [BL] - Not used anymore

    *********************************************************************************/

#elif defined(LRT_2010_ROBOT_PRACTICE)
    // for practice robot [BA]
    static const float kPulsesPerRevolution = 480.0;

    const static float kHighGearMaxEncoderRate = 4800;
    const static float kLowGearMaxEncoderRate = 4800;

    const static float kHighGearMaxTurningRate = 1000; // TODO FIND THIS
    const static float kLowGearMaxTurningRate = 1000; // TODO FIND THIS

    const static double k1rps_TickRate = 4100.0 / (6 / 14.4);
    // 16000 ticks in 5 turns, found on 3/15/10 [BL]
    const static double kTicksPerFullTurn = 16000.0 / 5.;
#elif defined(LRT_2009_ROBOT)
    // nothing
#endif

    double GetNormalizedForwardSpeed();
    double GetNormalizedForwardSpeedWithHighGear();
    double GetForwardSpeed();
    double GetTurningSpeed();
    double GetNormalizedTurningSpeed();
    double GetLeftSpeed();
    double GetRightSpeed();
    double GetRobotDist();
    double GetTurnTicks();
    double GetTurnRevolutions();
    double GetLeftWheelDist();
    double GetRightWheelDist();
    double GetLeftWheelSpeed();
    double GetNormalizedLeftSpeed();
    double GetRightWheelSpeed();
    double GetNormalizedRightSpeed();
    virtual void NotifyGearChange(LRTGearBox::GearBoxState newstate);
    LRTEncoder& GetLeftEncoder();
    LRTEncoder& GetRightEncoder();
};
#endif /* LRTENCODER_H_ */
