//Author: Brandon Liu and David Liu (2009,2010)

#ifndef LRT_DRIVER_CONTROLS_H_
#define LRT_DRIVER_CONTROLS_H_

#include "SpeedController.h"
#include "Timer.h"
#include "Joystick.h"
#include "DriverStation.h"
#include "DebouncedJoystick.h"
#include "LRTUtil.h"
#include <algorithm>

class LRTDriverControls
{
protected:
    DebouncedJoystick driverStick, operatorStick;
    DebouncedJoystick gameController;

    const static int kNumButtons = 12;
    const static int kNumAxes = 6;

    const static int kNumControllerButtons = 12;
    const static int kNumControllerAxes = 4;
public:

    LRTDriverControls()
        : driverStick(1, kNumButtons, kNumAxes)
        , operatorStick(2, kNumButtons, kNumAxes)
        , gameController(3, kNumControllerButtons, kNumControllerAxes)
    {

    }

    void Update()
    {
        driverStick.Update();
        operatorStick.Update();
        gameController.Update();
    }

    DebouncedJoystick& GetDriverStick()
    {
        return driverStick;
    }
    DebouncedJoystick& GetOperatorStick()
    {
        return operatorStick;
    }
    DebouncedJoystick& GetGameController()
    {
        return gameController;
    }

    bool GetToggleGear()
    {
        return false;
    }

    bool GetAbortButton()
    {
        return driverStick.IsButtonJustPressed(2);
    }

    bool GetKickerRelease()
    {
        return driverStick.IsButtonJustPressed(4);
    }

    bool GetBrake()
    {
        return driverStick.IsButtonDown(10) || driverStick.IsButtonDown(9);
    }

    bool GetRightPivot()
    {
        return driverStick.IsButtonDown(9);
    }

    bool GetLeftPivot()
    {
        return driverStick.IsButtonDown(10);
    }

    bool GetLCDScrollLeft()
    {
        return IsOperatorShift() && operatorStick.IsButtonJustPressed(5);
    }

    bool GetLCDScrollRight()
    {
        return IsOperatorShift() && operatorStick.IsButtonJustPressed(6);
    }

    bool GetLCDScrollUp()
    {
        return operatorStick.IsHatSwitchJustPressed(6, -1);
    }

    bool GetLCDScrollDown()
    {
        return operatorStick.IsHatSwitchJustPressed(6, 1);
    }

    bool GetRetractWinch()
    {
        return driverStick.IsButtonDown(6) || operatorStick.IsButtonDown(2);
    }

    bool GetReleaseWinch()
    {
        return driverStick.IsButtonDown(7);
    }

    bool IsOperatorShift()
    {
        return operatorStick.IsButtonDown(1);
    }

    bool GetApplyConfigButton()
    {
        return IsOperatorShift() && operatorStick.IsButtonJustPressed(7);
    }

    bool GetReloadConfigButton()
    {
        return IsOperatorShift() && operatorStick.IsButtonJustPressed(9);
    }

    bool GetSaveConfigButton()
    {
        return IsOperatorShift() && operatorStick.IsButtonJustPressed(11);
    }

    bool GetArmVertical()
    {
        return !IsOperatorShift() && operatorStick.IsButtonJustPressed(7);
    }

    bool GetArmVerticalThenLiftExtend()
    {
        return operatorStick.IsButtonJustPressed(3);
    }

    bool GetLiftHomeThenArmMiddle()
    {
        return false;
    }

    bool GetLiftHomeThenArmHome()
    {
        return operatorStick.IsButtonJustPressed(4);
    }

    bool GetLiftExtend()
    {
        return operatorStick.IsButtonJustPressed(8);
    }

    bool GetArmMiddleAndLiftMiddle()
    {
        return operatorStick.IsButtonJustPressed(6);
    }

    bool GetLiftUp()
    {
        return driverStick.IsButtonDown(11)
                || operatorStick.IsButtonDown(10);
    }

    bool GetLiftDown()
    {
        return operatorStick.IsButtonDown(12);
    }

    bool GetLiftHome()
    {
        return operatorStick.IsButtonJustPressed(5);
    }

    const static float minArmY = 0.5;
    bool GetArmUp()
    {
        return !IsOperatorShift() && operatorStick.IsButtonDown(9);
    }

    bool GetArmDown()
    {
        return !IsOperatorShift() && operatorStick.IsButtonDown(11);
    }

    float GetArmSpeed()
    {
        // need negative value to ensure correct direction
        // (if joystick pushed forward, arm up)
        return -LRTUtil::addDeadband<float>(operatorStick.GetY(), minArmY) * 0.6;
    }

    bool GetArmSpeedControlled()
    {
        return LRTUtil::abs<float>(operatorStick.GetY()) > minArmY;
    }

    bool GetDisableRoller()
    {
        return driverStick.IsButtonDown(3);
    }
    
    bool GetToggleRoller()
    {
    	return driverStick.IsButtonJustPressed(3);
    }

    bool GetReverseRoller()
    {
        return driverStick.IsButtonDown(1);
    }

    bool GetTestMode()
    {
        return GetOperatorThrottle() > 0.8 ^ GetDriverThrottle() > 0.8;
    }

    bool GetServiceMode()
    {
        return GetOperatorThrottle() > 0.8 && GetDriverThrottle() > 0.8;
    }

    bool GetServiceKickerGo()
    {
        return driverStick.IsButtonDown(2);
    }

    bool GetServiceKickerPulseReverse()
    {
        return driverStick.IsButtonJustPressed(3);
    }

    bool GetServiceRetractWinch()
    {
        return driverStick.IsButtonDown(7);
    }

    bool GetServiceReleaseWinch()
    {
        return driverStick.IsButtonDown(8);
    }

    bool GetServiceArmUp()
    {
        return driverStick.IsButtonDown(9);
    }

    bool GetServiceArmDown()
    {
        return driverStick.IsButtonDown(11);
    }

    bool GetServiceLiftUp()
    {
        return driverStick.IsButtonDown(10);
    }

    bool GetServiceLiftDown()
    {
        return driverStick.IsButtonDown(12);
    }

    bool GetServiceChangeAutonZone()
    {
        return IsOperatorShift() && operatorStick.IsButtonJustPressed(4);
    }

    bool GetServiceSetArmVertical()
    {
        return IsOperatorShift() && operatorStick.IsButtonJustPressed(9);
    }

    bool GetServiceSetArmMiddle()
    {
        return IsOperatorShift() && operatorStick.IsButtonJustPressed(7);
    }

    bool GetServiceSetLiftMiddle()
    {
        return IsOperatorShift() && operatorStick.IsButtonJustPressed(8);
    }

    bool GetServiceSetArmHome()
    {
        return IsOperatorShift() && operatorStick.IsButtonJustPressed(11);
    }

    bool GetServiceSetLiftExtended()
    {
        return IsOperatorShift() && operatorStick.IsButtonJustPressed(10);
    }

    bool GetServiceSetLiftHome()
    {
        return IsOperatorShift() && operatorStick.IsButtonJustPressed(12);
    }

    bool GetControllerEnabled()
    {
        return gameController.IsButtonJustPressed(11);
    }

    bool GetControllerDisabled()
    {
        return gameController.IsButtonJustPressed(12);
    }

    bool GetControllerPulseWindKicker()
    {
        return gameController.IsButtonJustPressed(1);
    }

    bool GetControllerPulseUnwindKicker()
    {
        return gameController.IsButtonJustPressed(2);
    }

    bool GetControllerArmUp()
    {
        return gameController.IsButtonDown(5);
    }

    bool GetControllerArmDown()
    {
        return gameController.IsButtonDown(7);
    }

    bool GetControllerLiftUp()
    {
        return gameController.IsButtonDown(6);
    }

    bool GetControllerLiftDown()
    {
        return gameController.IsButtonDown(8);
    }

    bool GetControllerStartAutonomous()
    {
        return gameController.IsButtonJustPressed(9);
    }

    bool GetControllerAbortAutonomous()
    {
        return gameController.IsButtonJustPressed(10);
    }

    // normal controls
    float GetForward()
    {
        return LRTUtil::addDeadband<float>(-driverStick.GetY(), 0.15);
    }

    // normal turn
    float GetTurn()
    {
        return LRTUtil::addDeadband<float>(-driverStick.GetRawAxis(3), 0.25);   // twist axis
    }

    float GetOperatorThrottle()
    {
        return -operatorStick.GetRawAxis(4);
    }

    float GetDriverThrottle()
    {
        return -driverStick.GetRawAxis(4);
    }

    /*********************************************************************************************************************************************/

};

#endif /* LRT_DRIVER_CONTROLS_H_ */
