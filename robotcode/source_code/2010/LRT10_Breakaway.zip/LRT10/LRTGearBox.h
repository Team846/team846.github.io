//Author: Brandon Liu and Brian Axelrod (2010)
#ifndef _LRTGearBox_
#define _LRTGearBox_

#include "WPILib.h"
#include "LRTServo.h"
#include <string>
#include <vector>
#include "Synchronized.h"
#include "SpeedController.h"
#include <types/vxWind.h>

class GearBoxListener;

class LRTGearBox
{
public:
    enum GearBoxState {kHighGear, kNeutralGear, kLowGear};

    LRTGearBox(std::string gearBoxName, SpeedController& esc, int servoNum);
    ~LRTGearBox();

    void ApplyConfig();
    void ShiftTo(GearBoxState state);

    GearBoxState GetState();
    int GetPulseCount();

    void SetServiceMode(bool isServiceMode);
    bool IsServiceMode();

    void PulseGearBox();
    void RegisterGearBoxListener(GearBoxListener* listener);
    LRTServo& GetServo();

private:
    LRTServo m_shifterServo;
    SpeedController& m_wheelEsc;
    volatile float m_highVal, m_neutralVal, m_lowVal;

    string m_name;
    Task m_taskPulser;
    volatile GearBoxState m_state;

    volatile int m_pulseCount;
    volatile bool m_isServiceMode;
    SEM_ID m_semaphore;

    std::vector <GearBoxListener*> m_listener;
    volatile float m_servoPulseTime, m_servoRestTime;
};

class GearBoxListener
{
public:
    virtual ~GearBoxListener() {};
    virtual void NotifyGearChange(LRTGearBox::GearBoxState newstate) = 0;
};


#endif
