//Author: David Liu (2010)

#include "LRTRoller.h"
#include "Jaguar.h"
#include "LRTConnections.h"
#include "LRTUtil.h"
#include "LRTConfig.h"
#include "LRTConsole.h"

LRTRoller::LRTRoller(SpeedController& esc, LRTDriveEncoders& driveEncoders)
    : m_escRaw(esc)
    , m_driveEncoders(driveEncoders)
    , m_isEnabled(false)
    , m_isReverse(false)
    , m_prefix("LRTRoller.")
{
    ApplyConfig();
}

void LRTRoller::ApplyConfig()
{
    LRTConfig& config = LRTConfig::GetInstance();

    m_rollerAdjustment = config.Get<float>(m_prefix + "rollerAdjustment", 0.5);
    m_rollerMultiplier = config.Get<float>(m_prefix + "rollerMultiplier", 1.08);

    m_rollerReverseMultiplier = m_rollerForwardMultiplier = m_rollerMultiplier;
    m_rollerForwardMultiplier *= config.Get<float>(m_prefix + "rollerForwardMultiplier", 0.8) ;
    m_rollerReverseMultiplier *= config.Get<float>(m_prefix + "rollerReverseMultiplier", 1.2);

    m_rollerJoystickGain = config.Get<float>(m_prefix + "rollerJoystickGain", 0.02);
    m_isRollerButtonToggling = config.Get<bool>(m_prefix + "isRollerButtonToggling", false);
}

float LRTRoller::GetRollerOutput()
{
    return m_escRaw.Get();
}

void LRTRoller::SetRollerOutput(float speed)
{
    if(speed > 0.01)
        speed += kRollerDeadband;
    else if(speed < -0.01)
        speed -= kRollerDeadband;

    m_escRaw.Set(LRTUtil::clamp<float>(speed, -1.0, 1.0));
}

void LRTRoller::SetEnabled(bool enabled)
{
    m_isEnabled = enabled;
}

bool LRTRoller::GetEnabled()
{
    return m_isEnabled;
}

void LRTRoller::SetReverse(bool reverse)
{
    m_isReverse = reverse;
}

bool LRTRoller::IsReverse()
{
    return m_isReverse;
}

float LRTRoller::ComputeSpeed(float joyDelta)
{
    float suck = -1.0; // positive val is sucking ball in

    if(!m_isReverse)
    {
        float multiplier = m_driveEncoders.GetNormalizedForwardSpeed() > 0 ?
                m_rollerForwardMultiplier : m_rollerReverseMultiplier;

        float leftSpeed = m_driveEncoders.GetLeftSpeed();
        float rightSpeed = m_driveEncoders.GetRightSpeed();

        float maxSpeed = LRTUtil::valWithAbsMax<float>(leftSpeed, rightSpeed);
        float nmSpeed = maxSpeed / LRTDriveEncoders::s_maxEncoderRate;

        suck = -multiplier * nmSpeed + m_rollerAdjustment;
        // add (not subtract) joystick delta to anticipate sudden de-accel [KV] [BA]
        suck -= joyDelta * m_rollerJoystickGain;

        LRTConsole::GetInstance().PrintEverySecond("Mult=%.2f, Spd=%.2f, Adj=%.2f, Suck: %.2f\n",
                multiplier, nmSpeed, m_rollerAdjustment, suck);
    }

    return suck;
}

void LRTRoller::ApplyOutput(float joyDelta)
{
    if(m_isEnabled)
    {
        // motor is wired with opposite polarity
        float motor = -ComputeSpeed(joyDelta);
        SetRollerOutput(motor);
    }
    else
        SetRollerOutput(0);
}

bool LRTRoller::IsRollerButtonToggling()
{
    return m_isRollerButtonToggling;
}
