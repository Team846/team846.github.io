//Author: Brandon Liu (2010)

#include "LRTWinch.h"
#include "LRTConnections.h"
#include "Jaguar.h"
#include "LRTDriverStationLCD.h"

LRTWinch::LRTWinch(SpeedController& esc) :
    m_esc(esc)
    , m_winchState(kIdle)
{

}

void LRTWinch::RetractWinch()
{
    m_winchState = kRetracting;
}
void LRTWinch::ReleaseWinch()
{
    m_winchState = kReleasing;
}

void LRTWinch::ApplyOutput()
{
    switch(m_winchState)
    {
    case kRetracting:
        m_esc.Set(1.0);
        break;

    case kReleasing:
        // victors are not linear
        m_esc.Set(-0.20);
        break;

    case kIdle:
        m_esc.Set(0);
        break;
    }

    m_winchState = kIdle; // force driver to keep the button down
}

float LRTWinch::GetCurrent()
{
//  return m_esc.GetCurrent();
    return 0.0; // switched to Victor; no current measure
}
