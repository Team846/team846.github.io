#define MIN(a,b) ((a)>(b)?(b):(a))
#define MAX(a,b) ((a)<(b)?(b):(a))

#include "LRTesc.h"
#include "AsynchronousPrinter.h"
#include "LRTDriveEncoders.h"
#include "LRTconsole.h"
#include "LRTConfig.h"
#include <string>

// CurrentLimiter class
LRTesc::CurrentLimiter::CurrentLimiter()
    : m_timeExtended(0)
    , m_timeBurst(0)
    , m_coolExtended(0)
    , m_coolBurst(0)
{
}

float LRTesc::CurrentLimiter::Limit(float targetSpeed, float robotSpeed)
{
    if(LRTUtil::abs<float>(targetSpeed) < .001)
        return 0.0; //dont defeat the dynamic braking

    const static float kMaxConst = .55;
    if(targetSpeed < 0)
        return -Limit(-targetSpeed, - robotSpeed);

//  if (robotSpeed + kMaxConst < 0)//if we would be drawing too much current
//  {
//      ApplyBrakes(8);
//      return 0.0;                     //before stopping then just don't power
//  }
    float voltage_normalized = DriverStation::GetInstance()->GetBatteryVoltage() / 12;
    float voltageLim = kMaxConst / voltage_normalized;
//  if (robotSpeed + voltageLim < targetSpeed)
//  AsynchronousPrinter::Printf("%.3f\n", voltage_normalized);
//  if (robotSpeed >= 0.0)
//  {
//      float oldTargetSpeed = targetSpeed;
    targetSpeed = MIN(targetSpeed, robotSpeed + voltageLim);
//      if (targetSpeed != oldTargetSpeed)
//          AsynchronousPrinter::Printf("x\n");
//  }
//  else
//  {
//      if (robotSpeed + voltageLim < 0)
//
//  }
    return targetSpeed;
}

// LRTesc Class
LRTesc::LRTesc(int channel, LRTEncoder& encoder, string name):
    ProxiedCANJaguar(channel)
    , CANJaguarBrake((*(ProxiedCANJaguar*)this))
    , m_encoder(encoder)
    , m_name(name)
    , m_GearBoxState(LRTGearBox::kLowGear)
    , m_index(0)
    , m_errorRunning(0)
{
    ApplyConfig();
}

void LRTesc::ApplyConfig()
{
    string prefix("LRTesc.");
    m_pgain = LRTConfig::GetInstance().Get<float>(prefix + "pgain", 4.0);
}

float LRTesc::GetNormalizedSpeed()
{
    return m_encoder.GetRate() / LRTDriveEncoders::s_maxEncoderRate;
}

void LRTesc::Stop()
{
//  AsynchronousPrinter::Printf("%s stop\n", m_name.c_str());

//  double encoderRate = m_encoder.GetRate();
    //TODO take into account two gears
//  encoderRate /= LRTDriveEncoders::kMaxEncoderRate;
    float RobotSpeed = GetNormalizedSpeed();
    if(LRTUtil::abs<double>(RobotSpeed) > 0.3)
    {
        ApplyBrakes(8);
        Set(0.0);
        return;
    }
    double error = 0.0 - RobotSpeed;
//  m_errors[m_index%kArraySize] = error;
    static float k = 1. / 2;
    m_errorRunning *= k;
    m_errorRunning += error;

    Set(m_errorRunning * m_pgain * (1 - k));
//  AsynchronousPrinter::Printf("error = %f rate = %f gain = %f\n", error, RobotSpeed, m_pgain);
    ApplyBrakes(8);
}

void LRTesc::Set(float speed)
{
//  float robotSpeed = GetNormalizedSpeed();
//  speed = m_currentLimiter.Limit(speed, robotSpeed);

//  AsynchronousPrinter::Printf( "%s value sent: %.2f\n", m_name.c_str(), LRTUtil::clamp<float>(speed, -1.0, 1.0) );

    ProxiedCANJaguar::Set(LRTUtil::clamp<float>(speed, -1.0, 1.0));


    ///be within safe limits for the jaguar
//  static bool above60 = false;
////    static bool
//  float CurrentSpeed = GetNormalizedSpeed();
//  float TargetSpeed = speed;
////    float
//  const static float kCIMStallCurrent = 133.0;
//  const static float kMaxCurrent = 100.0;
//  const static float kHighCurrent = 60.0;
//  const static float kConstantCurrent = 40.0;
//
//  float generatedCurrent;
//  if (LRTUtil::sign<float>(CurrentSpeed)&& LRTUtil::sign<float>(TargetSpeed))
//  {
//      generatedCurrent = (TargetSpeed - CurrentSpeed) * kCIMStallCurrent;
//      if (generatedCurrent > kMaxCurrent)//Not allowed current
//      {
////            float newCurrent =
////            Set();//Set yourself with a current less than maximum
//      }
//  }

}
