#ifndef _LRTesc_
#define _LRTesc_

#include "LRTConnections.h"
#include "ProxiedCANJaguar.h"
#include "CANJaguarBrake.h"
#include "LRTGearBox.h"
#include "WPILib.h"
#include "LRTEncoder.h"

class LRTesc : public ProxiedCANJaguar , public CANJaguarBrake
{
public:
    LRTesc(int channel, LRTEncoder& encoder, string name);

    void ApplyConfig();
    void Stop();
    virtual void Set(float speed);
private:

    class CurrentLimiter
    {
    public:
        CurrentLimiter();
        float Limit(float speed, float robotSpeed);

    private:
        UINT32 m_timeExtended, m_timeBurst;
        UINT32 m_coolExtended, m_coolBurst;

        const static float kmaxContinous = 40.0 / 133;
        const static float kmaxExtended = 60.0 / 133;
        const static float kmaxBurst = 100.0 / 133;

        const static float kmaxExtendedPeriodSeconds = 2.0;
        const static float kmaxBurstPeriodSeconds = 0.2;

        const static float kminExtendedCooldown = 1.0;
        const static float kminBurstCooldown = 0.5;
    };

    CurrentLimiter m_currentLimiter;
    LRTEncoder& m_encoder;
    string m_name;
    LRTGearBox::GearBoxState m_GearBoxState;

    float GetNormalizedSpeed();
    float m_pgain;
    int m_index;

    const static int kArraySize = 4;
    float m_errorRunning;
    float m_errors[kArraySize];
};
#endif /* _LRTesc_ */
