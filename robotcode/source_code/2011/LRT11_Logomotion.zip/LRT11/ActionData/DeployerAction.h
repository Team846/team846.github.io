#ifndef DEPLOYER_ACTION_H
#define DEPLOYER_ACTION_H
#include "..\ActionData.h"

struct DeployerAction
{
    bool shouldAlignerRelease;
    bool shouldDeployMinibot;
};
#endif //DEPLOYER_ACTION_H
