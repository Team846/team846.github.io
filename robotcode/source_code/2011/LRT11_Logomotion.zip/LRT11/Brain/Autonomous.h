#ifndef AUTONOMOUS_H
#define AUTONOMOUS_H

class Autonomous
{
public:
    Autonomous()
    {

    }

};

#endif //AUTONOMOUS_H
