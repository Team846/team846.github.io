#include "LRTDigitalOutput.h"

// 5 us; tested in room 612 on 3/12/11 -KV
UINT32 LRTDigitalOutput::delay = 50 * 5;
