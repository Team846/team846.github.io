var class_brain =
[
    [ "Brain", "class_brain.html#a92daf9737361454abbb5988a89b7ff40", null ]
];