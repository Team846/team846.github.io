var class_build =
[
    [ "GetNumber", "class_build.html#a9f5d52e1840e568016036c34124da091", null ],
    [ "GetTime", "class_build.html#a129bada4f288e35d2340e157f6414c1f", null ]
];