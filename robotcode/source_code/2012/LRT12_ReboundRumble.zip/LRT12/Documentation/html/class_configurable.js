var class_configurable =
[
    [ "Configurable", "class_configurable.html#a058f698c44e2c2fb6d4366a0fbe624f2", null ],
    [ "~Configurable", "class_configurable.html#ac8ec080db0cbe21feafa88470da95e86", null ],
    [ "Configure", "class_configurable.html#a951fdca310cfb5e2090ca10734a181e1", null ]
];