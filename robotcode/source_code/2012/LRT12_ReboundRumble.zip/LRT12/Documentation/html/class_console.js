var class_console =
[
    [ "GetCycleCount", "class_console.html#a7f2f28853a12ad15fecc6efc0580a583", null ],
    [ "GetInstance", "class_console.html#a61d2bbd3b427702716e27a579f97d85a", null ],
    [ "PrintEveryHalfSecond", "class_console.html#a4e9c628cb3178632ab04a5588d8467fe", null ],
    [ "PrintEverySecond", "class_console.html#a6ff6891ea662984db70084187965280a", null ],
    [ "PrintMultipleTimesPerSecond", "class_console.html#a48d9e27150ad93dd8239eef9da0c5254", null ],
    [ "UpdateCycleCount", "class_console.html#a25b10a54442e1372deee3c2b54fbfadd", null ]
];