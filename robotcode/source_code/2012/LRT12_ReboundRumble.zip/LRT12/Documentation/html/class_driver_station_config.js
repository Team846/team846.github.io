var class_driver_station_config =
[
    [ "NUM_JOYSTICK_AXES", "class_driver_station_config.html#ae65eb0493cc153b4eda7634cd02d3ac0", null ],
    [ "NUM_JOYSTICK_BUTTONS", "class_driver_station_config.html#a38682d1a4d65e8831781953451173f32", null ]
];