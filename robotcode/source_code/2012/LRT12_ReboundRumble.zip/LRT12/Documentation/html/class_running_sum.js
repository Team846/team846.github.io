var class_running_sum =
[
    [ "RunningSum", "class_running_sum.html#a3ef30833e073d096a2561bad579139b3", null ],
    [ "Clear", "class_running_sum.html#a6e3d39b38161f01979275007b518abb5", null ],
    [ "UpdateSum", "class_running_sum.html#a2ce3ef61ad0966adc167f499bbd676a9", null ]
];