var searchData=
[
  ['save',['Save',['../class_config.html#ab04c51d227c1457404ae9dadc1c576e1',1,'Config']]],
  ['set',['Set',['../class_config.html#a5d9210c988409c7a95c1c9d0c293daa3',1,'Config']]],
  ['startcompetition',['StartCompetition',['../class_l_r_t_robot_base.html#a242e46650b04f58baaa6c3c585a15634',1,'LRTRobotBase']]]
];
