var struct_config_val =
[
    [ "positionInFile", "struct_config_val.html#a28edcf3f0dc74dda4daa8bb20f2d4400", null ],
    [ "val", "struct_config_val.html#a7ace719baff94cd3c4d8f41804949ae3", null ]
];