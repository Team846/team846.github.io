var struct_sort_by_second_value =
[
    [ "operator()", "struct_sort_by_second_value.html#ab275494b78541d6c37f54597d4824980", null ]
];