var searchData=
[
  ['hasnewvalue',['hasNewValue',['../class_cached_value.html#a791917421d40814e2e3d4b781e137e90',1,'CachedValue']]],
  ['hasvalue',['hasValue',['../class_cached_value.html#ad653f096397652aa24fcbb05d44e76eb',1,'CachedValue']]]
];
