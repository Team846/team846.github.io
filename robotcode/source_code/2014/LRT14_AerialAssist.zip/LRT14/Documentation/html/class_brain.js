var class_brain =
[
    [ "Log", "class_brain.html#a816005fdad839f4dfe56845733407b99", null ]
];