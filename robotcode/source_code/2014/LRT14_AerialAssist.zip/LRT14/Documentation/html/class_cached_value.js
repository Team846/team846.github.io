var class_cached_value =
[
    [ "CachedValue", "class_cached_value.html#a7070b87a5d8f45e82959743a4e8cd5d3", null ],
    [ "CachedValue", "class_cached_value.html#ab23dc10a2fe5b08e920d8ba0b87010ba", null ],
    [ "disableCaching", "class_cached_value.html#aa7ef70e9e1a5bd41b831d47d2279da32", null ],
    [ "enableCaching", "class_cached_value.html#abbe3a76d6cf48b4b086e8bdcede77028", null ],
    [ "getValue", "class_cached_value.html#a5f17c0234d830b6ac9aaf1b63440069e", null ],
    [ "hasNewValue", "class_cached_value.html#a791917421d40814e2e3d4b781e137e90", null ],
    [ "hasValue", "class_cached_value.html#ad653f096397652aa24fcbb05d44e76eb", null ],
    [ "incrementCounter", "class_cached_value.html#a6b3dd9cd1dc8f885784eff58edf698e6", null ],
    [ "isCaching", "class_cached_value.html#a88f3e8fd2b85f4785fb2a4c9f2d944cd", null ],
    [ "peek", "class_cached_value.html#a4c0aafc87504d654d008ff2948e61b2f", null ],
    [ "setValue", "class_cached_value.html#af671c2b0a449d8e6c7f7a70faf26b2a6", null ],
    [ "uncache", "class_cached_value.html#a27307f0fc37ea09c539b55544781e41c", null ]
];