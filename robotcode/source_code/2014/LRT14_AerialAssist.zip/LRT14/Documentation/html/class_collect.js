var class_collect =
[
    [ "Abort", "class_collect.html#a7b1bbbd3935022822939f7469611816f", null ],
    [ "AllocateResources", "class_collect.html#a962da284048cd8963e0feeac48d96db7", null ],
    [ "Configure", "class_collect.html#abda7f92ee85fc4afc460723bc9fe4ff1", null ],
    [ "Run", "class_collect.html#a276fa7cedfb54cd24a7b6be12a07d637", null ],
    [ "Start", "class_collect.html#ac200359d3e4b386961d28c8a2f535168", null ]
];