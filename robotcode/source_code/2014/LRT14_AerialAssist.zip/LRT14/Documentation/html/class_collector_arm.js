var class_collector_arm =
[
    [ "Configure", "class_collector_arm.html#af6e82c989197276b51588b230f62a089", null ],
    [ "OnDisabled", "class_collector_arm.html#a8c052c07843132aa1a03d88f8ca561b0", null ],
    [ "OnEnabled", "class_collector_arm.html#aa5bba6db6f31f53907f8f9e9b16857d8", null ],
    [ "UpdateDisabled", "class_collector_arm.html#ae9fab97314b561366583573fbcef4bdf", null ],
    [ "UpdateEnabled", "class_collector_arm.html#a67beb9463cc8163140fd3ea61e7071d3", null ]
];