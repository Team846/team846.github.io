var class_collector_rollers =
[
    [ "Configure", "class_collector_rollers.html#a659c4319d51558c1732fcd08be027881", null ],
    [ "OnDisabled", "class_collector_rollers.html#aa52b7d5bdb8edbeb17803b8c90012840", null ],
    [ "OnEnabled", "class_collector_rollers.html#a062334c6e26d803b281fa74d1c75adff", null ],
    [ "UpdateDisabled", "class_collector_rollers.html#a811cc84b0e2bbd1fb43b754eed3b7af1", null ],
    [ "UpdateEnabled", "class_collector_rollers.html#a235deb33b545b45a99d065a47af19132", null ]
];