var class_configurable =
[
    [ "Configure", "class_configurable.html#a951fdca310cfb5e2090ca10734a181e1", null ]
];