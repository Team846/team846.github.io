var class_debounced_joystick =
[
    [ "AxisInBounds", "class_debounced_joystick.html#ac957606489bcdaa1a24153579f518a87", null ],
    [ "ButtonInBounds", "class_debounced_joystick.html#abb7370fff3c6432ae89f8177c893c53e", null ],
    [ "GetLastAxis", "class_debounced_joystick.html#ab08fb3b507a2ac2a80295f448a20cd52", null ],
    [ "GetNumAxes", "class_debounced_joystick.html#a901c3465c749809fd771f9095d3bfbde", null ],
    [ "GetNumButtons", "class_debounced_joystick.html#a22b264953d0e9760be61106850d262dd", null ],
    [ "GetPort", "class_debounced_joystick.html#abf42c98d0be7c719228a19f20c0f0204", null ],
    [ "GetRawAxisDelta", "class_debounced_joystick.html#a4ddf89fc4376e37475c8985b62e59481", null ],
    [ "Init", "class_debounced_joystick.html#a1734f9457e5376acdfe74dcd9c84c4ef", null ],
    [ "IsButtonDown", "class_debounced_joystick.html#ace037efd8c60477585092027691525e0", null ],
    [ "IsButtonJustPressed", "class_debounced_joystick.html#ac37bd6a8c9a9ac5435448ee21093a461", null ],
    [ "IsButtonJustReleased", "class_debounced_joystick.html#a55a0a70552ac1d751b012872e2e18f1a", null ],
    [ "IsHatSwitchDown", "class_debounced_joystick.html#a0cc4670f7290cafc50b7b0ca030312f1", null ],
    [ "IsHatSwitchJustPressed", "class_debounced_joystick.html#aa98033cb45bcf87f205d5179e7b50a91", null ],
    [ "IsHatSwitchJustReleased", "class_debounced_joystick.html#a325328a180b9615fa931d44f22a4a271", null ],
    [ "Log", "class_debounced_joystick.html#aa0f84c041cdf0319b83b233cc6f6050a", null ],
    [ "Update", "class_debounced_joystick.html#a56172e067e669025e1172e47285fbe4b", null ],
    [ "WasButtonDown", "class_debounced_joystick.html#a69052711c5a3b0a1e723c30c65fc260f", null ],
    [ "WasHatSwitchDown", "class_debounced_joystick.html#af2e9ca9f8c816de7b692f5702857713c", null ]
];