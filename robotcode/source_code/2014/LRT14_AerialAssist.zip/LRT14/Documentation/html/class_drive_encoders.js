var class_drive_encoders =
[
    [ "~DriveEncoders", "class_drive_encoders.html#af2137e86ff7b99f1f701dc3ec2702357", null ],
    [ "Configure", "class_drive_encoders.html#aa94fc44a3a5e9ecc7486196afd9b2c7f", null ],
    [ "GetEncoder", "class_drive_encoders.html#a802a5e4a9944abc901f70b68b800bbb4", null ],
    [ "GetNormalizedForwardSpeed", "class_drive_encoders.html#ab347d16a7104639d6c5b1a8935e8f001", null ],
    [ "GetNormalizedSpeed", "class_drive_encoders.html#a5f8730962e5650fa53616ad0444b19fe", null ],
    [ "GetNormalizedTurningSpeed", "class_drive_encoders.html#a469555dd7fa99affb43268c301b27d8e", null ],
    [ "GetRawForwardSpeed", "class_drive_encoders.html#afaab579d4625ac496d25a818e909aa2b", null ],
    [ "GetRawTurningSpeed", "class_drive_encoders.html#a68c343a4fe83a96de314a3097c478c5d", null ],
    [ "GetRobotDist", "class_drive_encoders.html#a29be919afe11a8887ff1c9fe4f9b791f", null ],
    [ "GetTurnAngle", "class_drive_encoders.html#a0ccec7f145a82105b48a45ee9f30172b", null ],
    [ "GetTurnRadius", "class_drive_encoders.html#ab8576826a59cee5e119e98aae0504068", null ],
    [ "GetTurnRevolutions", "class_drive_encoders.html#a566b245db06b97d912ad3ce7d008202b", null ],
    [ "GetTurnTicks", "class_drive_encoders.html#aa656031072b3159391365e193ec87763", null ],
    [ "GetWheelDist", "class_drive_encoders.html#a6d6b64ca32221ed7bded573a46aa4364", null ],
    [ "Log", "class_drive_encoders.html#a3154805e827c1ef7e24576476c458294", null ]
];