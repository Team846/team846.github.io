var class_launcher_angle_data =
[
    [ "Log", "class_launcher_angle_data.html#a7873140cb5b1e0cefefa19e157a79c08", null ]
];