var class_launcher_loader =
[
    [ "Configure", "class_launcher_loader.html#a17189d5c48039af71fd2ab6a28e0d8d9", null ],
    [ "OnDisabled", "class_launcher_loader.html#a2e3535327939da2780a442a7e2e5e9ca", null ],
    [ "OnEnabled", "class_launcher_loader.html#a740e166c8e2af199ac61061aba8da4a4", null ],
    [ "Send", "class_launcher_loader.html#a59e12b73c0e2e1899089b3953f7397c5", null ],
    [ "UpdateDisabled", "class_launcher_loader.html#aa8bc61b3af97a484308c4ccfb7312496", null ],
    [ "UpdateEnabled", "class_launcher_loader.html#a96e85ef3247042f60a271aef8cc86662", null ]
];