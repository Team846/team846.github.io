var class_linear_filter =
[
    [ "LinearFilter", "class_linear_filter.html#a438338979d1c704361bf7b31ddf70c3f", null ],
    [ "Reset", "class_linear_filter.html#afd93e79bc869b30449690ea908e7fd0e", null ],
    [ "Update", "class_linear_filter.html#a4c8112e64963ab03897ce011c71b8390", null ]
];