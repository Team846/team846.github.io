var class_live_network_sender =
[
    [ "Run", "class_live_network_sender.html#a2a3ee996f4a35433a5856b0f44120f25", null ],
    [ "Send", "class_live_network_sender.html#a3e8f055d7957a5d3f437c237cd452ba6", null ]
];