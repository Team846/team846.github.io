var class_loggable =
[
    [ "Log", "class_loggable.html#a731e515c2fdd12055724cc650f4bf402", null ],
    [ "LogToFile", "class_loggable.html#afba2ecc852da01f0c940681b8723b498", null ],
    [ "LogToFile", "class_loggable.html#ac26f2e47c2e017b0d3c33efdd89d1e90", null ],
    [ "LogToFile", "class_loggable.html#aa36be77db3991b7774bd5490fdcf2a85", null ]
];