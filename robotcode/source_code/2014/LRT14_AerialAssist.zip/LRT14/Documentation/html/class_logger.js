var class_logger =
[
    [ "Initialize", "class_logger.html#ab39418bac1b42d3316a1d2f02f77baf8", null ],
    [ "Log", "class_logger.html#acbcb94465898e8d8f0dd639c6d417a9f", null ],
    [ "Log", "class_logger.html#a430d4b03b36c0aac339dc64135149660", null ],
    [ "Log", "class_logger.html#a522e84bbef052ef7d36f0215f422867c", null ],
    [ "Run", "class_logger.html#ad5d10a83f45e3f3853d8de526dc77e2b", null ]
];