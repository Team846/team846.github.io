package com.team846.frc2015.automation;

public enum ControlResource {
    DRIVE,
    TURN,
    STRAFE,
    CONTAINER_GRABBER,
    COLLECTOR_ARMS,
    COLLECTOR_ROLLERS,
    ELEVATOR,
    CARRIAGE_HOOKS,
    CARRIAGE_EXTENDER
}
