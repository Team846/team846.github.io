package com.team846.frc2015.components.drivetrain;

public abstract class DriveStyle {
    public abstract DriveSpeed getSpeeds();
}
