package com.team846.frc2015.components.stackSecurity;

public abstract class StackSecurityStyle {
    public abstract boolean isSecurityDown();
}
