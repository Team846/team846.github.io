package com.team846.frc2015.driverstation;

public enum GameState {
    DISABLED,
    AUTONOMOUS,
    TELEOPERATED
}
