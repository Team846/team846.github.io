# Arizona Field Measurements
Auto line to defense ramp - 72.4 in

## Position 1
End of defense ramp to turning point: 112 in

Turn 60 degrees

Drive forward after turn: 94 in

## Position 2
End of defense ramp to turning point: 143 in

Turn 60 degrees

Drive forward after turn: 28.5 in

## Position 3/4
End of defense ramp to batter: 128 in

## Position 5
End of defense ramp to turning point: 147.5 in

## Defenses
Distance to cross low bar: 47.75

Distance to cross cheval: 49 in

Distance to cross rampart: 50 in

Distance to cross moat/rock wall: 51 in

Distance up batter: 48 in
