# Vision Tasks

- [ ] Investigate power supply requirements for coprocessor
- [ ] Decide whether or not to use an infrared filter
- [ ] Investigate potential use of a flashlight to aim at tower
  - [ ] Implement button for flashlight **(not toggle)**
- [ ]  Talk to previous members about aiming with vision
