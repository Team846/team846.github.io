package com.lynbrookrobotics.sixteen.config.constants;

public class DriverButtonAssignments {
  public static final int COLLECT = 1; // driver stick trigger
}
