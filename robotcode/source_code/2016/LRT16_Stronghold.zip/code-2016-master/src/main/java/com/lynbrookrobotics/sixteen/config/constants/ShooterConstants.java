package com.lynbrookrobotics.sixteen.config.constants;

public class ShooterConstants {
  public static double BALL_PROXIMITY_THRESHOLD = 0.8;
}
