package com.lynbrookrobotics.sixteen.tasks;

import com.lynbrookrobotics.potassium.tasks.FiniteTask;

public class InfiniteFinite extends FiniteTask {
  @Override
  protected void startTask() {}

  @Override
  protected void update() {}

  @Override
  protected void endTask() {}
}
