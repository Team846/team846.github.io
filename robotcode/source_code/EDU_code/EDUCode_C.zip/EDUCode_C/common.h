#ifndef __common_h_
#define __common_h_

typedef struct {
	int left;
	int right;
} pwms;

extern pwms gPWM;		//{-127,127}

#endif //__common_h_
