#include "move.h"
#include "turn.h"
#include "common.h"
#include "resultCodes.h"

pwms gPWM;		//{-127,127}

static struct
{
	char autonomousState;
	int cycles;
} gMove={-1,0};


void moveInitialize (int cycles)
{
	gMove.cycles=cycles;
	gMove.autonomousState=0;
}

char moveRun (void)
{
	if (0!=gMove.autonomousState)
		return gMove.autonomousState;

	if (gMove.cycles>0)
	{
		gMove.cycles--;
		gPWM.left=gPWM.right=127;
	}
	else
	{
		gMove.autonomousState=kSuccess;
	}

	return gMove.autonomousState;
}
static char autonomousState=-1;
/*****************************************************************/
char autonomousRunning (void)
{
	return -1 == autonomousState ? 0:1;
}
/*****************************************************************/
void autonomousInit (void)
{
	if (!autonomousRunning())
		autonomousState=0;
}
/*****************************************************************/
char autonomous (void)
{
	static int wait=-1;

	char result;
	char turnResult;

	switch (autonomousState)
	{
		case 0:
			if (wait<0) 
				wait= 5000/17;
			wait--;
			if (wait==0)
			{
				autonomousState++;
				wait=-1;
			}
			break;

		case 1:
			moveInitialize (3000/17);
			autonomousState++;
			// fall through
		case 2:
			result=moveRun();
			if (result)
				autonomousState++;
			break;
		case 3:
			if (wait<0) 
				wait=1;
			wait--;
			if (wait==0)
			{
				autonomousState++;
				wait=-1;
			}
			break;	
		case 4:
			turnInitialize(2000/17, 127, 0); //an int for time, an int for speed
			autonomousState++;
			// fall through
		case 5:
			turnResult=turnRun();
			if (turnResult)
				autonomousState++;
			break;
		case 6:
			if (wait<0) 
				wait=1; //time
			wait--;
			if (wait==0)
			{
				autonomousState++;
				wait=-1;
			}
			break;
		case 7:
			moveInitialize (3000/17);
			autonomousState++;
			// fall through
		case 8:
			result=moveRun();
			if (result)
				autonomousState++;
			break;
		default:
			autonomousState = -1;	//do nothing for default
	}

	return autonomousState;
}
