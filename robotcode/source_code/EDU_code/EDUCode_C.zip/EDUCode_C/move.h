

void moveInitialize (int cycles);
char moveRun (void);

char autonomousRunning (void);
void autonomousInit (void);
char autonomous (void);
