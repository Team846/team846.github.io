enum {kRunning = 0, kSuccess, kTimeOut};
