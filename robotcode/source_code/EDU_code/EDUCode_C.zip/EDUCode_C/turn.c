#include "turn.h"
#include "common.h"
#include "resultCodes.h"

static struct
{
	char turnState;
	int cycles;
	int power; 
	char dir;
} gTurn={-1,0,0,0};


void turnInitialize (int cycles, int power, char dir)
{
	gTurn.cycles=cycles;
	gTurn.turnState=0;
	gTurn.power=power;
	gTurn.dir=dir;
}

char turnRun (void)
{
	if (0!=gTurn.turnState)
		return gTurn.turnState;

	if (gTurn.cycles>0)
	{
		gTurn.cycles--;
		if(gTurn.dir == kLeft)
		{
			gPWM.right=gTurn.power;
			gPWM.left= -gTurn.power;
		}
		else
		{
			gPWM.left=gTurn.power;
			gPWM.right= -gTurn.power;
		}
	}
	else
	{
		gTurn.turnState=kSuccess;
	}

	return gTurn.turnState;
}
