enum dirs {kLeft = 0, kRight};

void turnInitialize (int cycles, int power, char dir);
char turnRun (void);

