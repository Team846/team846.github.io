Victor884 Test data 2/14/04 battery voltage 11.7V
Tested after Victor884 calibrated
within these ranges, 0%<PWM<100%


2004 Victor884's
#1 13,119	134,246  
#2 12,120	135,247
#3 13,121	135,246
#4 13,120	135,246  //properly calibrated


2003 Victor884's before calibration
#1 Dead
#2 42,125	140,229
#3 40,124	139,228	
#4 41,125	140,228

2003 Victor 884's After calibration
#1 Dead
#2 12,120	135,247
#3 12,120	135,247
#4 13,120	135,246

884 period:
883 period:
minimum duty cycle much higher than minimum duty cycle of 884.
2002 Victor 883 before calibration
PWM5
#5	39,123	138,226
#-	12,124	139,247	//already calibrated
2002 Victor 883 after calibration
#5 12,120	135,247
#- 12,119	134,247
based on above data,
map input {0,126},127,{128,254},255
	to
		 {11,121},127,{134,248}
