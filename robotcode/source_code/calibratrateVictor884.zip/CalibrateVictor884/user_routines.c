/*******************************************************************************
* FILE NAME: user_routines.c <FRC VERSION>
*
* DESCRIPTION:
*  This file contains the default mappings of inputs  
*  (like switches, joysticks, and buttons) to outputs on the RC.  
*
* USAGE:
*  You can either modify this file to fit your needs, or remove it from your 
*  project and replace it with a modified copy. 
*
*******************************************************************************/

#include "ifi_aliases.h"
#include "ifi_default.h"
#include "ifi_utilities.h"
#include "user_routines.h"
#include "printf_lib.h"

void MyRoutine(void);
void flashpwm04(void);
int remap2PWM(unsigned char pwm);
/*** DEFINE USER VARIABLES AND INITIALIZE THEM HERE ***/
/* EXAMPLES: (see MPLAB C18 User's Guide, p.9 for all types)
unsigned char wheel_revolutions = 0; (can vary from 0 to 255)
unsigned int  delay_count = 7;       (can vary from 0 to 65,535)
int           angle_deviation = 142; (can vary from -32,768 to 32,767)
unsigned long very_big_counter = 0;  (can vary from 0 to 4,294,967,295)
*/


/*******************************************************************************
* FUNCTION NAME: Limit_Switch_Max
* PURPOSE:       Sets a PWM value to neutral (127) if it exceeds 127 and the
*                limit switch is on.
* CALLED FROM:   this file
* ARGUMENTS:     
*     Argument       Type             IO   Description
*     --------       -------------    --   -----------
*     switch_state   unsigned char    I    limit switch state
*     *input_value   pointer           O   points to PWM byte value to be limited
* RETURNS:       void
*******************************************************************************/
void Limit_Switch_Max(unsigned char switch_state, unsigned char *input_value)
{
  if (switch_state == CLOSED)
  { 
    if(*input_value > 127)
      *input_value = 127;
  }
}


/*******************************************************************************
* FUNCTION NAME: Limit_Switch_Min
* PURPOSE:       Sets a PWM value to neutral (127) if it's less than 127 and the
*                limit switch is on.
* CALLED FROM:   this file
* ARGUMENTS:     
*     Argument       Type             IO   Description
*     --------       -------------    --   -----------
*     switch_state   unsigned char    I    limit switch state
*     *input_value   pointer           O   points to PWM byte value to be limited
* RETURNS:       void
*******************************************************************************/
void Limit_Switch_Min(unsigned char switch_state, unsigned char *input_value)
{
  if (switch_state == CLOSED)
  { 
    if(*input_value < 127)
      *input_value = 127;
  }
}


/*******************************************************************************
* FUNCTION NAME: Limit_Mix
* PURPOSE:       Limits the mixed value for one joystick drive.
* CALLED FROM:   Default_Routine, this file
* ARGUMENTS:     
*     Argument             Type    IO   Description
*     --------             ----    --   -----------
*     intermediate_value    int    I    
* RETURNS:       unsigned char
*******************************************************************************/
unsigned char Limit_Mix (int intermediate_value)
{
  static int limited_value;
  
  if (intermediate_value < 2000)
  {
    limited_value = 2000;
  }
  else if (intermediate_value > 2254)
  {
    limited_value = 2254;
  }
  else
  {
    limited_value = intermediate_value;
  }
  return (unsigned char) (limited_value - 2000);
}


/*******************************************************************************
* FUNCTION NAME: User_Initialization
* PURPOSE:       This routine is called first (and only once) in the Main function.  
*                You may modify and add to this function.
* CALLED FROM:   main.c
* ARGUMENTS:     none
* RETURNS:       void
*******************************************************************************/
void User_Initialization (void)
{
  rom const	char *strptr = "IFI User Processor Initialized ...";

  Set_Number_of_Analog_Channels(SIXTEEN_ANALOG);    /* DO NOT CHANGE! */
MyRoutine();
/* FIRST: Set up the I/O pins you want to use as digital INPUTS. */
  digital_io_01 = digital_io_02 = digital_io_03 = digital_io_04 = INPUT;
  digital_io_05 = digital_io_06 = digital_io_07 = digital_io_08 = INPUT;
  digital_io_09 = digital_io_10 = digital_io_11 = digital_io_12 = INPUT;
  digital_io_13 = digital_io_14 = digital_io_15 = digital_io_16 = INPUT;
  digital_io_18 = INPUT;  /* Used for pneumatic pressure switch. */
    /* 
     Note: digital_io_01 = digital_io_02 = ... digital_io_04 = INPUT; 
           is the same as the following:

           digital_io_01 = INPUT;
           digital_io_02 = INPUT;
           ...
           digital_io_04 = INPUT;
    */

/* SECOND: Set up the I/O pins you want to use as digital OUTPUTS. */
  digital_io_17 = OUTPUT;    /* Example - Not used in Default Code. */

/* THIRD: Initialize the values on the digital outputs. */
  rc_dig_out17 = 0;

/* FOURTH: Set your initial PWM values.  Neutral is 127. */
  pwm01 = pwm02 = pwm03 = pwm04 = pwm05 = pwm06 = pwm07 = pwm08 = 127;
  pwm09 = pwm10 = pwm11 = pwm12 = pwm13 = pwm14 = pwm15 = pwm16 = 127;

/* FIFTH: Set your PWM output types for PWM OUTPUTS 13-16.
  /*   Choose from these parameters for PWM 13-16 respectively:               */
  /*     IFI_PWM  - Standard IFI PWM output generated with Generate_Pwms(...) */
  /*     USER_CCP - User can use PWM pin as digital I/O or CCP pin.           */
  Setup_PWM_Output_Type(IFI_PWM,IFI_PWM,IFI_PWM,IFI_PWM);

  /* 
     Example: The following would generate a 40KHz PWM with a 50% duty cycle on the CCP2 pin:

         CCP2CON = 0x3C;
         PR2 = 0xF9;
         CCPR2L = 0x7F;
         T2CON = 0;
         T2CONbits.TMR2ON = 1;

         Setup_PWM_Output_Type(USER_CCP,IFI_PWM,IFI_PWM,IFI_PWM);
  */

  /* Add any other initialization code here. */

  Initialize_Serial_Comms();   
  
  Putdata(&txdata);             /* DO NOT CHANGE! */

  printf("%s\n", strptr);       /* Optional - Print initialization message. */

  User_Proc_Is_Ready();         /* DO NOT CHANGE! - last line of User_Initialization */
}

/*******************************************************************************
* FUNCTION NAME: Process_Data_From_Master_uP
* PURPOSE:       Executes every 26.2ms when it gets new data from the master 
*                microprocessor.
* CALLED FROM:   main.c
* ARGUMENTS:     none
* RETURNS:       void
*******************************************************************************/
void Process_Data_From_Master_uP(void)
{
  Getdata(&rxdata);   /* Get fresh data from the master microprocessor. */

  MyRoutine();  /* Optional.  See below. */

 
 //Generate_Pwms(pwm13,pwm14,pwm15,pwm16);

  Putdata(&txdata);             /* DO NOT CHANGE! */
}

/*******************************************************************************
* FUNCTION NAME: Default_Routine
* PURPOSE:       Performs the default mappings of inputs to outputs for the
*                Robot Controller.
* CALLED FROM:   this file, Process_Data_From_Master_uP routine
* ARGUMENTS:     none
* RETURNS:       void
*******************************************************************************/
int remapPWM(unsigned char pwm);
char calibratePWM03(void);
void MyRoutine(void)
{
  static char ticks = 0;	//approx 38 ticks / second
  static char fifthSec=0; //set to zero every quarter second
  overlay char pwmChanged=0;
  static char calibrating=0;
  if (++ticks >= 1000/26.2) ticks=0;
  if (++fifthSec >= 200/26.2) fifthSec=0;
  
  pwm01 = p1_y;   
  //pwm02 = p2_y;
  
  // use this to set pwm03 up/down for testing
  //when calibrating, finish by pressing trigger sw to set center to 127.
  //Victor884 sets midpoint to final 'stick' postition.
	if (calibrating)
  	{
	   	calibrating = calibratePWM03();
	   	if (!calibrating) printf("calibration finished\n");
	}
	else if (p3_sw_top && p3_sw_trig)
	{
		calibrating=1;
		printf("calibrating\n");
	}
	else
	{
		if (p3_sw_trig){pwm01=127; }	//force pwm01 to neutral
		if (p3_sw_trig && pwm03 != 127){pwm03=127; pwmChanged=1; }
		if (p3_sw_top && pwm03 !=0){pwm03=0; pwmChanged=1; }
		if (p3_sw_aux1 && 0==fifthSec) {pwm03--; pwmChanged=1; }
		if (p3_sw_aux2 && 0==fifthSec) {pwm03++; pwmChanged=1; }
		if (pwmChanged) printf("pwm03=%d\n", (int)pwm03);
	}
	if (1)
	  	flashpwm04();  //connect lamp to Victor on pwm04 to test uniformity
	  //	pwm04 = remap2PWM(0);
	  //	pwm04 = remap2PWM(40);
	  //	pwm04 = remap2PWM(150);
  	if (0)
	{
 	 	pwm04 = remap2PWM(p1_y);	
		if (0==ticks)	//on the second
		 	printf("pwm01=%3d -> %3d\n", (int)pwm01, (int)pwm04);
	}
}


/******************************************************************************/
/******************************************************************************/
/******************************************************************************/

/*we want to map input PWM's {-127,-d,+d,127} to empirical points below: */
/* From measurements with an oscilloscope,
 * AFTER the Victor was calibrated per the instructions,
 * the Victor884 under test had a duty cycle, d, 0%<d<100% over the ranges
 * {12,118},{133,247}
 * based on above data,
 * map input {0,126},127,{128,254},255
	 {11,121},127,{134,248}
 *
 */
typedef struct {
	int a,b,c,d;
} rangeMap;

//	int iii=127+1;  //watch out! sets iii to 0xFF80, not 128 (0x0080)
//	int jjj=128;	//this works
//	iii=127L+1;		//this works iii set to 128 (0x0080)
int remapPWM(unsigned char pwm)
{
	static const rangeMap in = {0,126,128,254};
	static const rangeMap out = {11,121,134,248};
	
	int newPwm=127;
	int neutral = (out.b+out.c)/2;
	
	if (pwm<in.a)
		newPwm = neutral;   //error
	else if (pwm<=in.b)
		newPwm = ((pwm-in.a)*out.b + (in.b-pwm)*out.a) / (in.b-in.a);
	else if (pwm<in.c)
		newPwm = neutral;
	else if (pwm<= in.d)
		newPwm = ((pwm-in.c)*out.d + (in.d-pwm)*out.c) / (in.d-in.c);
	else
		newPwm = neutral;   //error
	return newPwm;
}

int remap2PWM(unsigned char pwm);
int remap2PWM(unsigned char pwm)
{
	enum in {a=0,b=126, c=128,d=254};
	enum out {w=11,x=121,y=134,z=248};
	
	int newPwm=127;
	int neutral = (x+y)/2;
	
	if (pwm<a)
		newPwm = neutral;   //error
	else if (pwm<=b)
		newPwm = ((pwm-a)*(int)x + (b-pwm)*(int)w) / (b-(int)a);
	else if (pwm<c)
		newPwm = neutral;
	else if (pwm<=d)
		newPwm = ((pwm-c)*(int)z + (d-pwm)*(int)y) / (d-(int)c);
	else
		newPwm = neutral;   //error
	return newPwm;
}

enum {xxx,yyy};

int remapPWMnoDeadband(unsigned char const pwm);
int remapPWMnoDeadband(unsigned char const pwm)
{
//	static const rangeMap in = {0,126,128,254};
	static const rangeMap out = {11,121,134,248};
	
	int newPwm;
	
	if (pwm<=126)
		newPwm = ((pwm-0)*out.b + (126-pwm)*out.a)/126;
	else if (pwm<128)
		newPwm = 127;
	else if (pwm<= 254)
		newPwm = ((pwm-128)*out.d + (254-pwm)*out.c) /126;
	else
		newPwm = 127; 
	return newPwm;
}

int remapPWMwithDeadband(unsigned char const pwm);
int remapPWMwithDeadband(unsigned char const pwm)
{
//	static const rangeMap in = {0,126,128,254};
	static const rangeMap out = {11,121,134,248};
#define kDeadband 2L 
	int newPwm;
	
	if (pwm<=126)
		newPwm = ((pwm-0)*out.b + (126-pwm)*out.a)/126;
	else if (pwm<128)
		newPwm = 127;
	else if (pwm<= 254)
		newPwm = ((pwm-128)*out.d + (254-pwm)*out.c) /126;
	else
		newPwm = 127; 
	return newPwm;
}


void flashpwm04(void)
{
	static char count=0;
	static char on=40;  //0-127
	if (++count >= 1000/26.2)
	{
		count = 0;	
		pwm04 = remapPWM(127+(on= -on));
		printf("flash: pwm04=%3d\n", (int) pwm04);
	}	
}


char calibratePWM03(void)
{
	static char phase=0;
	static char wait=0;
	txdata.user_byte3=phase;
	txdata.user_byte4=wait;
	
	switch (phase)
	{
		case 0:	//first pass
			phase = 1;
			pwm03=254;	//set to max and wait 15 passes
			wait=15;
			break;
		case 1:
			if (--wait==0) phase++;
			break;
		case 2:
			pwm03=0;	//set to negative max and wait 15 passes
			wait=15;
			phase++;
			break;
		case 3:
			if (--wait==0) phase++;
			break;
		case 4:
			pwm03=127;
			wait=2000/26.2;	//SET to neutral and wait 2 seconds
			phase++;
			break;
		case 5:
			if (--wait==0) phase=0; //reset phase
			break;
	}
	return phase;
}
